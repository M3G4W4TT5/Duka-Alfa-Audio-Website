export { ChladniEditor, type ChladniEditorHandle, type ChladniEditorProps } from './components/ChladniEditor';
export { parseConfiguration, type Configuration } from './plate/configuration';
export { createStarterPreset } from './plate/starter';
export type { PlatePointerEvent as ChladniPointerEvent } from './plate/experiment';
export type { ChladniPresentationStatus } from './plate/use-plate';
