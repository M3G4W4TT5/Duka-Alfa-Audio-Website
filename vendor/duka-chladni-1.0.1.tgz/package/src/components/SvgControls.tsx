import { useRef } from 'react';
import { clamp, svgPlacement, type SvgLayerSettings } from '../plate/settings';
import { percent, SettingSlider } from './ControlFields';

export interface SvgSourceControls {
  name: string;
  aspect: number;
  custom: boolean;
  busy: boolean;
  ready: boolean;
  error: string;
  choose: (file: File | null) => void;
}

export function Switch({ label, checked, change }: {
  label: string; checked: boolean; change: (checked: boolean) => void;
}) {
  return <label className="plate-switch">
    <span>{label}</span>
    <input type="checkbox" role="switch" checked={checked} onChange={event => change(event.target.checked)} />
  </label>;
}

const mm = (v: number) => `${Number(v.toFixed(2))} mm`;

export function SvgControls({ layer, source, change }: {
  layer: SvgLayerSettings; source: SvgSourceControls; change: (patch: Partial<SvgLayerSettings>) => void;
}) {
  const input = useRef<HTMLInputElement>(null);
  const { travelX, travelY } = svgPlacement(layer.size, source.aspect);
  return <section className="svg-section" aria-label="SVG layer">
    <h2><Switch label="SVG layer" checked={layer.enabled} change={enabled => change({ enabled })} /></h2>
    {layer.enabled && <>
      <div className="svg-source">
        <span className="svg-filename" title={source.name}>{source.busy ? 'Preparing SVG…' : source.name}</span>
        <div className="panel-actions">
          <button type="button" onClick={() => input.current?.click()}>Upload SVG</button>
          {source.custom && <button type="button" onClick={() => source.choose(null)}>Use Duka logo</button>}
        </div>
        <input hidden type="file" aria-label="SVG file" accept=".svg,image/svg+xml" ref={input}
          onChange={event => {
            const file = event.currentTarget.files?.[0];
            if (file) source.choose(file);
            event.currentTarget.value = '';
          }} />
      </div>
      {source.error && <p className="control-note" role="alert">{source.error}</p>}
      <div className="svg-roles">
        <label className="material-inherit"><input type="checkbox" checked={layer.stencil}
          onChange={event => change({ stencil: event.target.checked })} />Use as stencil</label>
        <label className="material-inherit"><input type="checkbox" checked={layer.artwork}
          onChange={event => change({ artwork: event.target.checked })} />Show artwork</label>
      </div>
      {(layer.stencil || layer.artwork) && <>
        <SettingSlider spec={{ label: 'SVG size', min: 5, max: 100, step: 1, format: v => `${v}%` }}
          value={layer.size} onChange={size => {
            const bounds = svgPlacement(size, source.aspect);
            change({ size, x: clamp(layer.x, -bounds.travelX, bounds.travelX), y: clamp(layer.y, -bounds.travelY, bounds.travelY) });
          }} />
        <SettingSlider spec={{ label: 'SVG X position', min: -travelX, max: travelX, step: .1, format: mm }}
          value={layer.x} onChange={x => change({ x })} />
        <SettingSlider spec={{ label: 'SVG Y position', min: -travelY, max: travelY, step: .1, format: mm }}
          value={layer.y} onChange={y => change({ y })} />
      </>}
      {layer.stencil && <div className="svg-group">
        <span className="control-caption">Stencil shape</span>
        <div className="drive-modes" role="group" aria-label="Stencil shape">
          {(['fill', 'outline'] as const).map(shape => <button type="button" key={shape}
            aria-pressed={layer.shape === shape} onClick={() => change({ shape })}>{shape === 'fill' ? 'Fill' : 'Outline'}</button>)}
        </div>
        {layer.shape === 'outline' && <SettingSlider spec={{ label: 'Outline weight', min: .1, max: 5, step: .05, format: mm }}
          value={layer.weight} onChange={weight => change({ weight })} />}
      </div>}
      {layer.artwork && <div className="svg-group">
        <SettingSlider spec={{ label: 'Artwork height', min: 0, max: 8, step: .05, format: mm }}
          value={layer.height} onChange={height => change({ height })} />
        <SettingSlider spec={{ label: 'Artwork opacity', min: 0, max: 1, step: .01, format: percent }}
          value={layer.opacity} onChange={opacity => change({ opacity })} />
        <label className="material-inherit"><input type="checkbox" checked={layer.shadows}
          onChange={event => change({ shadows: event.target.checked })} />Cast shadows</label>
      </div>}
    </>}
  </section>;
}
