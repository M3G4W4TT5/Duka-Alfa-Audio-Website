import { useRef } from 'react';
import type { Arrangement } from '../plate/configuration';

export function ConfigurationControls({ arrangement, change, hasStencil, busy, message, save, load }: {
  arrangement: Arrangement; change: (v: Arrangement) => void; hasStencil: boolean;
  busy: boolean; message: string; save: () => void; load: (file: File) => void;
}) {
  const input = useRef<HTMLInputElement>(null);
  return <section aria-label="Configuration" className="configuration-controls">
    <details><summary>Configuration</summary>
      <label className="field-row">Starting sand
        <select aria-label="Starting sand" value={arrangement} onChange={e => change(e.target.value as Arrangement)}>
          <option value="loose">Loose sand</option><option value="pattern">Settled pattern</option>
          <option value="stencil" disabled={!hasStencil}>Poured into stencil</option>
        </select>
      </label>
      <div className="panel-actions">
        <button type="button" onClick={save} disabled={busy}>Export configuration</button>
        <button type="button" onClick={() => input.current?.click()}>Import configuration</button>
      </div>
      <input ref={input} type="file" hidden accept=".chladni.json,.json,application/json" aria-label="Configuration file"
        onChange={event => { const file = event.target.files?.[0]; event.target.value = ''; if (file) load(file); }} />
      {message && <p role="status" className="control-note">{message}</p>}
    </details>
  </section>;
}
