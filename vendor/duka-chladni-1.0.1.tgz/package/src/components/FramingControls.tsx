import { useEffect, useId, useRef, useState, type PointerEvent } from 'react';
import { HALF } from '../plate/field';
import { cornerCrop, cropAt, cropZoom, fillFrame, fitPlate, MAX_ZOOM, visibleCrop,
  type Crop, type Framing, type Point, type Preview, type ViewId } from '../plate/framing';
import { NumericEntry, SettingSlider } from './ControlFields';
import { Switch } from './SvgControls';

const names = { window: 'Window', desktop: 'Desktop', mobile: 'Mobile' };
const corners = [[-1,-1], [1,-1], [-1,1], [1,1]] as const;
type Drag = { type: 'move' | 'resize'; start: Point; crop: Crop; box: string; pointer: number };

function Overview({ crop, change, sample }: { crop: Crop; change: (crop: Crop) => void; sample: () => Float32Array | undefined }) {
  const svg = useRef<SVGSVGElement>(null);
  const image = useRef<SVGImageElement>(null);
  const drag = useRef<Drag | null>(null);
  const [drawing, setDrawing] = useState(false);
  const title = useId();
  useEffect(() => {
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = 256;
    const ctx = canvas.getContext('2d')!;
    let visible = false;
    function paint() {
      if (document.hidden || !visible) return;
      const points = sample();
      if (!points) return;
      ctx.clearRect(0, 0, 256, 256);
      ctx.fillStyle = '#edcbea8c';
      for (let i = 0; i < points.length; i += 4)
        ctx.fillRect((.5 + points[i] / (2 * HALF)) * 256, (.5 - points[i + 1] / (2 * HALF)) * 256, 1.4, 1.4);
      image.current?.setAttribute('href', canvas.toDataURL());
    }
    const observer = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (visible) paint();
    });
    observer.observe(svg.current!);
    const timer = window.setInterval(paint, 500);
    return () => { clearInterval(timer); observer.disconnect(); };
  }, [sample]);
  const left = crop.centerX - crop.width / 2, top = crop.centerY - crop.height / 2;
  const minX = Math.min(0, left), minY = Math.min(0, top);
  const w = Math.max(1, left + crop.width) - minX, h = Math.max(1, top + crop.height) - minY;
  const size = Math.max(w, h) * 1.08;
  const box = drag.current?.box ?? [minX + (w - size) / 2, minY + (h - size) / 2, size, size].join(' ');
  const handle = Math.max(w, h) * .022;
  function point(event: PointerEvent<SVGSVGElement>): Point {
    const at = new DOMPoint(event.clientX, event.clientY).matrixTransform(svg.current!.getScreenCTM()!.inverse());
    return { x: at.x, y: at.y };
  }
  function begin(event: PointerEvent<SVGSVGElement>) {
    if (event.button !== 0 || drag.current) return;
    const target = event.target as SVGElement;
    const index = target.getAttribute('data-corner');
    const p = point(event);
    const corner = !drawing && index !== null ? corners[Number(index)] : null;
    const move = !drawing && !corner && target.hasAttribute('data-frame');
    const start = corner ? { x: crop.centerX - corner[0] * crop.width / 2, y: crop.centerY - corner[1] * crop.height / 2 } : p;
    drag.current = { type: move ? 'move' : 'resize', start, crop, box, pointer: event.pointerId };
    svg.current!.setPointerCapture(event.pointerId);
  }
  function move(event: PointerEvent<SVGSVGElement>) {
    const d = drag.current;
    if (!d || d.pointer !== event.pointerId) return;
    const p = point(event), aspect = d.crop.width / d.crop.height;
    change(d.type === 'resize' ? cornerCrop(d.start, p, aspect) :
      cropAt(aspect, Math.min(d.crop.width, d.crop.height), d.crop.centerX + p.x - d.start.x, d.crop.centerY + p.y - d.start.y));
  }
  const [, redraw] = useState(0);
  function end(event: PointerEvent<SVGSVGElement>) {
    if (drag.current?.pointer !== event.pointerId) return;
    drag.current = null; setDrawing(false); redraw(n => n + 1);
  }
  return <div className="crop-overview">
    <div className="map-toolbar"><span>Plate overview</span><button type="button" aria-pressed={drawing}
      onClick={() => setDrawing(value => !value)}>Draw crop</button></div>
    <svg ref={svg} viewBox={box} role="img" aria-labelledby={title} className={drawing ? 'drawing' : ''}
      onPointerDown={begin} onPointerMove={move} onPointerUp={end} onPointerCancel={end} onLostPointerCapture={end}>
      <title id={title}>Full plate with the visible crop. Drag the frame or its corners, or use the values below.</title>
      <rect width="1" height="1" className="map-plate" />
      <path d="M.5 0V1 M0 .5H1" className="map-axis" />
      <image ref={image} x="0" y="0" width="1" height="1" pointerEvents="none" />
      <rect data-frame="" x={left} y={top} width={crop.width} height={crop.height} className="map-frame" />
      {corners.map(([x,y], i) => <rect key={i} data-corner={i} className="map-handle"
        x={crop.centerX + x * crop.width / 2 - handle} y={crop.centerY + y * crop.height / 2 - handle}
        width={2 * handle} height={2 * handle} style={{ cursor: x === y ? 'nwse-resize' : 'nesw-resize' }} />)}
    </svg>
  </div>;
}

export function FramingControls({ preview, update, aspect, setCrop, sample }: {
  preview: Preview; update: (patch: Partial<Preview>) => void; aspect: number;
  setCrop: (crop: Crop | null) => void; sample: () => Float32Array | undefined;
}) {
  const { view, framing, editing } = preview;
  const container = preview.layout === 'container';
  const device = view === 'window' ? null : framing[view];
  const ratio = device && !container ? device.width / device.height : aspect;
  const crop = visibleCrop(framing, view, ratio);
  const zoom = cropZoom(device?.crop ?? crop);
  function patchFraming(patch: Partial<Framing>) { update({ framing: { ...framing, ...patch } }); }
  const short = Math.min(crop.width, crop.height);
  const rounded = (n: number) => Number(n.toFixed(3));
  return <section aria-label="View" className="framing-controls">
    <h2>View <small>{container ? 'Current container' : device ? device.width + ' × ' + device.height : 'Current window'}</small></h2>
    <div className="drive-modes" role="group" aria-label="Preview size">{(Object.keys(names) as ViewId[]).map(id =>
      <button type="button" key={id} aria-pressed={view === id} onClick={() => update({ view: id })}>{names[id]}</button>)}</div>
    <div className="drive-modes" role="group" aria-label="Preview interaction">
      <button type="button" aria-pressed={!editing} onClick={() => update({ editing: false })}>Interact</button>
      <button type="button" aria-pressed={editing} onClick={() => update({ editing: true })}>Edit crop</button>
    </div>
    {device && view !== 'window' && <Switch label="Use this crop on the website" checked={device.enabled}
      change={enabled => patchFraming({ [view]: { ...device, enabled } })} />}
    {editing && <>
      <p className="control-note">{container ? 'Drag the crop in the plate overview to pan, or drag a corner to zoom.' :
        'Drag the scene to pan. Scroll or pinch to zoom.'}</p>
      <Overview key={view} crop={crop} change={setCrop} sample={sample} />
      {(['x', 'y'] as const).map(axis => <SettingSlider key={axis}
        spec={{ label: 'Centre ' + axis.toUpperCase(), min: 0, max: 100, step: .1, format: n => n + '%' }}
        entry={{ label: 'Crop centre ' + axis.toUpperCase() + ' percent', unit: '%' }}
        value={Number((100 * (axis === 'x' ? crop.centerX : crop.centerY)).toFixed(1))} onChange={value =>
          setCrop(cropAt(ratio, short, axis === 'x' ? value / 100 : crop.centerX, axis === 'y' ? value / 100 : crop.centerY))} />)}
      <SettingSlider spec={{ label: 'Zoom', min: 1, max: Math.max(MAX_ZOOM, rounded(zoom)), step: .001, format: n => n + '×' }}
        entry={{ label: 'Crop zoom factor', unit: '×' }} value={rounded(zoom)}
        onChange={value => setCrop(cropAt(ratio, short * zoom / value, crop.centerX, crop.centerY))} />
      <div className="panel-actions"><button type="button" onClick={() => setCrop(view === 'window' ? null : fitPlate(ratio))}>Fit whole plate</button>
        <button type="button" onClick={() => setCrop(fillFrame(ratio))}>Fill frame</button></div>
    </>}
    {(framing.desktop.enabled || framing.mobile.enabled) && <label className="breakpoint-control">
      Mobile below <NumericEntry label="Mobile breakpoint in CSS pixels" value={framing.breakpoint} min={240} max={2560} step={1}
        commit={n => { const breakpoint = Math.max(240, Math.min(2560, Math.round(n))); patchFraming({ breakpoint }); return breakpoint; }} /> px
    </label>}
  </section>;
}
