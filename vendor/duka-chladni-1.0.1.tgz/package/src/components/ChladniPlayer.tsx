import { useEffect, useImperativeHandle, useLayoutEffect, useMemo, useRef, useState, type Ref } from 'react';
import { parseConfiguration } from '../plate/configuration';
import { defaultFraming, type Preview } from '../plate/framing';
import { loadPresetSvg } from '../plate/preset-assets';
import { DEFAULT_SETTINGS } from '../plate/settings';
import { usePlate, type ChladniPointerHandle, type ChladniPresentationStatus } from '../plate/use-plate';
import '../styles/stage.css';

export interface ChladniPlayerHandle extends ChladniPointerHandle {
  /** Submit the prepared frame at the current container size without advancing it. */
  present(): boolean;
}

export interface ChladniPlayerProps {
  configuration: unknown;
  active?: boolean;
  /** Prepare and draw the preset once even when playback is inactive. */
  prepare?: boolean;
  onStatusChange?: (status: ChladniPresentationStatus) => void;
  ref?: Ref<ChladniPlayerHandle>;
}

export function ChladniPlayer({ configuration, active = true, prepare = false, onStatusChange, ref }: ChladniPlayerProps) {
  const preset = useMemo(() => {
    try {
      return { value: parseConfiguration(configuration) };
    } catch (error) {
      return { message: error instanceof Error ? error.message : 'Could not read configuration.' };
    }
  }, [configuration]);
  const settings = useRef(preset.value?.settings ?? DEFAULT_SETTINGS);
  const preview = useRef<Preview>({ view: 'window', editing: false, layout: 'player', framing: defaultFraming() });
  const { stage, canvas, error, plate, instance, surface } = usePlate({
    active: active && !!preset.value, prepare: prepare && !!preset.value, settings, preview,
  });
  const [ready, setReady] = useState<{ preset: typeof preset; surface: typeof surface }>();
  const [failure, setFailure] = useState<{ preset: typeof preset; message: string }>();
  const message = preset.message ?? (failure?.preset === preset ? failure.message : undefined);
  const status = message || surface?.available === false ? 'unavailable'
    : ready?.preset === preset && ready.surface === surface ? 'ready' : 'preparing';

  useImperativeHandle(ref, () => ({
    movePointer: event => { if (status === 'ready') instance.current?.movePointer(event); },
    leavePointer: () => instance.current?.leavePointer(),
    present: () => status === 'ready' && !!instance.current?.present(),
  }), [instance, status]);

  useLayoutEffect(() => onStatusChange?.(status), [onStatusChange, status]);

  useEffect(() => {
    if (!plate || !surface?.available || !preset.value) return;
    const config = preset.value;
    const controller = new AbortController();
    const { signal } = controller;
    plate.cancelPreparation();
    loadPresetSvg(config, signal).then(({ image }) => {
      if (signal.aborted) return;
      settings.current = config.settings;
      preview.current = { ...preview.current, framing: config.framing };
      plate.setSvgImage(image);
      plate.restore(config.start, () => { if (!signal.aborted) setReady({ preset, surface }); });
    }).catch(error => {
      if (!signal.aborted) setFailure({ preset, message: error instanceof Error ? error.message : 'Could not load configuration.' });
    });
    return () => controller.abort();
  }, [plate, preset, surface]);

  return <div className="chladni-player" data-presentation={status}>
    <div className="plate-stage" ref={stage} style={status === 'ready' ? undefined : { visibility: 'hidden' }}>
      <canvas ref={canvas} aria-hidden="true" />
    </div>
    {message && <p className="plate-error" role="status">{message}</p>}
    <p className="plate-error" ref={error} role="status" hidden>The plate needs WebGL2 with floating-point render targets.</p>
  </div>;
}
