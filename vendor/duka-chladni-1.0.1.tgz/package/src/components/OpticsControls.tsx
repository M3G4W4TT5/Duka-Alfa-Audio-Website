import { useRef, useState, type CSSProperties } from 'react';
import { Color } from 'three';
import { clamp, sampleGradient, type BloomSettings, type GradientStop } from '../plate/settings';
import { percent, SettingSlider, type SliderSpec } from './ControlFields';

export function GradientEditor({ gradient, onChange }: {
  gradient: GradientStop[];
  onChange: (gradient: GradientStop[]) => void;
}) {
  const ramp = useRef<HTMLDivElement>(null);
  const [selectedId, setSelectedId] = useState(0);
  const selected = gradient.find(stop => stop.id === selectedId) ?? gradient[0];
  const isEndpoint = (stop: GradientStop) => stop.id === 0 || stop.id === 1;
  const sort = (stops: GradientStop[]) => stops.sort((a, b) => a.position - b.position);
  const position = (at: number) => Math.round(clamp(at, .001, .999) * 1000) / 1000;
  const positionAt = (x: number) => {
    const bounds = ramp.current!.getBoundingClientRect();
    return (x - bounds.left) / bounds.width;
  };

  function updateStop(id: number, change: Partial<Pick<GradientStop, 'position' | 'color'>>) {
    onChange(sort(gradient.map(stop => stop.id === id ? { ...stop, ...change } : stop)));
  }

  function addStop(at: number) {
    const point = position(at);
    const color = sampleGradient(gradient, point, new Color(), new Color());
    const id = gradient.reduce((max, stop) => Math.max(max, stop.id), 1) + 1;
    onChange(sort([...gradient, { id, position: point, color: '#' + color.getHexString() }]));
    setSelectedId(id);
  }

  function addInLargestGap() {
    let gap = 0;
    let midpoint = .5;
    for (let i = 1; i < gradient.length; i++) {
      const length = gradient[i].position - gradient[i - 1].position;
      if (length > gap) {
        gap = length;
        midpoint = gradient[i - 1].position + length / 2;
      }
    }
    addStop(midpoint);
  }

  function removeStop(stop: GradientStop) {
    if (isEndpoint(stop)) return;
    const index = gradient.findIndex(entry => entry.id === stop.id);
    setSelectedId(gradient[index - 1].id);
    onChange(gradient.filter(entry => entry.id !== stop.id));
  }

  return (
    <div className="gradient-editor">
      <div
        className="gradient-ramp"
        ref={ramp}
        onPointerDown={event => {
          if (event.target === event.currentTarget && event.button === 0) addStop(positionAt(event.clientX));
        }}
        style={{ backgroundImage: `linear-gradient(90deg in srgb-linear, ${gradient.map(stop =>
          `${stop.color} ${stop.position * 100}%`).join(', ')})` }}
      >
        {[...gradient].sort((a, b) => a.id - b.id).map(stop => {
          const fixed = isEndpoint(stop);
          const percent = Math.round(stop.position * 1000) / 10;
          return (
            <button
              key={stop.id}
              type="button"
              className="gradient-stop"
              data-active={stop.id === selected.id}
              data-fixed={fixed}
              style={{ left: `${percent}%`, '--stop-color': stop.color } as CSSProperties}
              aria-label={fixed ? (stop.id === 0 ? 'Left colour stop' : 'Right colour stop') : `Colour stop at ${percent}%`}
              aria-pressed={stop.id === selected.id}
              onFocus={() => setSelectedId(stop.id)}
              onClick={() => setSelectedId(stop.id)}
              onPointerDown={event => {
                if (event.button !== 0) return;
                setSelectedId(stop.id);
                if (!fixed) event.currentTarget.setPointerCapture(event.pointerId);
              }}
              onPointerMove={event => {
                if (!fixed && event.currentTarget.hasPointerCapture(event.pointerId)) {
                  updateStop(stop.id, { position: position(positionAt(event.clientX)) });
                }
              }}
              onKeyDown={event => {
                if (fixed) return;
                if (event.key === 'Delete' || event.key === 'Backspace') {
                  event.preventDefault();
                  removeStop(stop);
                }
                if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
                  event.preventDefault();
                  const step = event.shiftKey ? .05 : .01;
                  const delta = event.key === 'ArrowRight' ? step : -step;
                  updateStop(stop.id, { position: position(stop.position + delta) });
                }
              }}
            />
          );
        })}
      </div>
      <div className="gradient-details">
        <label className="swatch">
          <input type="color" aria-label="Selected light colour" value={selected.color}
            onInput={event => updateStop(selected.id, { color: event.currentTarget.value })} />
          <span>{selected.color.toUpperCase()}</span>
        </label>
        {isEndpoint(selected) && <span>{selected.position * 100}%</span>}
      </div>
      {!isEndpoint(selected) && <SettingSlider
        spec={{ label: 'Stop position', min: .1, max: 99.9, step: .1, format: value => `${value}%` }}
        entry={{ label: 'Colour stop position in percent', unit: '%' }} value={Math.round(selected.position * 1000) / 10}
        onChange={value => updateStop(selected.id, { position: position(value / 100) })} />}
      <div className="panel-actions">
        <button type="button" onClick={addInLargestGap}>Add stop</button>
        <button type="button" disabled={isEndpoint(selected)} onClick={() => removeStop(selected)}>Remove stop</button>
      </div>
    </div>
  );
}

const bloomSliders: (SliderSpec & { key: 'bloomStrength' | 'bloomRadius' | 'bloomFalloff' | 'bloomThreshold' | 'bloomGrit' })[] = [
  { key: 'bloomStrength', label: 'Strength', min: 0, max: 2, step: .01, format: percent },
  { key: 'bloomRadius', label: 'Spread', min: 0, max: 1, step: .01, format: percent },
  { key: 'bloomFalloff', label: 'Falloff', min: 0, max: 1, step: .01, format: percent,
    help: 'Lower for a longer, softer halo.' },
  { key: 'bloomThreshold', label: 'Threshold', min: .05, max: 1.5, step: .01, format: value => value.toFixed(2) },
  { key: 'bloomGrit', label: 'Grit', min: 0, max: .8, step: .01, format: percent },
];

export function BloomControls({ settings, onChange }: {
  settings: BloomSettings;
  onChange: (patch: Partial<BloomSettings>) => void;
}) {
  return (
    <section aria-label="Bloom">
      <h2>Bloom</h2>
      {bloomSliders.filter(spec => spec.key === 'bloomStrength' || settings.bloomStrength > 0).map(spec =>
        <SettingSlider key={spec.key} spec={spec} value={settings[spec.key]} onChange={value => onChange({ [spec.key]: value })} />)}
    </section>
  );
}
