import { useRef, type ReactNode } from 'react';
import { ChladniEditor } from '../editor';
import { ChladniPlayer, type ChladniPlayerHandle } from '../player';

/** Compatibility for existing source consumers. New integrations use the explicit entries. */
export default function Chladni({ configuration, active, title }: {
  configuration?: unknown;
  active?: boolean;
  title?: ReactNode;
}) {
  const player = useRef<ChladniPlayerHandle>(null);
  if (configuration === undefined) return <ChladniEditor active={active} title={title} />;
  return <div style={{ width: '100%', height: '100%' }}
    onPointerMove={event => player.current?.movePointer(event)} onPointerLeave={() => player.current?.leavePointer()}>
    <ChladniPlayer ref={player} active={active} configuration={configuration} />
  </div>;
}
