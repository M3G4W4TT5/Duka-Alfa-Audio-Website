import type { PlateSettings } from '../plate/settings';
import { FINISHES, logoSurface, type LogoEffect, type SurfaceFinish, type SurfaceStyle, type TextureKind } from '../plate/surface-settings';
import { degrees, percent, SettingSlider } from './ControlFields';

const mm = (v: number) => `${v} mm`;
const textures: Record<TextureKind, string> = { smooth: 'Smooth', brushed: 'Brushed steel', grit: 'Fine grit', corroded: 'Corroded steel' };
const finishNames = { matte: 'Matte', satin: 'Satin metal', chrome: 'Polished chrome' };
type SettingsProps = { settings: PlateSettings; onChange: (patch: Partial<PlateSettings>) => void };

function ColourField({ label, value, change }: { label: string; value: string; change: (value: string) => void }) {
  return <div className="field-row"><span>{label}</span><div className="material-colour">
    <input type="color" aria-label={label} value={value} onChange={event => change(event.currentTarget.value)} />
    <input key={value} type="text" aria-label={label + ' hex'} defaultValue={value.toUpperCase()} maxLength={7}
      spellCheck={false} onBlur={event => {
        let hex = event.currentTarget.value.trim().replace(/^#/, '');
        if (/^[\da-f]{3}$/i.test(hex)) hex = Array.from(hex, c => c + c).join('');
        if (/^[\da-f]{6}$/i.test(hex)) change('#' + hex.toLowerCase());
        else event.currentTarget.value = value.toUpperCase();
      }} onKeyDown={event => {
        if (event.key === 'Escape') { event.stopPropagation(); event.currentTarget.value = value.toUpperCase(); event.currentTarget.blur(); }
        if (event.key === 'Enter') event.currentTarget.blur();
      }} />
  </div></div>;
}

function FinishFields({ finish, change }: { finish: SurfaceFinish; change: (value: SurfaceFinish) => void }) {
  const preset = (Object.keys(FINISHES) as (keyof typeof FINISHES)[]).find(key => {
    const f = FINISHES[key];
    return f.roughness === finish.roughness && f.metalness === finish.metalness && f.reflections === finish.reflections;
  });
  return <>
    <label className="field-row">Finish <select value={preset ?? 'custom'}
      onChange={event => change(FINISHES[event.target.value as keyof typeof FINISHES])}>
      <option value="custom" disabled>Custom</option>
      {Object.entries(finishNames).map(([key, name]) => <option key={key} value={key}>{name}</option>)}
    </select></label>
    {preset === 'chrome' && <p className="control-caption">A light neutral base colour gives bright chrome.</p>}
    <SettingSlider spec={{ label: 'Metalness', min: 0, max: 1, step: .01, format: percent }}
      value={finish.metalness} onChange={metalness => change({ ...finish, metalness })} />
    <SettingSlider spec={{ label: 'Roughness', min: .035, max: 1, step: .005, format: percent }}
      value={finish.roughness} onChange={roughness => change({ ...finish, roughness })} />
    <SettingSlider spec={{ label: 'Studio reflections', min: 0, max: 1.5, step: .01, format: percent }}
      value={finish.reflections} onChange={reflections => change({ ...finish, reflections })} />
  </>;
}

function MaterialEditor({ target, settings, onChange }: SettingsProps & { target: 'Background' | 'Logo' }) {
  const isLogo = target === 'Logo';
  const { backgroundMaterial, logoMaterial, materialLinks } = settings;
  const style = isLogo ? logoSurface(backgroundMaterial, logoMaterial, materialLinks) : backgroundMaterial;
  const texture = style.texture;
  function change(patch: Partial<SurfaceStyle>) {
    if (isLogo) onChange({ logoMaterial: { ...logoMaterial, ...patch } });
    else onChange({ backgroundMaterial: { ...backgroundMaterial, ...patch } });
  }
  function link(group: keyof SurfaceStyle) {
    if (!isLogo) return null;
    return <label className="material-inherit"><input type="checkbox" checked={materialLinks[group]}
      onChange={event => {
        const linked = event.currentTarget.checked;
        onChange({ materialLinks: { ...materialLinks, [group]: linked },
          ...(group === 'texture' && !linked ? { logoTextureAnchor: [settings.logoX, settings.logoY] as [number, number] } : {}),
          logoMaterial: linked ? logoMaterial : { ...logoMaterial, [group]: backgroundMaterial[group] } });
      }} />Use background {group}</label>;
  }
  return <details className="surface-editor" aria-label={target + ' material'}>
    <summary>{target} material</summary>
    <div className="material-group">{link('colour')}
      {(!isLogo || !materialLinks.colour) && <ColourField label={target + ' colour'} value={style.colour} change={colour => change({ colour })} />}
    </div>
    <div className="material-group">{link('finish')}
      {(!isLogo || !materialLinks.finish) && <FinishFields finish={style.finish} change={finish => change({ finish })} />}
    </div>
    <div className="material-group">{link('texture')}
      {(!isLogo || !materialLinks.texture) && <>
        <label className="field-row">Texture <select value={texture.kind}
          onChange={event => change({ texture: { ...texture, kind: event.target.value as TextureKind } })}>
          {Object.entries(textures).map(([kind, name]) => <option key={kind} value={kind}>{name}</option>)}
        </select></label>
        {texture.kind !== 'smooth' && <>
          <SettingSlider spec={{ label: 'Texture strength', min: 0, max: 1, step: .01, format: percent }}
            value={texture.strength} onChange={strength => change({ texture: { ...texture, strength } })} />
          <SettingSlider spec={{ label: 'Texture scale', min: 5, max: 180, step: 1, format: mm }}
            value={texture.scaleMm} onChange={scaleMm => change({ texture: { ...texture, scaleMm } })} />
          {texture.kind === 'brushed' && <SettingSlider spec={{ label: 'Brush direction', min: 0, max: 180, step: 1, format: degrees }}
            value={texture.angle} onChange={angle => change({ texture: { ...texture, angle } })} />}
          {texture.kind === 'corroded' && <SettingSlider spec={{ label: 'Texture colour', min: 0, max: 1, step: .01, format: percent }}
            value={texture.colourMix} onChange={colourMix => change({ texture: { ...texture, colourMix } })} />}
        </>}
      </>}
    </div>
  </details>;
}

function LogoEffects({ effect, solid, change }: { effect: LogoEffect; solid: boolean; change: (patch: Partial<LogoEffect>) => void }) {
  return <details className="surface-editor" aria-label="Logo effects">
    <summary>Logo effects{effect.kind !== 'off' && <span>{effect.kind === 'neon' ? 'Neon' : 'Colour overlay'}</span>}</summary>
    <div className="material-group">
      <label className="field-row">Effect <select value={effect.kind}
        onChange={event => change({ kind: event.target.value as LogoEffect['kind'] })}>
        <option value="off">Off</option><option value="colour">Colour overlay</option><option value="neon">Neon</option>
      </select></label>
      {effect.kind !== 'off' && <>
        <div className="drive-modes effect-coverage" role="group" aria-label="Effect coverage">
          {(['edges', 'whole'] as const).map(coverage => <button type="button" key={coverage}
            aria-pressed={effect.coverage === coverage} onClick={() => change({ coverage })}>
            {coverage === 'edges' ? 'Top edges' : 'Whole logo'}</button>)}
        </div>
        <ColourField label="Effect colour" value={effect.colour} change={colour => change({ colour })} />
        {effect.coverage === 'edges' && <SettingSlider spec={{ label: 'Edge width', min: .05, max: 1.5, step: .05, format: mm }}
          value={effect.widthMm} onChange={widthMm => change({ widthMm })} />}
        {effect.kind === 'neon' ? <><SettingSlider spec={{ label: 'Emission', min: 0, max: 12, step: .05,
          format: v => `${v}×`, help: 'Bloom sets the spread and falloff of the halo.' }}
          value={effect.emission} onChange={emission => change({ emission })} />
          {solid && <SettingSlider spec={{ label: 'Light spill', min: 0, max: 1, step: .01, format: percent,
            help: 'Light reaching the nearby sand and plate.' }}
            value={effect.spill} onChange={spill => change({ spill })} />}</> :
          <SettingSlider spec={{ label: 'Opacity', min: 0, max: 1, step: .01, format: percent }}
            value={effect.opacity} onChange={opacity => change({ opacity })} />}
      </>}
    </div>
  </details>;
}

export function SurfaceControls(props: SettingsProps) {
  return <div className="surface-editors">
    <MaterialEditor target="Background" {...props} />
    {props.settings.background === '3d' && <>
      <MaterialEditor target="Logo" {...props} />
      <LogoEffects effect={props.settings.logoEffect} solid={props.settings.reliefLighting === 'solid'}
        change={patch => props.onChange({ logoEffect: { ...props.settings.logoEffect, ...patch } })} />
    </>}
  </div>;
}
