import { useId, useRef, useState, type CSSProperties, type ReactNode, type RefObject } from 'react';
import { angleFromVector, currentLightingPreset, mapPoint, wrapDegrees } from '../plate/lighting';
import { MAX_SPOTLIGHTS, type SpotlightSettings, type StrobeSettings } from '../plate/settings';
import { maxFlashWidth, STANDARD_FLASH_LIMIT, STROBE_LIMITS } from '../plate/strobe';
import { degrees, percent, SettingSlider, type SliderSpec } from './ControlFields';

const presets = { follow: 'One light', cross: 'Two lights', three: 'Three lights', four: 'Four lights' };
export type LightingPreset = keyof typeof presets;

const lightSliders: (SliderSpec & { key: 'intensity' | 'elevation' | 'beamWidth' })[] = [
  { key: 'intensity', label: 'Intensity', min: 0, max: 3, step: .01, format: percent },
  { key: 'elevation', label: 'Elevation', min: 4, max: 60, step: .1, format: degrees },
  { key: 'beamWidth', label: 'Beam width', min: 24, max: 174, step: 1, format: degrees },
];

function tidyAngle(angle: number) { return Math.round(wrapDegrees(angle) * 10) / 10 % 360; }

function AngleSlider({ label, value, onChange }: { label: string; value: number; onChange: (angle: number) => void }) {
  return <SettingSlider spec={{ label, min: 0, max: 360, step: .1, format: degrees }}
    entry={{ label: `${label} in degrees`, unit: '°' }} value={Math.round(value * 10) / 10} onChange={onChange} />;
}

function ColourEntry({ label, color, onChange }: { label: string; color: string; onChange: (color: string) => void }) {
  return <label className="field-row"><span>{label}</span><span className="swatch">
    <input type="color" aria-label={label} value={color} onInput={event => onChange(event.currentTarget.value)} />
    <span>{color.toUpperCase()}</span>
  </span></label>;
}

interface SpotlightsProps {
  subject?: 'plate' | 'dish';
  lights: SpotlightSettings[];
  strobe: StrobeSettings;
  mapRef: RefObject<HTMLDivElement | null>;
  captureAngle: (id: number) => number | undefined;
  onChange: (id: number, patch: Partial<SpotlightSettings>) => void;
  onAdd: () => number | undefined;
  onRemove: (id: number) => void;
  onPreset: (preset: LightingPreset) => void;
  children: ReactNode;
}

export function Spotlights({ subject = 'plate', lights, strobe, mapRef, captureAngle, onChange, onAdd, onRemove, onPreset, children }: SpotlightsProps) {
  const angleReference = useId();
  const [selectedId, select] = useState(lights[0].id);
  const selected = lights.find(light => light.id === selectedId) ?? lights[0];
  const steady = selected.intensity > 0;
  const usesDirection = steady || (strobe.mode !== 'off' && strobe.strength > 0 && strobe.source === selected.id);
  const drag = useRef<{ x: number; y: number; grabX: number; grabY: number; moved: boolean }>(null);

  return (
    <section aria-label="Spotlights">
      <h2>Spotlights</h2>
      <label className="field-row"><span>Lighting preset</span>
        <select aria-label="Lighting preset" value={currentLightingPreset(lights)} onChange={event => {
          onPreset(event.currentTarget.value as LightingPreset);
          select(1);
        }}>
          <option value="custom" disabled>Custom</option>
          {Object.entries(presets).map(([key, label]) => <option key={key} value={key}>{label}</option>)}
        </select>
      </label>
      <div className="panel-actions light-picker" role="group" aria-label="Select spotlight">
        {lights.map(light => <button type="button" key={light.id} aria-pressed={selected.id === light.id}
          onClick={() => select(light.id)}>Light {light.id}</button>)}
      </div>
      {usesDirection && <div className="light-layout">
        <div className="light-compass">
          <div ref={mapRef} className="light-map" role="group" aria-label={`Spotlight orbit around the ${subject === 'plate' ? 'square plate' : 'round dish'}`}
            aria-describedby={angleReference}>
            <div className="map-plate" aria-hidden="true" />
            {lights.map(light => {
              const point = mapPoint(light.position === 'follow' ? captureAngle(light.id) ?? light.angle : light.angle);
              return <button type="button" key={light.id} className="light-marker" data-follow={light.position === 'follow'}
                aria-label={`Position of light ${light.id}`} aria-pressed={light.id === selected.id}
                style={{ '--light-x': `${point.x}%`, '--light-y': `${point.y}%`,
                  '--light-color': light.colorSource === 'fixed' ? light.color : '#cdaec9',
                } as CSSProperties}
                onClick={() => select(light.id)}
                onPointerDown={event => {
                  if (event.button !== 0 || !event.isPrimary) return;
                  select(light.id);
                  const marker = event.currentTarget.getBoundingClientRect();
                  drag.current = { x: event.clientX, y: event.clientY, moved: false,
                    grabX: event.clientX - (marker.left + marker.width / 2),
                    grabY: event.clientY - (marker.top + marker.height / 2) };
                  event.currentTarget.setPointerCapture(event.pointerId);
                }}
                onPointerMove={event => {
                  const start = drag.current;
                  if (!start || !event.currentTarget.hasPointerCapture(event.pointerId)) return;
                  if (!start.moved && Math.hypot(event.clientX - start.x, event.clientY - start.y) < 3) return;
                  start.moved = true;
                  const bounds = mapRef.current!.getBoundingClientRect();
                  const x = (event.clientX - start.grabX - bounds.left) / bounds.width - .5;
                  const y = .5 - (event.clientY - start.grabY - bounds.top) / bounds.height;
                  if (Math.hypot(x, y) < .08) return;
                  onChange(light.id, { position: 'fixed', angle: tidyAngle(angleFromVector(x, y)) });
                }}
                onLostPointerCapture={() => { drag.current = null; }}
                onKeyDown={event => {
                  const direction = ['ArrowUp', 'ArrowRight'].includes(event.key) ? 1 :
                    ['ArrowDown', 'ArrowLeft'].includes(event.key) ? -1 : 0;
                  if (!direction) return;
                  event.preventDefault();
                  select(light.id);
                  const angle = light.position === 'follow' ? captureAngle(light.id) ?? light.angle : light.angle;
                  onChange(light.id, { position: 'fixed', angle: tidyAngle(angle + direction * (event.shiftKey ? 15 : 1)) });
                }}>{light.id}</button>;
            })}
          </div>
          <small id={angleReference}>0° at top, clockwise</small>
        </div>
        <div className="light-source-fields">
          <label><span>Position</span>
            <select value={selected.position} onChange={event =>
              onChange(selected.id, { position: event.currentTarget.value as SpotlightSettings['position'] })}>
              <option value="follow">Follow pointer</option><option value="fixed">Fixed angle</option>
            </select>
          </label>
          {steady && <label><span>Colour source</span>
            <select value={selected.colorSource} onChange={event =>
              onChange(selected.id, { colorSource: event.currentTarget.value as SpotlightSettings['colorSource'] })}>
              <option value="horizontal">Horizontal gradient</option>
              <option value="vertical">Vertical gradient</option><option value="fixed">Fixed colour</option>
            </select>
          </label>}
        </div>
      </div>}
      {usesDirection && selected.position === 'fixed' && <AngleSlider label="Light angle" value={selected.angle}
        onChange={angle => onChange(selected.id, { angle })} />}
      <div className="panel-actions light-actions">
        <button type="button" disabled={lights.length >= MAX_SPOTLIGHTS} onClick={() => {
          const id = onAdd();
          if (id !== undefined) select(id);
        }}>Add light</button>
        <button type="button" disabled={lights.length === 1} onClick={() => onRemove(selected.id)}>Remove light</button>
      </div>
      {steady && (selected.colorSource === 'fixed' ? <ColourEntry label="Fixed colour" color={selected.color}
        onChange={color => onChange(selected.id, { color, linearColor: undefined })} /> : children)}
      {lightSliders.filter(spec => spec.key === 'intensity' || usesDirection).map(spec =>
        <SettingSlider key={spec.key} spec={spec} value={selected[spec.key]}
        onChange={value => onChange(selected.id, { [spec.key]: value })} />)}
    </section>
  );
}

const millis = (value: number) => `${value.toLocaleString('en')} ms`;

export function StrobeControls({ settings, lights, onChange, subject = 'plate' }: {
  subject?: 'plate' | 'dish';
  settings: StrobeSettings;
  lights: SpotlightSettings[];
  onChange: (patch: Partial<StrobeSettings>) => void;
}) {
  const heading = useId();
  return (
    <section aria-label="Strobe">
      <h2 id={heading}>Strobe</h2>
      <div className="drive-modes strobe-modes" role="group" aria-labelledby={heading}>
        {(['off', 'hold', 'automatic'] as const).map(mode => <button type="button" key={mode}
          aria-pressed={settings.mode === mode} onClick={() => onChange({ mode })}>
          {mode === 'off' ? 'Off' : mode === 'hold' ? 'Hold' : 'Automatic'}
        </button>)}
      </div>
      {settings.mode === 'hold' && <p className="control-note">Press and hold on the canvas, or hold Space with the {subject} focused.</p>}
      {settings.mode !== 'off' &&
        <SettingSlider spec={{ label: 'Peak strength', ...STROBE_LIMITS.strength, format: value => `${value}×` }}
          value={settings.strength} onChange={strength => onChange({ strength })} />}
      {settings.mode !== 'off' && settings.strength > 0 && <>
        <label className="field-row"><span>Strobe source</span>
          <select value={settings.source} onChange={event => {
            const value = event.currentTarget.value;
            onChange({ source: value === 'fixed' ? 'fixed' : Number(value) });
          }}>
            {lights.map(light => <option key={light.id} value={light.id}>Light {light.id}</option>)}
            <option value="fixed">Fixed angle</option>
          </select>
        </label>
        {settings.source === 'fixed' && <>
          <AngleSlider label="Strobe angle" value={settings.angle} onChange={angle => onChange({ angle })} />
          <small className="control-note">0° at top, clockwise</small>
        </>}
        <ColourEntry label="Flash colour" color={settings.color} onChange={color => onChange({ color })} />
        <SettingSlider spec={{ label: 'Flash rate', ...STROBE_LIMITS.rate, format: value => `${value} Hz`,
          help: `Bright flashes above ${STANDARD_FLASH_LIMIT} Hz can trigger photosensitive seizures.` }}
          value={settings.rate} onChange={rate => onChange({ rate, width: Math.min(settings.width, maxFlashWidth(rate)) })} />
        <SettingSlider spec={{ label: 'Flash width', ...STROBE_LIMITS.width, max: maxFlashWidth(settings.rate), format: millis }}
          value={settings.width} onChange={width => onChange({ width })} />
        <SettingSlider spec={{ label: 'Flashes per burst', ...STROBE_LIMITS.flashes, format: value => value ? String(value) : 'Continuous' }}
          value={settings.flashes} onChange={flashes => onChange({ flashes })} />
        {settings.flashes > 0 && <SettingSlider spec={{ label: 'Burst gap', ...STROBE_LIMITS.gap, format: millis }}
          value={settings.gap} onChange={gap => onChange({ gap })} />}
      </>}
    </section>
  );
}
