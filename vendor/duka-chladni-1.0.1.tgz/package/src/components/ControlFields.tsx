import { useId, useRef, type CSSProperties } from 'react';

export function NumericEntry({ label, value, min, max, step, commit, disabled = false }: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  commit: (value: number) => number;
  disabled?: boolean;
}) {
  return (
    <input key={value} type="number" aria-label={label} defaultValue={value} min={min} max={max} step={step}
      disabled={disabled} onBlur={event => {
        const next = event.currentTarget.valueAsNumber;
        event.currentTarget.value = String(Number.isFinite(next) && next !== value ? commit(next) : value);
      }}
      onKeyDown={event => {
        if (event.key === 'Enter') event.currentTarget.blur();
        if (event.key === 'Escape') {
          event.stopPropagation();
          event.currentTarget.value = String(value);
          event.currentTarget.blur();
        }
      }} />
  );
}

export type SliderSpec = {
  label: string;
  min: number;
  max: number;
  step: number;
  format: (value: number) => string;
  help?: string;
};

export const percent = (value: number) => `${Math.round(value * 100)}%`;
export const degrees = (value: number) => `${value}°`;

export function SettingSlider({ spec, value, onChange, entry }: {
  spec: SliderSpec;
  value: number;
  onChange: (value: number) => void;
  entry?: { label: string; unit: string };
}) {
  const id = useId();
  const helpId = `${id}-help`;
  const range = useRef<HTMLInputElement>(null);
  return (
    <div className="setting-slider">
      <label htmlFor={id}>{spec.label}</label>
      <input ref={range} id={id} type="range" min={spec.min} max={spec.max} step={spec.step} value={value}
        disabled={spec.min === spec.max}
        aria-label={spec.label} aria-valuetext={spec.format(value)} aria-describedby={spec.help ? helpId : undefined}
        style={{ '--filled': `${spec.max === spec.min ? 0 : 100 * (value - spec.min) / (spec.max - spec.min)}%` } as CSSProperties}
        onChange={event => onChange(event.currentTarget.valueAsNumber)} />
      {entry ? <span className="setting-value slider-entry">
        <NumericEntry label={entry.label} value={value} min={spec.min} max={spec.max} step={spec.step}
          commit={input => {
            // Let the range apply its own bounds and step to typed values too.
            const slider = range.current!;
            slider.valueAsNumber = input;
            const next = slider.valueAsNumber;
            onChange(next);
            return next;
          }} />{entry.unit}
      </span> : <span className="setting-value">{spec.format(value)}</span>}
      {spec.help && <small className="setting-help" id={helpId}>{spec.help}</small>}
    </div>
  );
}
