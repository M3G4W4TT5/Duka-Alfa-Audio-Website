// Trace the horizontal displacement against the signed distance field. A long
// vibrational hop must encounter the first wave even if its endpoint is in a gap.
float wallFraction(vec2 from, vec2 delta, float radius, float skin) {
  float travel = length(delta);
  if (travel < 1.e-9) return 1.;
  float t = 0.;
  for (int i = 0; i < 16; ++i) {
    float free = reliefContact(from + t * delta).x - radius;
    if (free >= (1. - t) * travel) return 1.;
    if (free <= skin) break;
    t += .92 * free / travel;
  }
  return t;
}

float surfaceHeight(vec2 contact) { return contact.x < 0. ? contact.y : 0.; }

vec4 moveOnRelief(vec4 grain, vec2 next, vec2 start, float layer, float hopHeight,
                  float roundness, bool supported) {
  float ground = surfaceHeight(start);
  float z = max(grain.z, ground);
  float vz = supported ? sqrt(2. * gravity * hopHeight) : grain.w;
  vec2 from = grain.xy;
  vec2 delta = next - from;
  float texel = reliefTexel();
  float radius = mix(.00005, .000095, roundness);
  float skin = max(.000002, .08 * texel);

  if (supported && start.x < 0. && start.x > -.015 * reliefPose.z && start.y < reliefPose.w - .000001) {
    vec2 outward = wallNormal(from);
    float slope = max(0., (reliefContact(from - outward * texel).y - start.y) / texel);
    float friction = mix(.48, .29, roundness);
    delta += outward * min(.0006, gravity * stepSeconds * stepSeconds * max(0., slope - friction) / (1. + slope * slope));
  }
  if (reliefPose.w > 0. && start.x >= 0. && start.x <= length(delta) + radius + skin) {
    if (z < start.y && start.x < radius) from += wallNormal(from) * (radius + 2. * skin - start.x);
    float t = wallFraction(from, delta, radius, skin);
    if (t < 1.) {
      vec2 contact = from + t * delta;
      float time = t * stepSeconds;
      float overLip = max(ground, z + time * (vz - .5 * gravity * time));
      if (overLip < reliefContact(contact).y - .000005) {
        vec2 n = wallNormal(contact);
        vec2 remaining = delta * (1. - t);
        remaining -= n * min(0., dot(remaining, n));
        // A second swept segment allows sliding while protecting the next curved wall.
        from = contact + n * (3. * skin);
        delta = remaining * wallFraction(from, remaining, radius, skin);
      }
    }
  }
  next = clamp(from + delta, vec2(-grainEdge), vec2(grainEdge));
  float roof = reliefPose.w > 0. ? surfaceHeight(reliefContact(next)) : 0.;
  float pile = supported ? mix(clamp(z - ground, 0., .00028), layer, .18) : layer;
  float bed = roof + pile;
  float endZ = z + stepSeconds * (vz - .5 * gravity * stepSeconds);
  float endV = vz - gravity * stepSeconds;
  if (endZ <= bed) {
    // Solve the impact time inside the step, then integrate a small inelastic rebound.
    float impact = sqrt(max(0., vz * vz + 2. * gravity * max(0., z - bed)));
    float remaining = max(0., stepSeconds - (vz + impact) / gravity);
    float rebound = impact > .15 ? impact * mix(.10, .17, roundness) : 0.;
    float bounce = remaining * (rebound - .5 * gravity * remaining);
    endZ = bed + max(0., bounce);
    endV = bounce > 0. ? rebound - gravity * remaining : 0.;
  }
  return vec4(next, endZ, endV);
}
