export const DEPTH_BINS_PER_PIXEL = 8;
const TABLE_COLUMNS = 1024;

export interface StencilSamples {
  width: number;
  height: number;
  columns: number;
  entries: Uint32Array;
  ends: Uint32Array;
}

// Sort painted cells by inward distance. A filled shape uses the whole table,
// and any outline width uses a prefix. The second channel is cumulative alpha,
// so antialiased edges and translucent artwork receive proportional coverage.
export function buildStencilSamples(pixels: Uint8ClampedArray, width: number, height: number): StencilSamples {
  const stride = width + 2;
  const vertical = new Uint32Array(stride * height);
  const bins = new Uint16Array(width * height);
  const ends = new Uint32Array(Math.ceil(Math.min(width, height) * DEPTH_BINS_PER_PIXEL / 2) + 8);
  for (let x = 0; x < width; x++) {
    let distance = 0;
    for (let y = 0; y < height; y++) {
      const cell = y * width + x;
      distance = pixels[cell * 4 + 3] ? distance + 1 : 0;
      vertical[y * stride + x + 1] = distance;
    }
    distance = 0;
    for (let y = height - 1; y >= 0; y--) {
      const i = y * stride + x + 1;
      distance = Math.min(distance + 1, vertical[i]);
      vertical[i] = distance * distance;
    }
  }
  // Horizontal lower envelope of squared-distance parabolas. The two extra
  // zero columns include the outside boundary even on a completely filled SVG.
  const sites = new Int32Array(stride), cuts = new Float64Array(stride + 1);
  for (let y = 0; y < height; y++) {
    const row = y * stride;
    let k = 0;
    sites[0] = 0;
    cuts[0] = -Infinity;
    cuts[1] = Infinity;
    for (let q = 1; q < stride; q++) {
      let cross: number;
      while (true) {
        const p = sites[k];
        cross = (vertical[row + q] - vertical[row + p] + q*q - p*p) / (2*(q-p));
        if (cross > cuts[k]) break;
        k--;
      }
      sites[++k] = q;
      cuts[k] = cross;
      cuts[k + 1] = Infinity;
    }
    k = 0;
    for (let x = 0; x < width; x++) {
      const cell = y * width + x, q = x + 1;
      if (!pixels[cell * 4 + 3]) continue;
      while (cuts[k + 1] < q) k++;
      const p = sites[k], depth = Math.sqrt((q-p)*(q-p) + vertical[row+p]) - .5;
      const bin = Math.floor(Math.max(0, depth) * DEPTH_BINS_PER_PIXEL);
      bins[cell] = bin;
      ends[bin]++;
    }
  }
  const offsets = new Uint32Array(ends.length);
  let count = 0;
  for (let i = 0; i < ends.length; i++) {
    offsets[i] = count;
    count += ends[i];
    ends[i] = count;
  }
  if (!count) throw new Error('The SVG has no visible artwork.');
  const columns = Math.min(count, TABLE_COLUMNS);
  const entries = new Uint32Array(columns * Math.ceil(count / columns) * 2);
  for (let cell = 0; cell < bins.length; cell++) {
    const alpha = pixels[cell * 4 + 3];
    if (alpha) {
      const dest = offsets[bins[cell]]++ * 2;
      entries[dest] = cell;
      entries[dest + 1] = alpha;
    }
  }
  let cumulative = 0;
  for (let i = 0; i < count; i++) {
    cumulative += entries[2*i + 1];
    entries[2*i + 1] = cumulative;
  }
  return { width, height, columns, entries, ends };
}

export function stencilCount(samples: StencilSamples, outline: boolean, weightMm: number, widthMm: number) {
  const { ends } = samples;
  const bin = Math.floor(weightMm * samples.width / widthMm * DEPTH_BINS_PER_PIXEL);
  return ends[outline ? Math.min(ends.length - 1, Math.max(4, bin)) : ends.length - 1];
}
