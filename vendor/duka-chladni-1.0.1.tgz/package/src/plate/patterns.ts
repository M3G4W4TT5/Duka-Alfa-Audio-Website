export type DriveMode = 'frequency' | 'patterns';

// Each band is a conservative detuning in Hz over which the settled figure
// remains legible. The narrow P1 transitions need especially fine control.
export const PATTERNS = [
  { name: 'Soft halo', hz: 107, bandHz: 1.25 },
  { name: 'Double ring', hz: 126, bandHz: 3 },
  { name: 'Tall oval', hz: 154, bandHz: 0.55 },
  { name: 'Bowed sides', hz: 157, bandHz: 0.22 },
  { name: 'Parallel bands', hz: 160, bandHz: 0.24 },
  { name: 'Open hourglass', hz: 175, bandHz: 0.4 },
  { name: 'Diagonal cross', hz: 181, bandHz: 0.09 },
  { name: 'Single ring', hz: 196, bandHz: 4 },
  { name: 'Rounded diamond', hz: 298, bandHz: 5 },
  { name: 'Corner arcs', hz: 365, bandHz: 10 },
  { name: 'Ring and arcs', hz: 447, bandHz: 5 },
  { name: 'Square grid', hz: 548, bandHz: 2 },
  { name: 'Edge cups', hz: 626, bandHz: 6 },
  { name: 'Cushion and ring', hz: 947, bandHz: 12 },
  { name: 'Split eye', hz: 992, bandHz: 7 },
  { name: 'Floating arcs', hz: 1014, bandHz: 3 },
  { name: 'Twin figure eights', hz: 1093, bandHz: 6 },
  { name: 'Four diamonds', hz: 1120, bandHz: 6 },
  { name: 'Ring and petals', hz: 1287.5, bandHz: 5 },
  { name: 'Nested diamond', hz: 1535, bandHz: 23 },
  { name: 'Octagonal frame', hz: 1800, bandHz: 42 },
  { name: 'Scalloped rings', hz: 2074.3, bandHz: 30 },
  { name: 'Scalloped diamond', hz: 2315, bandHz: 26 },
  { name: 'Split windows', hz: 2450, bandHz: 10 },
  { name: 'Broken spokes', hz: 2538, bandHz: 6 },
  { name: 'Diamond chains', hz: 2680, bandHz: 13 },
  { name: 'Edge lenses', hz: 2852, bandHz: 20 },
  { name: 'Window lattice', hz: 3000, bandHz: 18 },
] as const;

export const LAST_PATTERN = PATTERNS.length - 1;
const LINGER = 0.24; // Fraction of one pointer interval on either side of a stop.
const slopes = PATTERNS.map(({ hz, bandHz }, i) => {
  const below = i > 0 ? hz - PATTERNS[i - 1].hz : Infinity;
  const above = i < LAST_PATTERN ? PATTERNS[i + 1].hz - hz : Infinity;
  return Math.min(bandHz / LINGER, below / 2, above / 2);
});

// Position is measured in stops. A quintic blend joins the two local linear
// responses with matching first and second derivatives. The positive slopes
// keep even a very small mouse movement visible in the drive frequency.
export function patternFrequency(position: number): number {
  if (position <= 0) return PATTERNS[0].hz;
  if (position >= LAST_PATTERN) return PATTERNS[LAST_PATTERN].hz;
  const i = Math.floor(position);
  const t = position - i;
  const left = PATTERNS[i].hz + slopes[i] * t;
  const right = PATTERNS[i + 1].hz - slopes[i + 1] * (1 - t);
  const u = (t - LINGER) / (1 - 2 * LINGER);
  if (u <= 0) return left;
  if (u >= 1) return right;
  const blend = u ** 3 * (10 + u * (-15 + 6 * u));
  return left + blend * (right - left);
}

// Used when entering the guide mid-sweep. An exact stop stays exact so that
// a subsequent arrow key advances by one whole pattern.
export function positionForFrequency(hz: number): number {
  const upper = PATTERNS.findIndex(pattern => pattern.hz >= hz);
  if (upper < 0) return LAST_PATTERN;
  if (upper === 0 || PATTERNS[upper].hz === hz) return upper;
  let low = upper - 1, high = upper;
  for (let i = 0; i < 36; i++) {
    const mid = (low + high) / 2;
    if (patternFrequency(mid) < hz) low = mid;
    else high = mid;
  }
  return (low + high) / 2;
}

// Even regions identify a settled pattern's frequency band. An odd region
// identifies the passage from the preceding pattern to the following one.
export function patternRegion(hz: number): number {
  for (let i = 0; i < PATTERNS.length; i++) {
    const distance = hz - PATTERNS[i].hz;
    const halfBand = slopes[i] * LINGER;
    if (distance < -halfBand) return Math.max(0, 2 * i - 1);
    if (distance <= halfBand) return 2 * i;
  }
  return LAST_PATTERN * 2;
}
