uniform vec3 surfaceColour;
uniform vec3 surfaceFinish; // metalness, roughness, studio reflection strength
uniform vec4 surfaceTexture; // family, strength, repeats per metre, scanned colour mix
uniform vec2 surfaceBrush;
uniform vec2 surfaceOrigin;
uniform sampler2D detailMap;
uniform sampler2D scannedColour;
uniform float physicalWeight;

struct Surface {
  vec3 colour;
  vec3 n;
  vec3 tangent;
  float metal, rough, anisotropy;
};

Surface readSurface(vec3 p, vec3 n, vec3 geometryNormal) {
  Surface s = Surface(surfaceColour, n, vec3(1., 0., 0.), surfaceFinish.x, surfaceFinish.y, 0.);
  // Project the cap in plate coordinates. The upright faces have their own
  // plane, so their physical grain size survives independent relief-height edits.
  vec3 t = vec3(1., 0., 0.), b = vec3(0., 1., 0.);
  if (abs(geometryNormal.z) < .5) {
    b = vec3(0., 0., 1.);
    // A fixed projection on each dominant axis avoids swimming around curved sides.
    t = abs(geometryNormal.x) > abs(geometryNormal.y) ? vec3(0., sign(geometryNormal.x), 0.)
      : vec3(-sign(geometryNormal.y), 0., 0.);
  }
  vec3 along = t * surfaceBrush.x + b * surfaceBrush.y;
  vec3 across = -t * surfaceBrush.y + b * surfaceBrush.x;
  if (surfaceTexture.x > .5) {
    vec3 local = p - vec3(surfaceOrigin, 0.);
    vec2 uv = vec2(dot(local, along), dot(local, across)) * surfaceTexture.z;
    bool brushed = surfaceTexture.x < 1.5, rust = surfaceTexture.x > 2.5;
    // The scan's strokes run along V. Orient and elongate them along the
    // selected brush axis, transforming the normal slopes by the same mapping.
    if (brushed) uv = vec2(-uv.y, .33 * uv.x);
    vec4 data = texture2D(detailMap, uv);
    float strength = surfaceTexture.y;
    vec2 bump = data.rg * 2. - 1.;
    if (brushed) bump = vec2(.33 * bump.y, -bump.x);
    vec3 slope = (along * bump.x + across * bump.y) * (brushed ? 3. : (rust ? 3. : 1.1));
    s.n = normalize(n + strength * (slope - n * dot(slope, n)));
    float meanRoughness = brushed ? .088 : (rust ? .658 : .764);
    float bodyRoughness = brushed ? max(s.rough, mix(s.rough, .24, strength)) : s.rough;
    s.rough = clamp(bodyRoughness + strength * (.7 * (data.b - meanRoughness) + (brushed ? 0. : .07)), .035, 1.);
    float metalMask = clamp((data.a * 255. - 128.) / 127., 0., 1.);
    s.metal *= mix(1., metalMask, strength);
    s.anisotropy = brushed ? .85 * strength : 0.;
    if (rust && surfaceTexture.w > 0.) s.colour = mix(s.colour, texture2D(scannedColour, uv).rgb, surfaceTexture.w * strength);
  }
  // Project the brushing axis onto the perturbed surface for the anisotropic lobe.
  vec3 projected = along - s.n * dot(s.n, along);
  s.tangent = dot(projected, projected) > 1.e-6 ? normalize(projected) : normalize(cross(across, s.n));
  return s;
}

vec3 surfaceFresnel(vec3 f0, float cosine) {
  return f0 + (1. - f0) * pow(clamp(1. - cosine, 0., 1.), 5.);
}

vec3 directReflection(Surface s, vec3 lamp, vec2 beam, vec3 p) {
  vec3 ray = lamp - p;
  float d2 = max(dot(ray, ray), 1.e-7);
  vec3 l = ray * inversesqrt(d2), v = vec3(0., 0., 1.);
  float nl = dot(s.n, l);
  if (nl <= 0.) return vec3(0.);
  vec3 h = normalize(l + v), b = cross(s.n, s.tangent);
  float nv = max(s.n.z, .001), nh = max(dot(s.n, h), 0.);
  float aspect = sqrt(1. - .9 * s.anisotropy);
  float alpha = max(.003, s.rough * s.rough);
  vec2 axes = vec2(alpha * aspect, alpha / aspect);
  vec2 hxy = vec2(dot(h, s.tangent), dot(h, b)) / axes;
  float denom = dot(hxy, hxy) + nh * nh;
  float distribution = 1. / max(1.e-8, 3.14159 * axes.x * axes.y * denom * denom);
  vec2 vl = axes * vec2(s.tangent.z, b.z);
  vec2 ll = axes * vec2(dot(s.tangent, l), dot(b, l));
  float visibility = .5 / max(.0001, nl * length(vec3(vl, nv)) + nv * length(vec3(ll, nl)));
  vec3 fresnel = surfaceFresnel(mix(vec3(.04), s.colour, s.metal), h.z);
  vec3 diffuse = (1. - fresnel) * (1. - s.metal) * s.colour / 3.14159;
  float cone = smoothstep(beam.x, beam.y, dot(normalize(lamp), l));
  return (diffuse + fresnel * distribution * visibility) * nl * cone * (.325 / d2);
}

float studioCard(vec2 p, vec2 centre, vec2 axis, vec2 halfSize, vec2 blur) {
  vec2 d = p - centre;
  vec2 local = abs(vec2(dot(d, axis), dot(d, vec2(-axis.y, axis.x))));
  vec2 cover = 1. - smoothstep(halfSize - blur, halfSize + blur, local);
  return cover.x * cover.y * halfSize.x / (halfSize.x + .55 * blur.x);
}

vec2 studioBlur(vec2 cardAxis, vec2 tangent, float aspect, float scatter) {
  vec2 along = vec2(dot(tangent, cardAxis), dot(tangent, vec2(-cardAxis.y, cardAxis.x)));
  vec2 cos2 = clamp(along * along, 0., 1.);
  return scatter * sqrt(cos2 * (aspect * aspect) + (1. - cos2) / (aspect * aspect));
}

vec3 studioReflection(Surface s, vec3 p) {
  vec3 r = reflect(vec3(0., 0., -1.), s.n);
  // Intersect the reflected ray with finite overhead softboxes. Orthographic
  // top faces all have the same view direction, but see different parts of a card.
  vec2 hit = p.xy + r.xy * (max(0., .14 - p.z) / max(.075, r.z));
  float scatter = .0015 + .12 * s.rough * s.rough;
  vec2 a = vec2(.92, .392), b = vec2(.78, -.626);
  vec2 axis = s.tangent.xy;
  float aspect = sqrt(1. - .9 * s.anisotropy);
  vec2 blurA = studioBlur(a, axis, aspect, scatter);
  vec2 blurB = studioBlur(b, axis, aspect, scatter);
  float cards = 1.5 * studioCard(hit, vec2(-.04,.024), a, vec2(.012,.112), blurA)
              + .82 * studioCard(hit, vec2(.043,-.015), b, vec2(.018,.105), blurB);
  float studio = .065 + max(0.,r.z) * (.095 + cards);
  return surfaceFresnel(mix(vec3(.04),s.colour,s.metal), max(s.n.z,0.))
    * studio * surfaceFinish.z * (1. - .36 * s.rough);
}
