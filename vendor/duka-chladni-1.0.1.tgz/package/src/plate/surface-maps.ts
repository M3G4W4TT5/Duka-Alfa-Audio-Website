import * as THREE from 'three';
import brushed from '../assets/surfaces/brushed.webp?url';
import grit from '../assets/surfaces/grit.webp?url';
import corroded from '../assets/surfaces/corroded.webp?url';
import corrosionColour from '../assets/surfaces/corrosion-colour.webp?url';
import { DEFAULT_SURFACE, FINISHES, logoSurface, type SurfaceStyle } from './surface-settings';
import type { PlateSettings } from './settings';

const files = { brushed, grit, corroded, corrosionColour };
type MapName = keyof typeof files;
const kinds = { smooth: 0, brushed: 1, grit: 2, corroded: 3 };

function surfaceUniforms() {
  return {
    surfaceColour: { value: new THREE.Color(DEFAULT_SURFACE.colour) },
    surfaceFinish: { value: new THREE.Vector3() },
    surfaceTexture: { value: new THREE.Vector4() },
    surfaceBrush: { value: new THREE.Vector2(1, 0) },
    surfaceOrigin: { value: new THREE.Vector2() },
    detailMap: { value: null as THREE.Texture | null },
    scannedColour: { value: null as THREE.Texture | null },
    physicalWeight: { value: 0 },
  };
}

export class SurfaceMaterials {
  readonly background = surfaceUniforms();
  readonly logo = surfaceUniforms();
  private readonly maps = new Map<MapName, THREE.Texture | null>();
  private readonly loader = new THREE.TextureLoader();
  private settings?: PlateSettings;
  private disposed = false;

  private map(name: MapName) {
    if (this.maps.has(name)) return this.maps.get(name) ?? null;
    this.maps.set(name, null);
    this.loader.load(files[name], texture => {
      if (this.disposed) { texture.dispose(); return; }
      texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
      texture.colorSpace = name === 'corrosionColour' ? THREE.SRGBColorSpace : THREE.NoColorSpace;
      texture.anisotropy = 2;
      this.maps.set(name, texture);
      // Rebind only the current choices when an earlier selection finishes loading.
      if (this.settings) this.configure(this.settings);
    }, undefined, () => {
      this.maps.delete(name);
      if (!this.disposed) console.warn('Surface texture unavailable:', name);
    });
    return null;
  }

  private bind(u: ReturnType<typeof surfaceUniforms>, s: SurfaceStyle) {
    const f = s.finish, t = s.texture;
    const detail = t.kind !== 'smooth' && t.strength > 0 ? this.map(t.kind) : null;
    const colour = t.kind === 'corroded' && t.colourMix > 0 && t.strength > 0 ? this.map('corrosionColour') : null;
    const angle = t.kind === 'brushed' ? THREE.MathUtils.degToRad(t.angle) : 0;
    u.surfaceColour.value.set(s.colour);
    u.surfaceFinish.value.set(f.metalness, f.roughness, f.reflections);
    u.surfaceTexture.value.set(detail ? kinds[t.kind] : 0, t.strength, 1000 / t.scaleMm, colour ? t.colourMix : 0);
    u.surfaceBrush.value.set(Math.cos(angle), Math.sin(angle));
    u.detailMap.value = detail;
    u.scannedColour.value = colour;
    // Retain the calibrated matte baseline and ease continuously into the reflective finish.
    u.physicalWeight.value = Math.min(1, f.metalness + 4 * Math.abs(f.roughness - FINISHES.matte.roughness)
      + 2 * Math.abs(f.reflections - FINISHES.matte.reflections) + (detail ? t.strength : 0));
  }

  configure(settings: PlateSettings) {
    this.settings = settings;
    this.bind(this.background, settings.backgroundMaterial);
    if (settings.background === '3d') {
      this.bind(this.logo, logoSurface(settings.backgroundMaterial, settings.logoMaterial, settings.materialLinks));
      const [ax, ay] = settings.logoTextureAnchor;
      if (settings.materialLinks.texture) this.logo.surfaceOrigin.value.set(0, 0);
      else this.logo.surfaceOrigin.value.set((settings.logoX - ax) / 1000, (settings.logoY - ay) / 1000);
    }
  }

  dispose() {
    this.disposed = true;
    for (const texture of this.maps.values()) texture?.dispose();
    this.maps.clear();
  }
}
