import { FIT_SPAN, transformCrop, type Crop, type Point } from './framing';

export function bindFrameGestures(canvas: HTMLCanvasElement, signal: AbortSignal, active: () => boolean, editing: () => boolean,
  current: () => Crop, change: (crop: Crop) => void, reset: () => void) {
  const contacts = new Map<number, Point>();
  const uv = (x: number, y: number): Point => {
    const r = canvas.getBoundingClientRect();
    return { x: (x - r.left) / r.width, y: (y - r.top) / r.height };
  };
  function gesture() {
    const [a, b] = contacts.values();
    if (!b) return { mid: uv(a.x, a.y), distance: 0 };
    return { mid: uv((a.x + b.x) / 2, (a.y + b.y) / 2), distance: Math.hypot(a.x - b.x, a.y - b.y) };
  }
  canvas.addEventListener('wheel', event => {
    if (!active() || !event.deltaY || (event.ctrlKey && !editing())) return;
    event.preventDefault();
    const unit = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? canvas.clientHeight : 1;
    const point = uv(event.clientX, event.clientY);
    const next = transformCrop(current(), Math.exp(Math.max(-1, Math.min(1, event.deltaY * unit * .0017))), point, point);
    if (!editing() && Math.min(next.width, next.height) >= FIT_SPAN - 1e-8) reset();
    else change(next);
  }, { passive: false, signal });
  canvas.addEventListener('pointerdown', event => {
    if (!active() || !editing() || event.button !== 0 || contacts.size >= 2) return;
    contacts.set(event.pointerId, { x: event.clientX, y: event.clientY });
    canvas.setPointerCapture(event.pointerId);
  }, { signal });
  canvas.addEventListener('pointermove', event => {
    if (!active() || !editing() || !contacts.has(event.pointerId)) return;
    const before = gesture();
    contacts.set(event.pointerId, { x: event.clientX, y: event.clientY });
    const after = gesture();
    const scale = after.distance && before.distance ? before.distance / after.distance : 1;
    change(transformCrop(current(), scale, before.mid, after.mid));
  }, { signal });
  const end = (event: PointerEvent) => { contacts.delete(event.pointerId); };
  for (const type of ['pointerup', 'pointercancel', 'lostpointercapture'] as const)
    canvas.addEventListener(type, end, { signal });
  return () => {
    for (const id of contacts.keys()) if (canvas.hasPointerCapture(id)) canvas.releasePointerCapture(id);
    contacts.clear();
  };
}
