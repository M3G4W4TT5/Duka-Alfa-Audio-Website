export const STENCIL_RETURN_SECONDS = 3;

// Complement of smoothstep, factored to retain precision near the endpoint.
function remaining(phase: number) {
  return (1 - phase) ** 2 * (1 + 2 * phase);
}

export function advanceStencilReturn(previous: number, speed: number, seconds: number) {
  const progress = Math.min(1, previous + seconds * speed / STENCIL_RETURN_SECONDS);
  // Apply just this step's share of the distance still to go. Changing speed
  // then needs neither a new starting snapshot nor a correction to grain XY.
  const blend = previous >= 1 ? 0 : 1 - remaining(progress) / remaining(previous);
  return { progress, blend };
}
