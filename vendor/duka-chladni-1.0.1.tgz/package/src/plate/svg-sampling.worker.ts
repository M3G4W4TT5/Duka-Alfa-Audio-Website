import { buildStencilSamples } from './svg-sampling';

self.onmessage = ({ data }: MessageEvent<ImageData>) => {
  try {
    const result = buildStencilSamples(data.data, data.width, data.height);
    self.postMessage(result, { transfer: [result.entries.buffer, result.ends.buffer] });
  } catch (error) {
    self.postMessage({ error: error instanceof Error ? error.message : 'Could not prepare the stencil.' });
  }
};
