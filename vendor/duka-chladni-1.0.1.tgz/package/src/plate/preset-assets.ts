import type { Configuration } from './configuration';
import { loadSvgImage } from './svg-image';

export async function loadPresetSvg({ assets, settings }: Configuration, signal: AbortSignal) {
  const asset = assets.svg;
  const file = asset.type === 'inline' ? new File([asset.source], asset.filename, { type: 'image/svg+xml' }) : null;
  const image = file || settings.svg.enabled ? await loadSvgImage(file, signal) : null;
  signal.throwIfAborted();
  return { file, image };
}
