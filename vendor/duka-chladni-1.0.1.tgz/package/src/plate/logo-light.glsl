uniform vec4 logoEffect; // Kind, whole/edges, inward rim width (m), opacity or radiance.
uniform vec3 effectColour;
uniform float spillStrength;

// Local approximation of a luminous strip along the closest wall. Whole-logo
// coverage also sees the emitting side and the solid angle of the upper cap.
vec3 logoIrradiance(vec3 p, vec3 n) {
  if (spillStrength <= 0. || reliefPose.w <= 0.) return vec3(0.);
  // Stay inside the contact atlas's 64-texel distance band at every logo size.
  float reach = min(.018, 56. * reliefTexel());
  vec2 offset = abs(p.xy - reliefPose.xy);
  if (max(offset.x, offset.y) > .5 * reliefPose.z + reach || p.z > reliefPose.w + reach) return vec3(0.);
  vec2 contact = reliefContact(p.xy);
  float d = contact.x, height = contact.y;
  bool whole = logoEffect.y > .5;
  float gain = 0.;
  if (whole && p.z >= height) {
    // A receiver facing away from the upper cap sees progressively less of it.
    float z = max(reliefTexel(), p.z - height);
    float capFraction = .5 - .5 * d * inversesqrt(d*d + z*z);
    float range = 1. - smoothstep(.5 * reach, reach, length(vec2(max(0., d), z)));
    gain = range * capFraction * .5 * (1. - n.z);
  }
  float dz = (whole ? .5 * height : height) - p.z;
  float distanceToStrip = length(vec2(d, dz));
  if (distanceToStrip < reach && (!whole || d >= 0.)) {
    // Integrating a nearby line source gives a 1/r cross-section. Its finite
    // width regularizes contact; the receiver cosine gives floor spill a soft tail.
    float radius = .5 * (whole ? height : logoEffect.z);
    float inverseR = inversesqrt(max(1.e-12, distanceToStrip * distanceToStrip + radius * radius));
    float horizontal = 0.;
    if (dot(n.xy, n.xy) > 1.e-5) horizontal = -d * dot(n.xy, wallNormal(p.xy));
    float receiver = max(0., (horizontal + dz * n.z) * inverseR);
    float facing = whole ? max(d, 0.) * inverseR : 1.;
    gain += radius * inverseR * receiver * facing * (1. - smoothstep(.5 * reach, reach, distanceToStrip));
  }
  return effectColour * (spillStrength * gain);
}
