import { RadialBloomPass } from './bloom';
import { DEFAULT_SETTINGS } from './settings';

const screenNoise = /* glsl */ `
  float noise(vec2 pixel) {
    return fract(52.9829189 * fract(dot(pixel, vec2(.06711056, .00583715))));
  }

  float fineGrain(vec2 pixel) {
    return noise(pixel) + noise(pixel.yx + vec2(91., 47.)) - 1.;
  }
`;

export function createBloom() {
  const bloom = new RadialBloomPass();
  // The final additive blit sees only the blurred highlights. Applying grit
  // here keeps it at screen-pixel scale.
  bloom.blendMaterial.fragmentShader = /* glsl */ `
    uniform sampler2D tDiffuse;
    uniform float opacity;
    uniform float gritStrength;
    varying vec2 vUv;
    ${screenNoise}

    void main() {
      vec4 glow = texture2D(tDiffuse, vUv);
      vec2 pixel = floor(gl_FragCoord.xy);
      float grit = fineGrain(pixel + vec2(17., 83.));
      glow.rgb *= 1. + gritStrength * grit;
      gl_FragColor = opacity * glow;
    }
  `;
  bloom.blendMaterial.uniforms.gritStrength = { value: DEFAULT_SETTINGS.bloomGrit };
  return bloom;
}

export const finishFragment = /* glsl */ `
  uniform sampler2D tDiffuse;
  varying vec2 vUv;
  ${screenNoise}

  void main() {
    gl_FragColor = texture2D(tDiffuse, vUv);
    #include <colorspace_fragment>

    // A fine, monochrome grain sits at the final screen resolution, after bloom.
    // Keep the sample fixed in time so a stationary image has no grain flicker.
    vec2 pixel = floor(gl_FragCoord.xy);
    float grain = fineGrain(pixel);
    float luminance = dot(gl_FragColor.rgb, vec3(.2126, .7152, .0722));
    float strength = mix(.004, .010, smoothstep(.05, .35, luminance));
    strength *= 1. - .72 * smoothstep(.4, 1., luminance);
    gl_FragColor.rgb = clamp(gl_FragColor.rgb + vec3(grain * strength), 0., 1.);
  }
`;
