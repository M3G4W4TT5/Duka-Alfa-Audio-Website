// Reconstruct the signed harmonic response and its two derivatives at the grain.
// One texel holds two complex channels so the model transition uses the same path.
uniform sampler2D wave;
void cubicWeights(float t, out vec4 w, out vec4 dw) {
  float t2 = t*t, t3 = t2*t;
  w = .5 * vec4(-t + 2.*t2 - t3, 2. - 5.*t2 + 3.*t3,
                 t + 4.*t2 - 3.*t3, -t2 + t3);
  dw = .5 * vec4(-1. + 4.*t - 3.*t2, -10.*t + 9.*t2,
                  1. + 8.*t - 9.*t2, -2.*t + 3.*t2);
}

vec2 nodalDrift(vec2 position, out float gamma) {
  vec2 grid = min(abs(position) / cellMetres, vec2(halfCells));
  ivec2 cell = min(ivec2(grid), ivec2(halfCells - 1));
  vec2 t = grid - vec2(cell);
  vec4 wx, wy, dwx, dwy;
  cubicWeights(t.x, wx, dwx);
  cubicWeights(t.y, wy, dwy);
  vec4 a = vec4(0.), ax = vec4(0.), ay = vec4(0.);
  for (int y = 0; y < 4; y++) {
    ivec2 p = cell + ivec2(0, y);
    vec4 s0 = texelFetch(wave, p, 0);
    vec4 s1 = texelFetch(wave, p + ivec2(1, 0), 0);
    vec4 s2 = texelFetch(wave, p + ivec2(2, 0), 0);
    vec4 s3 = texelFetch(wave, p + ivec2(3, 0), 0);
    vec4 row = wx.x*s0 + wx.y*s1 + wx.z*s2 + wx.w*s3;
    a += wy[y] * row;
    ax += wy[y] * (dwx.x*s0 + dwx.y*s1 + dwx.z*s2 + dwx.w*s3);
    ay += dwy[y] * row;
  }
  ax *= sign(position.x);
  ay *= sign(position.y);
  gamma = length(a);
  vec2 energyGradient = vec2(dot(a,ax), dot(a,ay));
  float slope = length(energyGradient);
  vec2 normal = energyGradient / max(slope, 1.e-10);
  // The existing mobility uses the change in gamma across two field cells.
  float delta = 2. * slope / max(gamma, 1.e-8);
  float speed = .026 * gamma / (.24 + gamma) * delta / (.22 + delta);
  // The closest minimum of |a - d*da/dn|² is d=(a·da/dn)/|da/dn|².
  // Bound a downhill step near a narrow trough. Hops and contacts can cross it.
  vec4 alongNormal = normal.x*ax + normal.y*ay;
  float distanceMetres = cellMetres * slope / max(dot(alongNormal, alongNormal), 1.e-12);
  return -normal * min(speed, .8 * distanceMetres / stepSeconds);
}
