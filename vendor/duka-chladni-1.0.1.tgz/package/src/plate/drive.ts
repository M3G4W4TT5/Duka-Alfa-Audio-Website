import { LAST_PATTERN, patternFrequency, positionForFrequency, type DriveMode } from './patterns.ts';
import { clamp, type Axis } from './settings.ts';

type DriveSettings = { mode: DriveMode; minHz: number; maxHz: number };
const HZ_RESPONSE = 40;
const GUIDE_RESPONSE = 16;
const MAX_STOPS_PER_SECOND = 9;

export class PlateDrive {
  hz: number;
  targetHz: number;
  guidePosition = 0;
  guideTarget = 0;
  directHeight = 0.5; // Normalized height above the bottom of the viewport.
  private travelPosition = 0;
  private entryOffsetHz = 0;
  private filteredHz: number;
  private options: DriveSettings;

  constructor(options: DriveSettings, startHz: number) {
    this.options = options;
    this.hz = this.filteredHz = startHz;
    this.targetHz = startHz;
    this.setDirectFrequency(startHz);
    if (options.mode === 'patterns') this.enterGuide();
  }

  get position() {
    return this.options.mode === 'patterns' ? this.guideTarget / LAST_PATTERN : this.directHeight;
  }

  snapshot() {
    const { hz, targetHz, directHeight, guidePosition, guideTarget, travelPosition, entryOffsetHz, filteredHz } = this;
    return { hz, targetHz, directHeight, guidePosition, guideTarget, travelPosition, entryOffsetHz, filteredHz };
  }

  restore(state: ReturnType<PlateDrive['snapshot']>) {
    this.hz = state.hz;
    this.targetHz = state.targetHz;
    this.directHeight = state.directHeight;
    this.guidePosition = state.guidePosition;
    this.guideTarget = state.guideTarget;
    this.travelPosition = state.travelPosition;
    this.entryOffsetHz = state.entryOffsetHz;
    this.filteredHz = state.filteredHz;
  }

  configure(next: DriveSettings) {
    const previous = this.options;
    this.options = next;
    if (next.mode !== previous.mode) {
      this.filteredHz = this.hz;
      if (next.mode === 'patterns') {
        this.enterGuide();
      } else {
        this.setDirectFrequency(this.hz);
      }
    } else if (next.mode === 'frequency' && (next.minHz !== previous.minHz || next.maxHz !== previous.maxHz)) {
      this.setHeight(this.directHeight);
    }
  }

  setHeight(height: number) {
    const value = clamp(height, 0, 1);
    if (this.options.mode === 'patterns') {
      this.guideTarget = value * LAST_PATTERN;
    } else {
      this.directHeight = value;
      this.targetHz = this.options.minHz + value * (this.options.maxHz - this.options.minHz);
    }
  }

  selectPattern(index: number) {
    if (this.options.mode === 'patterns') this.guideTarget = clamp(index, 0, LAST_PATTERN);
  }

  nudge(direction: 1 | -1) {
    if (this.options.mode === 'patterns') {
      const next = direction > 0 ? Math.floor(this.guideTarget + 1e-8) + 1 : Math.ceil(this.guideTarget - 1e-8) - 1;
      this.selectPattern(next);
    } else {
      this.setDirectFrequency(Math.round(this.targetHz + direction));
    }
  }

  advance(elapsed: number) {
    if (this.options.mode === 'patterns') {
      // Travel in catalogue order even on a full-height pointer jump or a
      // distant thumbnail click. The existing grains keep moving all the way.
      const gap = this.guideTarget - this.travelPosition;
      const limit = MAX_STOPS_PER_SECOND * elapsed;
      this.travelPosition += clamp(gap * -Math.expm1(-elapsed * GUIDE_RESPONSE), -limit, limit);
      if (Math.abs(this.guideTarget - this.travelPosition) < 1e-8) this.travelPosition = this.guideTarget;
      // Ease position before mapping it. Filtering Hz across a large gap
      // would wash out the next stop's narrow frequency band during a swipe.
      this.guidePosition += (this.travelPosition - this.guidePosition) * -Math.expm1(-elapsed * HZ_RESPONSE);
      if (Math.abs(this.guideTarget - this.guidePosition) < 1e-8) this.guidePosition = this.guideTarget;
      this.targetHz = patternFrequency(this.travelPosition);
      this.entryOffsetHz *= Math.exp(-elapsed * GUIDE_RESPONSE);
      if (Math.abs(this.entryOffsetHz) < 0.00001) this.entryOffsetHz = 0;
      this.hz = patternFrequency(this.guidePosition) + this.entryOffsetHz;
      return;
    }

    // Exact update for two cascaded low-pass stages at a fixed input.
    const damping = elapsed * HZ_RESPONSE;
    const decay = Math.exp(-damping);
    const inputError = this.filteredHz - this.targetHz;
    this.hz = this.targetHz + (this.hz - this.targetHz + inputError * damping) * decay;
    this.filteredHz = this.targetHz + inputError * decay;
    if (Math.abs(this.hz - this.targetHz) < 0.00001 && Math.abs(this.filteredHz - this.targetHz) < 0.00001) {
      this.hz = this.filteredHz = this.targetHz;
    }
  }

  private enterGuide() {
    this.travelPosition = this.guidePosition = this.guideTarget = positionForFrequency(this.hz);
    this.targetHz = patternFrequency(this.guidePosition);
    this.entryOffsetHz = this.hz - this.targetHz;
  }

  private setDirectFrequency(hz: number) {
    const { minHz, maxHz } = this.options;
    this.targetHz = clamp(hz, minHz, maxHz);
    if (maxHz > minHz) this.directHeight = (this.targetHz - minHz) / (maxHz - minHz);
  }
}

export class DrivePointer {
  private last: { x: number; y: number } | undefined;
  private holdOnEntry = false;

  hold() { this.holdOnEntry = true; }

  sample(axis: Axis | null, x: number, y: number, width: number, height: number, touch = false) {
    const axisChanged = !this.last || (axis === 'horizontal' ? x !== this.last.x : y !== this.last.y);
    this.last = { x, y };
    const canTune = touch || (!this.holdOnEntry && axisChanged);
    this.holdOnEntry = false;
    if (axis === null || !canTune) return undefined;
    return axis === 'horizontal' ? x / Math.max(1, width - 1) : 1 - y / Math.max(1, height - 1);
  }
}
