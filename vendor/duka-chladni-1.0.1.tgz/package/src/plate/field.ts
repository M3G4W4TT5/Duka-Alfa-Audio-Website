import { bend, LEGACY_END_HZ, sampleLegacy } from './legacy.ts';
import { PhysicalResponse } from './physical.ts';

export { MAX_FREQUENCY } from './physical.ts';
export const SIDE = 0.18;
export const HALF = SIDE / 2;
export const GRAVITY = 9.81;
export const MIN_FREQUENCY = 0;
export const START_FREQUENCY = 126;
export const FIELD_SIZE = 113;
export const HALF_CELLS = (FIELD_SIZE - 1) / 2;
const QUADRANT_SIZE = HALF_CELLS + 1;
// One ghost sample per side gives the four-point cubic stencil valid edge slopes.
export const WAVE_SIZE = QUADRANT_SIZE + 2;

const PHYSICAL_START_HZ = 260;
const ENDPOINT_STEP_HZ = 0.05;
const TAIL_DECAY_HZ = 5;
const samples = () => new Float64Array(QUADRANT_SIZE ** 2);
const legacyAxis = Float64Array.from({ length: QUADRANT_SIZE }, (_, i) => bend(i / HALF_CELLS));

function legacyTail() {
  const real = samples(), imaginary = samples(), realSlope = samples(), imaginarySlope = samples();
  sampleLegacy(legacyAxis, LEGACY_END_HZ, real, imaginary);
  sampleLegacy(legacyAxis, LEGACY_END_HZ - ENDPOINT_STEP_HZ, realSlope, imaginarySlope);
  for (let i = 0; i < real.length; i++) {
    realSlope[i] = (real[i] - realSlope[i]) / ENDPOINT_STEP_HZ;
    imaginarySlope[i] = (imaginary[i] - imaginarySlope[i]) / ENDPOINT_STEP_HZ;
  }
  return { real, imaginary, realSlope, imaginarySlope };
}

const tail = legacyTail();

// Reflect across the centre axes. At the free edges, continue the one-sided
// quadratic through the last three samples so interpolation permits a nonzero slope.
function padWave(wave: Float32Array) {
  const stride = 4 * WAVE_SIZE;
  for (let y = 1; y <= QUADRANT_SIZE; y++) {
    const left = y * stride;
    const right = left + stride - 4;
    for (let c = 0; c < 4; c++) {
      wave[left + c] = wave[left + 8 + c];
      wave[right + c] = 3 * (wave[right - 4 + c] - wave[right - 8 + c]) + wave[right - 12 + c];
    }
  }
  const top = wave.length - stride;
  for (let i = 0; i < stride; i++) {
    wave[i] = wave[2 * stride + i];
    wave[top + i] = 3 * (wave[top - stride + i] - wave[top - 2 * stride + i]) + wave[top - 3 * stride + i];
  }
}

function cubicWeights(t: number, w: Float64Array) {
  const t2 = t * t, t3 = t2 * t;
  w[0] = (-t + 2 * t2 - t3) / 2;
  w[1] = 1 + (-5 * t2 + 3 * t3) / 2;
  w[2] = (t + 4 * t2 - 3 * t3) / 2;
  w[3] = (-t2 + t3) / 2;
}

export class VibrationField {
  // Signed peak acceleration in g. RG holds the active complex response.
  // BA holds the independent legacy tail only during the energy crossfade.
  readonly wave = new Float32Array(WAVE_SIZE ** 2 * 4);
  private readonly legacyReal = samples();
  private readonly legacyImaginary = samples();
  private readonly physical = new PhysicalResponse(QUADRANT_SIZE);
  private readonly weightsX = new Float64Array(4);
  private readonly weightsY = new Float64Array(4);
  private readonly sampled = new Float64Array(4);
  frequency = NaN;
  centreMicrometres = 0;

  update(frequency: number) {
    if (this.frequency === frequency) return;
    this.frequency = frequency;
    if (frequency === 0) {
      this.wave.fill(0);
      this.centreMicrometres = 0;
      return;
    }

    const omega = 2 * Math.PI * frequency;
    const gammaScale = omega * omega / GRAVITY;
    let real: Float64Array = this.legacyReal;
    let imaginary: Float64Array = this.legacyImaginary;
    let mix = 1, tailLength = 0;
    if (frequency <= LEGACY_END_HZ) {
      sampleLegacy(legacyAxis, frequency, real, imaginary);
    } else {
      this.physical.update(omega, omega * omega);
      real = this.physical.real;
      imaginary = this.physical.imaginary;
      if (frequency < PHYSICAL_START_HZ) {
        const over = frequency - LEGACY_END_HZ;
        const t = over / (PHYSICAL_START_HZ - LEGACY_END_HZ);
        mix = t * t * (3 - 2 * t);
        tailLength = -TAIL_DECAY_HZ * Math.expm1(-over / TAIL_DECAY_HZ);
      }
    }
    const gain = gammaScale * Math.sqrt(mix);
    const tailGain = gammaScale * Math.sqrt(1 - mix);
    for (let y = 0; y < QUADRANT_SIZE; y++) {
      let out = 4 * ((y + 1) * WAVE_SIZE + 1);
      for (let x = 0; x < QUADRANT_SIZE; x++, out += 4) {
        const i = y * QUADRANT_SIZE + x;
        this.wave[out] = gain * real[i];
        this.wave[out + 1] = gain * imaginary[i];
        this.wave[out + 2] = tailGain * (tail.real[i] + tailLength * tail.realSlope[i]);
        this.wave[out + 3] = tailGain * (tail.imaginary[i] + tailLength * tail.imaginarySlope[i]);
      }
    }
    padWave(this.wave);
    const centre = 4 * (WAVE_SIZE + 1);
    this.centreMicrometres = Math.hypot(this.wave[centre], this.wave[centre + 1],
      this.wave[centre + 2], this.wave[centre + 3]) * 1e6 / gammaScale;
  }

  // The diagnostics sample the same signed bicubic field as the GPU grains.
  sampleAcceleration(x: number, y: number) {
    const gx = Math.min(HALF_CELLS, Math.abs(x) * HALF_CELLS / HALF);
    const gy = Math.min(HALF_CELLS, Math.abs(y) * HALF_CELLS / HALF);
    const ix = Math.min(HALF_CELLS - 1, Math.floor(gx));
    const iy = Math.min(HALF_CELLS - 1, Math.floor(gy));
    cubicWeights(gx - ix, this.weightsX);
    cubicWeights(gy - iy, this.weightsY);
    this.sampled.fill(0);
    for (let row = 0; row < 4; row++) {
      let i = 4 * ((iy + row) * WAVE_SIZE + ix);
      for (let col = 0; col < 4; col++, i += 4) {
        const weight = this.weightsY[row] * this.weightsX[col];
        for (let c = 0; c < 4; c++) this.sampled[c] += weight * this.wave[i + c];
      }
    }
    return Math.hypot(this.sampled[0], this.sampled[1], this.sampled[2], this.sampled[3]);
  }

  get acceleration() {
    const result = new Float32Array(FIELD_SIZE ** 2);
    for (let y = 0; y < FIELD_SIZE; y++) {
      const row = (1 + Math.abs(y - HALF_CELLS)) * WAVE_SIZE + 1;
      for (let x = 0; x < FIELD_SIZE; x++) {
        const i = 4 * (row + Math.abs(x - HALF_CELLS));
        result[y * FIELD_SIZE + x] = Math.hypot(this.wave[i], this.wave[i + 1], this.wave[i + 2], this.wave[i + 3]);
      }
    }
    return result;
  }
}
