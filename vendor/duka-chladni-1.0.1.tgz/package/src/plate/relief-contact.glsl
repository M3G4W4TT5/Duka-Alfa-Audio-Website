uniform sampler2D reliefMap;
uniform vec4 reliefPose; // Centre XY, width and relief height, all metres.

float reliefTexel() { return reliefPose.z * RELIEF_SPAN / RELIEF_PIXELS; }

// Signed horizontal distance to a wall, and height of the adjacent upper face.
// The padded atlas contains the highest triangle at each point, including bevels.
vec2 reliefContact(vec2 p) {
  vec2 local = (p - reliefPose.xy) / (reliefPose.z * RELIEF_SPAN);
  vec2 outside = max(abs(local) - .5, 0.);
  if (max(outside.x, outside.y) > 0.) {
    return vec2((length(outside) + .5 - .5 / RELIEF_SPAN) * reliefPose.z * RELIEF_SPAN, reliefPose.w);
  }
  vec3 data = texture2D(reliefMap, local + .5).rgb;
  float distancePx = dot(data.rg, vec2(255., 255. / 256.)) - 128.;
  return vec2(distancePx * reliefTexel(), data.b * reliefPose.w);
}

vec2 wallNormal(vec2 p) {
  vec2 tap = vec2(reliefTexel(), 0.);
  vec2 g = vec2(reliefContact(p + tap).x - reliefContact(p - tap).x,
                reliefContact(p + tap.yx).x - reliefContact(p - tap.yx).x);
  return g / max(length(g), 1.e-9);
}
