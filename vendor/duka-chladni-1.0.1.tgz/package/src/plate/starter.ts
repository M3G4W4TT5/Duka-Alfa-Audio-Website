import { Color } from 'three';
import { BUILTINS, DUKA_SVG, ENGINE, parseConfiguration } from './configuration.ts';
import { PlateDrive } from './drive.ts';
import { START_FREQUENCY } from './field.ts';
import { defaultFraming } from './framing.ts';
import { DEFAULT_SETTINGS, DEFAULT_SPOTLIGHT, SAND_SEED, sampleGradient } from './settings.ts';

export function createStarterPreset({ controlsOnly = false, grainCount = DEFAULT_SETTINGS.grainCount } = {}) {
  const settings = { ...DEFAULT_SETTINGS, grainCount };
  const drive = new PlateDrive(settings, START_FREQUENCY);
  const angle = DEFAULT_SPOTLIGHT.angle;
  const color = sampleGradient(settings.gradient, .5, new Color(), new Color());
  return parseConfiguration({
    schemaVersion: 1, engine: ENGINE, settings, framing: defaultFraming(),
    editor: { view: 'window', editCrop: false, controlsOnly },
    assets: { ...BUILTINS, svg: DUKA_SVG },
    start: { arrangement: 'loose', seed: SAND_SEED, pour: 0, drive: drive.snapshot(),
      pointer: { x: .5, y: 1 - drive.directHeight }, followAngle: angle, lampTarget: angle,
      lights: [{ id: DEFAULT_SPOTLIGHT.id, hue: .5, color: color.toArray(), pinnedColor: [1, 1, 1], pinnedWeight: 0 }] },
  });
}
