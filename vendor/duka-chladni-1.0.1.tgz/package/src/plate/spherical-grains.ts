// The same instanced quad bounds a sphere in the overhead view and in each light's shadow map.
// grainShape() supplies the world-space centre and radius from the simulation.
export const sphereSurfaceVertex = /* glsl */ `
  uniform float grainPixelSize;
  varying vec4 sphere;
  varying vec2 disc;
  varying float depthPerRadius;
  varying float tone;
  void main() {
    sphere = grainShape();
    tone = grainForm.w;
    // Include half a screen pixel so edge coverage also works for small grains.
    vec2 offset = position.xy * (sphere.w + .5 * grainPixelSize);
    disc = offset / sphere.w;
    depthPerRadius = .5 * projectionMatrix[2][2] * sphere.w;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(sphere.xyz + vec3(offset, 0.), 1.);
  }
`;

export const sphereSurfaceFragment = /* glsl */ `
  uniform float grainPixelSize;
  varying vec4 sphere;
  varying vec2 disc;
  varying float depthPerRadius;
  void main() {
    float d = length(disc);
    float radiusPx = sphere.w / grainPixelSize;
    float coverage = clamp((1. - d) * radiusPx + .5, 0., min(1., 3.141593 * radiusPx * radiusPx));
    if (coverage <= 0.) discard;
    vec3 n = vec3(disc / max(1., d), sqrt(max(0., 1. - d * d)));
    vec3 p = sphere.xyz + sphere.w * n;
    gl_FragDepth = gl_FragCoord.z + depthPerRadius * n.z;
    gl_FragColor = vec4(grainColour(p, n), coverage);
    #include <colorspace_fragment>
  }
`;

export const sphereShadowVertex = /* glsl */ `
  uniform vec3 lamp;
  varying vec4 sphere;
  varying vec3 lightRay;
  void main() {
    sphere = grainShape();
    vec3 dir = normalize(sphere.xyz - lamp);
    vec3 across = normalize(abs(dir.z) < .99 ? vec3(-dir.y, dir.x, 0.) : vec3(0., -dir.z, dir.y));
    vec3 up = cross(dir, across);
    // A square on the near tangent plane encloses the silhouette as seen by this point light.
    vec3 corner = sphere.xyz + sphere.w * (position.x * across + position.y * up - dir);
    lightRay = corner - lamp;
    gl_Position = shadowClip(corner, lamp);
    gl_Position.z = 0.; // Clip and write depth at the sphere hit in the fragment shader.
  }
`;

export const sphereShadowFragment = /* glsl */ `
  uniform vec3 lamp;
  varying vec4 sphere;
  varying vec3 lightRay;
  void main() {
    vec3 ray = normalize(lightRay);
    vec3 toCentre = sphere.xyz - lamp;
    float along = dot(toCentre, ray);
    vec3 offset = along * ray - toCentre;
    float chordSq = sphere.w * sphere.w - dot(offset, offset);
    if (chordSq < 0. || along <= 0.) discard;
    vec3 hit = sphere.xyz + offset - ray * sqrt(chordSq);
    vec4 clip = shadowClip(hit, lamp);
    if (clip.w <= abs(clip.z)) discard;
    gl_FragDepth = .5 + .5 * clip.z / clip.w;
    gl_FragColor = vec4(1.);
  }
`;
