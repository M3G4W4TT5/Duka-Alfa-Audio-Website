import { Color } from 'three';
import { DEFAULT_SPOTLIGHT, MAX_SPOTLIGHTS, sampleGradient, type GradientStop, type PlateSettings, type SpotlightSettings } from './settings.ts';

type Preset = 'follow' | 'cross' | 'three' | 'four';

function fixedLight(id: number, angle: number, color: string, intensity: number): SpotlightSettings {
  return { ...DEFAULT_SPOTLIGHT, id, position: 'fixed', angle, colorSource: 'fixed', color, intensity };
}

const fixedLights = [
  fixedLight(1, 300, '#9b64f3', 1),
  fixedLight(2, 120, '#d16e42', 1 / 3),
  fixedLight(3, 35, '#77bffa', .24),
  fixedLight(4, 220, '#e2a66d', .18),
];

export function lightingPreset(preset: Preset) {
  if (preset === 'follow') return [DEFAULT_SPOTLIGHT];
  return fixedLights.slice(0, preset === 'cross' ? 2 : preset === 'three' ? 3 : 4);
}

const presetByCount: readonly Preset[] = ['follow', 'cross', 'three', 'four'];

export function currentLightingPreset(lights: SpotlightSettings[]): Preset | 'custom' {
  const name = presetByCount[lights.length - 1];
  if (!name) return 'custom';
  const matches = lightingPreset(name).every((preset, i) => {
    const light = lights[i];
    return light.id === preset.id && light.position === preset.position && light.colorSource === preset.colorSource &&
      (light.position === 'follow' || light.angle === preset.angle) &&
      (light.colorSource !== 'fixed' || light.color === preset.color) &&
      light.intensity === preset.intensity && light.elevation === preset.elevation && light.beamWidth === preset.beamWidth;
  });
  return matches ? name : 'custom';
}

export function addLight(lights: SpotlightSettings[]) {
  if (lights.length >= MAX_SPOTLIGHTS) return lights;
  const slot = fixedLights.find(light => !lights.some(existing => existing.id === light.id))!;
  return [...lights, slot];
}

export function replaceLights(settings: Pick<PlateSettings, 'strobe'>, lights: SpotlightSettings[], detachedAngle?: number) {
  const source = settings.strobe.source;
  const strobe = source === 'fixed' || lights.some(light => light.id === source)
    ? settings.strobe
    : { ...settings.strobe, source: 'fixed' as const, angle: detachedAngle ?? settings.strobe.angle };
  return { lights, strobe };
}

export const wrapDegrees = (degrees: number) => (degrees % 360 + 360) % 360;

export function angleFromVector(x: number, y: number) {
  return wrapDegrees(Math.atan2(x, y) * 180 / Math.PI);
}

export function orbitPoint(angle: number) {
  const rad = angle * Math.PI / 180;
  return { x: Math.sin(rad), y: Math.cos(rad) };
}

export function mapPoint(angle: number) {
  const { x, y } = orbitPoint(angle);
  return { x: 50 + 50 * x, y: 50 - 50 * y };
}

export function easeAngle(current: number, target: number, amount: number) {
  const delta = wrapDegrees(target - current + 180) - 180;
  return Math.abs(delta) < 1e-6 ? target : wrapDegrees(current + delta * amount);
}

export type RenderedSpotlight = {
  id: number;
  angle: number;
  color: Color;
  hue: number;
  intensity: number;
  elevation: number;
  beamWidth: number;
};

export type LiveSpotlight = RenderedSpotlight & { pinnedColor: Color; pinnedWeight: number };

export function updateSpotlightColour(light: LiveSpotlight, settings: SpotlightSettings, gradient: GradientStop[],
  targetHue: number, ease: number, scratch: Color) {
  if (settings.colorSource === 'fixed') {
    if (settings.linearColor) light.color.fromArray(settings.linearColor);
    else light.color.set(settings.color);
    light.pinnedColor.copy(light.color);
    light.pinnedWeight = 1;
    return;
  }

  // Traverse the stops even on a fast sweep. An arbitrary pinned colour can
  // sit outside the gradient, so fade its contribution when tracking resumes.
  light.hue += (targetHue - light.hue) * ease;
  sampleGradient(gradient, light.hue, light.color, scratch);
  if (light.pinnedWeight > 0) {
    light.pinnedWeight *= 1 - ease;
    if (light.pinnedWeight < 1e-6) light.pinnedWeight = 0;
    light.color.lerp(light.pinnedColor, light.pinnedWeight);
  }
}
