import * as THREE from 'three';
import type { SvgImage } from './svg-image';
import { stencilCount } from './svg-sampling';
import { DEFAULT_SVG, svgPlacement, type SvgLayerSettings } from './settings';

export interface GrainStencil {
  table: THREE.DataTexture;
  count: number;
  mass: number;
  pixels: THREE.Vector2;
  pose: THREE.Vector4;
}

// The sheet transmits light according to its painted alpha. Intersecting the
// actual lamp-to-receiver segment also handles different heights on the relief.
export const svgTransmission = /* glsl */ `
  uniform sampler2D svgMap;
  uniform vec4 svgPose;
  uniform float svgHeight;
  uniform float svgShadowOpacity;
  float throughSvg(vec3 lamp, vec3 p) {
    if (svgShadowOpacity <= 0. || abs(svgHeight - p.z) < .000012) return 1.;
    float dz = lamp.z - p.z;
    if (abs(dz) < 1.e-8) return 1.;
    float t = (svgHeight - p.z) / dz;
    if (t <= 0. || t >= 1.) return 1.;
    vec2 uv = (mix(p.xy, lamp.xy, t) - svgPose.xy) / svgPose.zw + .5;
    if (any(lessThan(uv, vec2(0.))) || any(greaterThan(uv, vec2(1.)))) return 1.;
    return 1. - svgShadowOpacity * texture2D(svgMap, uv).a;
  }
`;

export class SvgLayer {
  readonly uniforms = {
    svgMap: { value: null as THREE.CanvasTexture | null }, svgPose: { value: new THREE.Vector4(0, 0, 1, 1) },
    svgHeight: { value: 0 }, svgShadowOpacity: { value: 0 },
  };
  readonly opacity = { value: 0 };
  readonly guide = { value: 0 };
  stencil: GrainStencil | null = null;
  image: SvgImage | null = null;
  private table: THREE.DataTexture | null = null;
  private readonly pixels = new THREE.Vector2();
  private settings = DEFAULT_SVG;
  private guideUntil = 0;

  setImage(image: SvgImage | null) {
    if (this.image === image) return;
    this.uniforms.svgMap.value?.dispose();
    this.table?.dispose();
    this.image = image;
    this.table = null;
    this.uniforms.svgMap.value = null;
    if (image) {
      const art = new THREE.CanvasTexture(image.artwork);
      art.colorSpace = THREE.SRGBColorSpace;
      this.uniforms.svgMap.value = art;
      const { entries, columns, width, height } = image.samples;
      this.table = new THREE.DataTexture(entries, columns, entries.length / (2 * columns),
        THREE.RGIntegerFormat, THREE.UnsignedIntType);
      this.table.internalFormat = 'RG32UI';
      this.table.needsUpdate = true;
      this.pixels.set(width, height);
      this.preview();
    }
    this.configure(this.settings);
  }

  configure(settings: SvgLayerSettings) {
    const old = this.settings;
    if (settings.enabled && (!old.enabled || old.x !== settings.x || old.y !== settings.y || old.size !== settings.size)) this.preview();
    this.settings = settings;
    const { image, uniforms } = this;
    const { width, height } = svgPlacement(settings.size, image?.aspect ?? 1);
    uniforms.svgPose.value.set(settings.x / 1000, settings.y / 1000, width / 1000, height / 1000);
    uniforms.svgHeight.value = settings.height / 1000;
    this.opacity.value = settings.enabled && image && settings.artwork ? settings.opacity : 0;
    uniforms.svgShadowOpacity.value = settings.shadows ? this.opacity.value : 0;
    this.stencil = null;
    if (settings.enabled && settings.stencil && image && this.table) {
      const count = stencilCount(image.samples, settings.shape === 'outline', settings.weight, width);
      this.stencil = { table: this.table, count, mass: image.samples.entries[count * 2 - 1],
        pixels: this.pixels, pose: uniforms.svgPose.value };
    }
  }

  preview() { this.guideUntil = performance.now() + 850; }
  hideGuide() { this.guideUntil = 0; }

  visible(now: number) {
    const showGuide = this.settings.enabled && this.settings.stencil && !this.settings.artwork && this.image;
    this.guide.value = showGuide ? Math.max(0, Math.min(1, (this.guideUntil - now) / 250)) : 0;
    return this.opacity.value > 0 || this.guide.value > 0;
  }

  dispose() { this.uniforms.svgMap.value?.dispose(); this.table?.dispose(); }
}
