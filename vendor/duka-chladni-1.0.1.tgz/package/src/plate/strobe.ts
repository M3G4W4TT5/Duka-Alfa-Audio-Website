import { clamp, type StrobeSettings } from './settings.ts';

export const STROBE_LIMITS = {
  rate: { min: .25, max: 50, step: .05 },
  width: { min: 1, max: 180, step: 1 },
  flashes: { min: 0, max: 12, step: 1 },
  gap: { min: 50, max: 10000, step: 10 },
  strength: { min: 0, max: 20, step: .1 },
};

type Cadence = Pick<StrobeSettings, 'rate' | 'width' | 'flashes' | 'gap'>;

export const STANDARD_FLASH_LIMIT = 3;

export function maxFlashWidth(rate: number) {
  const period = 1000 / clamp(rate, STROBE_LIMITS.rate.min, STROBE_LIMITS.rate.max);
  const darkTime = Math.min(20, period / 2);
  return Math.min(STROBE_LIMITS.width.max, Math.floor(period - darkTime));
}

export function pulseAt(elapsed: number, cadence: Cadence) {
  const { rate, width, flashes, gap } = STROBE_LIMITS;
  const period = 1000 / clamp(cadence.rate, rate.min, rate.max);
  const duration = clamp(cadence.width, width.min, maxFlashWidth(cadence.rate));
  const count = Math.round(clamp(cadence.flashes, flashes.min, flashes.max));
  if (count === 0) {
    const index = Math.floor(elapsed / period);
    return elapsed - index * period < duration ? index : null;
  }
  const cycle = (count - 1) * period + duration + clamp(cadence.gap, gap.min, gap.max);
  const cycleIndex = Math.floor(elapsed / cycle);
  const phase = elapsed - cycleIndex * cycle;
  const flash = Math.floor(phase / period);
  return flash < count && phase - flash * period < duration ? cycleIndex * count + flash : null;
}

export class StrobeClock {
  on = false;
  flashCount = 0;
  private origin: number | null = null;
  private currentPulse: number | null = null;
  private readonly starts: number[] = [];
  private previous: StrobeSettings | undefined;

  interrupt() { this.origin = null; }

  advance(now: number, active: boolean, settings: StrobeSettings) {
    const previous = this.previous;
    this.previous = settings;
    if (!active) {
      this.origin = this.currentPulse = null;
      return this.on = false;
    }

    if (this.origin === null || settings.mode !== previous?.mode || settings.rate !== previous.rate ||
      settings.width !== previous.width || settings.flashes !== previous.flashes || settings.gap !== previous.gap) {
      this.origin = now;
      this.currentPulse = null;
      // A timing edit during a flash needs a dark frame before the new phase.
      if (this.on) return this.on = false;
    }

    const pulse = pulseAt(now - this.origin, settings);
    if (pulse === null || (this.on && this.currentPulse !== pulse)) {
      // If a frame stall skips a dark interval, present dark before showing a
      // later pulse. Expired windows are never replayed.
      this.currentPulse = null;
      return this.on = false;
    }
    if (this.on) return true;

    // Compare frame times in integer microseconds so fractional refresh intervals
    // put starts exactly one second apart on the same window boundary.
    const startUs = Math.round(now * 1000);
    const limit = clamp(Math.ceil(settings.rate), STANDARD_FLASH_LIMIT, STROBE_LIMITS.rate.max);
    const cutoff = startUs - 1_000_000;
    // Keep the inclusive three-flash guard at low rates. At higher rates a
    // pulse exactly one second old belongs to the preceding one-second window.
    while (this.starts.length && (limit === STANDARD_FLASH_LIMIT ? this.starts[0] < cutoff : this.starts[0] <= cutoff)) {
      this.starts.shift();
    }
    if (this.starts.length >= limit) return false;
    this.starts.push(startUs);
    this.flashCount++;
    this.currentPulse = pulse;
    return this.on = true;
  }
}
