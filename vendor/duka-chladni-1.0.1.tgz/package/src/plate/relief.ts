import * as THREE from 'three';
import contactUrl from '../assets/duka-contact.png?url';
import logoUrl from '../assets/duka-logomark.glb?url';
import { SIDE } from './field';
import { reliefBounds as bounds, type PlateSettings } from './settings';

export type ReliefStatus = 'idle' | 'loading' | 'ready' | 'error';

export class DukaRelief {
  readonly surface = new THREE.Group();
  readonly shadow = new THREE.Group();
  readonly placement = new THREE.Vector4();
  texture: THREE.Texture | null = null;
  status: ReliefStatus = 'idle';
  private requested = false;
  private lighting: PlateSettings['reliefLighting'] = 'solid';
  private disposed = false;

  constructor(private face: THREE.Material, private caster: THREE.Material, private changed: () => void) {}

  get active() { return this.requested && this.status === 'ready'; }
  get passesLight() { return this.requested && this.lighting === 'pass-through'; }

  private updateVisibility() {
    this.surface.visible = this.active && this.placement.w > 0;
    this.shadow.visible = this.surface.visible && !this.passesLight;
  }

  configure(settings: PlateSettings) {
    const previouslyRequested = this.requested;
    this.requested = settings.background === '3d';
    this.lighting = settings.reliefLighting;
    const width = SIDE * settings.logoSize / 100;
    const height = settings.logoHeight / 1000;
    this.placement.set(settings.logoX / 1000, settings.logoY / 1000, width, height);
    const { lo, hi } = bounds;
    const xy = width / (hi[0] - lo[0]), z = height / (hi[2] - lo[2]);
    for (const group of [this.surface, this.shadow]) {
      group.scale.set(xy, xy, z);
      group.position.set(this.placement.x - xy * (lo[0] + hi[0]) / 2,
        this.placement.y - xy * (lo[1] + hi[1]) / 2, -lo[2] * z);
    }
    this.updateVisibility();
    if (this.requested && (this.status === 'idle' || (this.status === 'error' && !previouslyRequested))) {
      this.status = 'loading';
      void this.load();
    }
  }

  private async load() {
    const [model, map] = await Promise.allSettled([
      import('three/addons/loaders/GLTFLoader.js').then(({ GLTFLoader }) => new GLTFLoader().loadAsync(logoUrl)),
      new THREE.TextureLoader().loadAsync(contactUrl),
    ]);
    const scene = model.status === 'fulfilled' ? model.value.scene : undefined;
    const texture = map.status === 'fulfilled' ? map.value : undefined;
    const meshes: THREE.Mesh[] = [];
    const materials = new Set<THREE.Material>();
    scene?.traverse(node => {
      if (node instanceof THREE.Mesh) {
        meshes.push(node);
        for (const material of Array.isArray(node.material) ? node.material : [node.material]) materials.add(material);
      }
    });
    for (const material of materials) material.dispose();
    if (this.disposed || !meshes.length || !texture || !scene) {
      for (const mesh of meshes) mesh.geometry.dispose();
      texture?.dispose();
      if (!this.disposed) {
        this.status = 'error';
        this.changed();
      }
      return;
    }
    texture.colorSpace = THREE.NoColorSpace;
    texture.minFilter = texture.magFilter = THREE.LinearFilter;
    texture.generateMipmaps = false;
    this.texture = texture;
    for (const mesh of meshes) {
      mesh.material = this.face;
      mesh.frustumCulled = false;
      mesh.renderOrder = -1;
    }
    this.surface.add(scene);
    const shadow = scene.clone(true);
    shadow.traverse(node => { if (node instanceof THREE.Mesh) node.material = this.caster; });
    this.shadow.add(shadow);
    this.status = 'ready';
    this.updateVisibility();
    this.changed();
  }

  dispose() {
    this.disposed = true;
    this.surface.traverse(node => { if (node instanceof THREE.Mesh) node.geometry.dispose(); });
    this.texture?.dispose();
    this.face.dispose();
    this.caster.dispose();
  }
}
