export type TextureKind = 'smooth' | 'brushed' | 'grit' | 'corroded';
export interface SurfaceFinish {
  metalness: number;
  roughness: number;
  reflections: number;
}
export interface SurfaceTexture {
  kind: TextureKind;
  strength: number;
  scaleMm: number;
  angle: number;
  colourMix: number;
}
export interface SurfaceStyle {
  colour: string;
  finish: SurfaceFinish;
  texture: SurfaceTexture;
}
export type MaterialLinks = Record<keyof SurfaceStyle, boolean>;
export interface LogoEffect {
  kind: 'off' | 'colour' | 'neon';
  coverage: 'edges' | 'whole';
  colour: string;
  widthMm: number;
  opacity: number;
  emission: number;
  spill: number;
}

export const FINISHES = {
  matte: { metalness: 0, roughness: .80, reflections: .6 },
  satin: { metalness: 1, roughness: .38, reflections: .8 },
  chrome: { metalness: 1, roughness: .085, reflections: 1 },
} satisfies Record<string, SurfaceFinish>;
export const DEFAULT_SURFACE: SurfaceStyle = {
  colour: '#141415', finish: FINISHES.matte,
  texture: { kind: 'smooth', strength: .65, scaleMm: 36, angle: 0, colourMix: 0 },
};
export const DEFAULT_LOGO_EFFECT: LogoEffect = {
  kind: 'off', coverage: 'edges', colour: '#b978ff', widthMm: .4, opacity: .85, emission: 3.5, spill: .4,
};
export function logoSurface(background: SurfaceStyle, logo: SurfaceStyle, links: MaterialLinks): SurfaceStyle {
  return { colour: links.colour ? background.colour : logo.colour,
    finish: links.finish ? background.finish : logo.finish, texture: links.texture ? background.texture : logo.texture };
}
