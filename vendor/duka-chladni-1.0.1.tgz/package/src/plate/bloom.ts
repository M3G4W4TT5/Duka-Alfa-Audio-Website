import { CustomBlending, OneFactor, Vector2, ZeroFactor } from 'three';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { DEFAULT_SETTINGS } from './settings.ts';

// The five Gaussian variances scale as 1, 5, 21, 85, 341. For each set of
// energy weights, the summed point response falls to half its peak at
// 1.6 times the first sigma. Adjusting the wings preserves that core width.
const GRADUAL = [0.0896, 0.1604, 0.47, 0.19, 0.09];
const STEEP = [0.1955, 0.7835, 0.02, 0.001, 0];
const SCATTER_GAIN = 5.1;
const MAX_SIGMA = 5.5;
const TAIL_SIGMAS = 3.8;
const MAX_PAIRS = Math.ceil((2 * MAX_SIGMA * TAIL_SIGMAS + 1) / 2);

const extractHighlights = /* glsl */ `
  uniform sampler2D tDiffuse;
  uniform float luminosityThreshold;
  uniform vec2 footprint;
  uniform bool denseSampling;
  varying vec2 vUv;

  vec3 highlight(vec2 uv) {
    vec3 rgb = texture2D(tDiffuse, uv).rgb;
    float light = dot(rgb, vec3(.2126, .7152, .0722));
    float knee = max(.035, luminosityThreshold * .45);
    float excess = light - luminosityThreshold;
    float shoulder = clamp(excess + knee, 0., 2. * knee);
    float passed = max(excess, shoulder * shoulder / (4. * knee));
    return rgb * (passed / max(light, .00001));
  }

  void main() {
    vec3 sum = vec3(0.);
    // Extract each HDR sample before averaging. A single bright quartz facet
    // can contribute even when most of this output pixel is dark.
    if (denseSampling) {
      for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) {
        vec2 offset = (vec2(float(x), float(y)) + .5) * .25 - .5;
        sum += highlight(vUv + offset * footprint);
      }
      sum *= 1. / 16.;
    } else {
      vec2 d = .25 * footprint;
      sum = .25 * (highlight(vUv + d) + highlight(vUv - d)
                 + highlight(vUv + vec2(d.x, -d.y)) + highlight(vUv + vec2(-d.x, d.y)));
    }
    gl_FragColor = vec4(sum, 1.);
  }`;

const blur = /* glsl */ `
  uniform sampler2D colorTexture;
  uniform vec2 direction;
  uniform float centreWeight;
  uniform int pairCount;
  uniform vec2 taps[${MAX_PAIRS}];
  varying vec2 vUv;

  void main() {
    vec2 stepUV = direction / vec2(textureSize(colorTexture, 0));
    vec3 light = texture2D(colorTexture, vUv).rgb * centreWeight;
    for (int i = 0; i < ${MAX_PAIRS}; i++) {
      if (i >= pairCount) break;
      vec2 offset = taps[i].x * stepUV;
      light += taps[i].y * (texture2D(colorTexture, vUv + offset).rgb
                          + texture2D(colorTexture, vUv - offset).rgb);
    }
    gl_FragColor = vec4(light, 1.);
  }`;

function gaussianTaps(sigma: number, decimate: boolean) {
  const taps = new Float32Array(2 * MAX_PAIRS);
  const weight = (x: number) => Math.exp(-0.5 * (x / sigma) ** 2);
  const centre = decimate ? 0 : 1;
  let total = centre, count = 0;
  // A 2:1 reduction centres the output between two source texels. Pair
  // adjacent texels into one bilinear fetch on each side of that centre.
  for (let x = decimate ? 0.5 : 1; x <= TAIL_SIGMAS * sigma; x += 2) {
    const a = weight(x), b = weight(x + 1);
    taps[2 * count] = x + b / (a + b);
    taps[2 * count + 1] = a + b;
    total += 2 * (a + b);
    count++;
  }
  for (let i = 0; i < count; i++) taps[2 * i + 1] /= total;
  return { taps, count, centre: centre / total };
}

export class RadialBloomPass extends UnrealBloomPass {
  pixelRatio = 1;
  private spread = NaN;
  private falloff = NaN;

  constructor() {
    super(new Vector2(1, 1), DEFAULT_SETTINGS.bloomStrength, 0, DEFAULT_SETTINGS.bloomThreshold);
    for (const target of [this.renderTargetBright, ...this.renderTargetsHorizontal, ...this.renderTargetsVertical]) {
      target.depthBuffer = false;
    }
    this.materialHighPassFilter.fragmentShader = extractHighlights;
    this.materialHighPassFilter.uniforms.footprint = { value: new Vector2(1, 1) };
    this.materialHighPassFilter.uniforms.denseSampling = { value: false };
    for (const material of this.separableBlurMaterials) {
      material.defines = {};
      material.fragmentShader = blur;
      material.uniforms.centreWeight = { value: 0 };
      material.uniforms.pairCount = { value: 0 };
      material.uniforms.taps = { value: null };
    }
    // Scatter is additive in linear light. Keep the base alpha, and apply the
    // strength exactly once regardless of the combined textures' alpha.
    this.blendMaterial.blending = CustomBlending;
    this.blendMaterial.blendSrc = OneFactor;
    this.blendMaterial.blendDst = OneFactor;
    this.blendMaterial.blendSrcAlpha = ZeroFactor;
    this.blendMaterial.blendDstAlpha = OneFactor;
    this.setProfile(DEFAULT_SETTINGS.bloomRadius, DEFAULT_SETTINGS.bloomFalloff);
  }

  setProfile(spread: number, falloff: number) {
    if (this.spread !== spread) {
      this.spread = spread;
      // The first level is half CSS resolution. Spread changes every physical
      // filter width continuously, including when a slider reaches an endpoint.
      const sigma = MAX_SIGMA ** spread;
      const first = gaussianTaps(sigma, false);
      const coarse = gaussianTaps(2 * sigma, true);
      this.separableBlurMaterials.forEach((material, i) => {
        const kernel = i === 0 ? first : coarse;
        material.uniforms.centreWeight.value = kernel.centre;
        material.uniforms.pairCount.value = kernel.count;
        material.uniforms.taps.value = kernel.taps;
      });
    }
    if (this.falloff !== falloff) {
      this.falloff = falloff;
      this.compositeMaterial.uniforms.bloomFactors.value = GRADUAL.map((w, i) =>
        SCATTER_GAIN * (w + (STEEP[i] - w) * falloff));
    }
  }

  override setSize(width: number, height: number) {
    // The composer supplies device pixels. Keep the optical radius in CSS
    // pixels so a Retina display and a standard display show the same halo.
    let w = Math.max(1, Math.round(width / (2 * this.pixelRatio)));
    let h = Math.max(1, Math.round(height / (2 * this.pixelRatio)));
    this.renderTargetBright.setSize(w, h);
    this.materialHighPassFilter.uniforms.footprint.value.set(1 / w, 1 / h);
    this.materialHighPassFilter.uniforms.denseSampling.value = this.pixelRatio > 1;
    let sourceH = h;
    for (let i = 0; i < this.nMips; i++) {
      // Reduce width in the horizontal pass and height in the vertical pass.
      // Each 1D convolution sees the same source pixel pitch along its own axis.
      this.renderTargetsHorizontal[i].setSize(w, sourceH);
      this.renderTargetsVertical[i].setSize(w, h);
      sourceH = h;
      w = Math.max(1, Math.round(w / 2));
      h = Math.max(1, Math.round(h / 2));
    }
  }

  override dispose() {
    this.materialHighPassFilter.dispose();
    super.dispose();
  }
}
