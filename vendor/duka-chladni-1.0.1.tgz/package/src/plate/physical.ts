import modalData from './wide-modes.json' with { type: 'json' };

export const MAX_FREQUENCY = modalData.maxDriveHz;

function cacheModeShapes(axisSize: number) {
  const degree = modalData.degree;
  const basisSize = degree / 2 + 1;
  const modeCount = modalData.modeHz.length;
  const source = Uint8Array.from(atob(modalData.coefficientsF32LE), byte => byte.charCodeAt(0));
  const view = new DataView(source.buffer);
  const coefficients = Float64Array.from({ length: source.length / 4 }, (_, i) => view.getFloat32(i * 4, true));
  const basis = new Float64Array(axisSize * basisSize);
  for (let i = 0; i < axisSize; i++) {
    const u = i / (axisSize - 1);
    basis[i * basisSize] = 1;
    let previous = 1;
    let current = u;
    for (let p = 2; p <= degree; p++) {
      const next = ((2 * p - 1) * u * current - (p - 1) * previous) / p;
      if (p % 2 === 0) basis[i * basisSize + p / 2] = next;
      previous = current;
      current = next;
    }
  }

  // Contract along x first, then along y. Interleave modes at each point for
  // sequential access when summing the driven field at a new frequency.
  const shapes = new Float32Array(axisSize ** 2 * modeCount);
  const xProjection = new Float64Array(axisSize * basisSize);
  for (let mode = 0; mode < modeCount; mode++) {
    for (let x = 0; x < axisSize; x++) {
      for (let row = 0; row < basisSize; row++) {
        let projection = 0;
        for (let j = 0; j < basisSize; j++) {
          projection += coefficients[(mode * basisSize + row) * basisSize + j] * basis[x * basisSize + j];
        }
        xProjection[x * basisSize + row] = projection;
      }
    }
    for (let y = 0; y < axisSize; y++) {
      for (let x = 0; x < axisSize; x++) {
        let shape = 0;
        for (let j = 0; j < basisSize; j++) shape += xProjection[x * basisSize + j] * basis[y * basisSize + j];
        shapes[(y * axisSize + x) * modeCount + mode] = shape;
      }
    }
  }
  return shapes;
}

const poles = modalData.modeHz.map(hz => 2 * Math.PI * hz);
const stiffness = poles.map(omega => omega * omega);
const damping = poles.map(omega => 2 * modalData.damping * omega);
const loads = modalData.overlaps.map(overlap => modalData.forceN * overlap);

export class PhysicalResponse {
  readonly real: Float64Array;
  readonly imaginary: Float64Array;
  private readonly shapes: Float32Array;
  private readonly weightReal = new Float64Array(poles.length);
  private readonly weightImaginary = new Float64Array(poles.length);

  constructor(axisSize: number) {
    this.shapes = cacheModeShapes(axisSize);
    this.real = new Float64Array(axisSize ** 2);
    this.imaginary = new Float64Array(axisSize ** 2);
  }

  update(omega: number, omegaSquared: number) {
    const { real, imaginary, weightReal, weightImaginary, shapes } = this;
    const count = poles.length;
    for (let mode = 0; mode < count; mode++) {
      const d = stiffness[mode] - omegaSquared;
      const q = damping[mode] * omega;
      const scale = loads[mode] / (d * d + q * q);
      weightReal[mode] = scale * d;
      weightImaginary[mode] = -scale * q;
    }
    for (let i = 0; i < real.length; i++) {
      const offset = i * count;
      let r = 0;
      let j = 0;
      for (let mode = 0; mode < count; mode++) {
        const shape = shapes[offset + mode];
        r += shape * weightReal[mode];
        j += shape * weightImaginary[mode];
      }
      real[i] = r;
      imaginary[i] = j;
    }
  }
}
