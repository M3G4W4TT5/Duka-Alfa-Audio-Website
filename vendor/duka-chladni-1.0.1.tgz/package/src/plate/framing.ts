export type ViewId = 'window' | 'desktop' | 'mobile';
export type Point = { x: number; y: number };
// Plate coordinates. (0,0) is the upper-left corner and (1,1) the lower-right.
export type Crop = { centerX: number; centerY: number; width: number; height: number };
export type DeviceView = { enabled: boolean; width: number; height: number; crop: Crop };
export interface Framing {
  breakpoint: number;
  fit: 'cover';
  window: Crop | null; // null follows the full plate at any container size.
  desktop: DeviceView;
  mobile: DeviceView;
}
export interface Preview {
  view: ViewId;
  editing: boolean;
  layout: 'standalone' | 'container' | 'player';
  framing: Framing;
}
export const VIEW_SIZES = { desktop: [1920, 1080], mobile: [402, 874] } as const;
export const FIT_SPAN = 1 / .91;
export const MAX_ZOOM = 24;
const limit = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));

export function cropAt(aspect: number, shortSpan: number, x = .5, y = .5): Crop {
  return { centerX: limit(x, 0, 1), centerY: limit(y, 0, 1),
    width: shortSpan * Math.max(1, aspect), height: shortSpan * Math.max(1, 1 / aspect) };
}
export function fillFrame(aspect: number) { return cropAt(aspect, Math.min(aspect, 1 / aspect)); }
export function fitPlate(aspect: number) { return cropAt(aspect, FIT_SPAN); }
export function defaultFraming(): Framing {
  const device = ([width, height]: readonly [number, number]): DeviceView =>
    ({ enabled: false, width, height, crop: fillFrame(width / height) });
  return { breakpoint: 768, fit: 'cover', window: null, desktop: device(VIEW_SIZES.desktop), mobile: device(VIEW_SIZES.mobile) };
}
export function websiteView(views: Framing, containerWidth: number): ViewId {
  const id = containerWidth < views.breakpoint ? 'mobile' : 'desktop';
  return views[id].enabled ? id : 'window';
}
export function visibleCrop(views: Framing, id: ViewId, aspect: number): Crop {
  const saved = id === 'window' ? views.window : views[id].crop;
  if (!saved) return fitPlate(aspect);
  const height = Math.min(saved.height, saved.width / aspect);
  return { centerX: saved.centerX, centerY: saved.centerY, width: height * aspect, height };
}
export function storeCrop(views: Framing, id: ViewId, crop: Crop): Framing {
  return id === 'window' ? { ...views, window: crop } : { ...views, [id]: { ...views[id], crop } };
}

// Store the smallest reference rectangle that covers the crop edited at the
// host's real aspect ratio. Projecting it back preserves that composition.
export function cropForReference(crop: Crop, aspect: number): Crop {
  const short = Math.max(crop.width / Math.max(1, aspect), crop.height / Math.max(1, 1 / aspect));
  return cropAt(aspect, limit(short, FIT_SPAN / MAX_ZOOM, FIT_SPAN), crop.centerX, crop.centerY);
}
export const cropZoom = (crop: Crop) => FIT_SPAN / Math.min(crop.width, crop.height);
// Plate point under 'from' still lies under 'to' after a pan or pinch.
export function transformCrop(crop: Crop, scale: number, from: Point, to: Point): Crop {
  const short = Math.min(crop.width, crop.height);
  // Covering a saved Window crop at a new aspect can already exceed the
  // manual zoom limit. Panning still preserves that exact composition.
  const k = limit(short * scale, Math.min(short, FIT_SPAN / MAX_ZOOM), FIT_SPAN) / short;
  return cropAt(crop.width / crop.height, short * k,
    crop.centerX + crop.width * ((from.x - .5) - k * (to.x - .5)),
    crop.centerY + crop.height * ((from.y - .5) - k * (to.y - .5)));
}
export function cornerCrop(anchor: Point, point: Point, aspect: number): Crop {
  const dx = point.x - anchor.x, dy = point.y - anchor.y;
  const height = Math.max(Math.abs(dx) / aspect, Math.abs(dy));
  const short = limit(height * Math.min(1, aspect), FIT_SPAN / MAX_ZOOM, FIT_SPAN);
  const w = short * Math.max(1, aspect), h = w / aspect;
  return cropAt(aspect, short, anchor.x + (dx < 0 ? -w : w) / 2, anchor.y + (dy < 0 ? -h : h) / 2);
}
