import * as THREE from 'three';
import { GPUComputationRenderer, type Variable } from 'three/addons/misc/GPUComputationRenderer.js';
import { GRAVITY, HALF, HALF_CELLS, SIDE, VibrationField, WAVE_SIZE } from './field';
import { DEFAULT_SETTINGS, GRAIN_COUNTS, SAND_SEED, normalizeGrainCount, reliefBounds } from './settings';
import waveSampling from './wave-sampling.glsl?raw';
import reliefContact from './relief-contact.glsl?raw';
import reliefMotion from './relief-motion.glsl?raw';
import type { GrainStencil } from './svg-layer';
import { advanceStencilReturn } from './stencil-return';

export const GRAIN_COLUMNS = 384;
const GRAIN_ROWS = GRAIN_COUNTS.max / GRAIN_COLUMNS;
export const STEP = 1 / 60;
const PACKING_SIZE = 576;
const RESISTANCE_SIZE = 18;
const GRAIN_EDGE = 0.0898;

// A consecutive range of grain IDs spans at most two partial rows and a band of full rows.
function* grainRectangles(first: number, end: number): Generator<[number, number, number, number]> {
  while (first < end) {
    const x = first % GRAIN_COLUMNS;
    const y = Math.floor(first / GRAIN_COLUMNS);
    const width = Math.min(GRAIN_COLUMNS - x, end - first);
    const height = width === GRAIN_COLUMNS ? Math.floor((end - first) / GRAIN_COLUMNS) : 1;
    yield [x, y, width, height];
    first += width * height;
  }
}

const updateGrains = /* glsl */ `
  uniform sampler2D plateResistance;
  uniform float driveHz;
  uniform bool vibrationOn;
  uniform sampler2D stencilHomes;
  uniform vec4 homePose;
  uniform float returnBlend;
  uniform sampler2D packing;
  uniform vec2 packingOffset;
  uniform vec2 packingAxis;
  uniform float tick;

  const int halfCells = ${HALF_CELLS};
  const float cellMetres = ${HALF / HALF_CELLS};
  const float stepSeconds = ${STEP};
  const float gravity = ${GRAVITY};
  const float grainEdge = ${GRAIN_EDGE};
  ${waveSampling}
  #ifdef DUKA_RELIEF
    #define RELIEF_SPAN ${reliefBounds.span}
    #define RELIEF_PIXELS ${reliefBounds.pixels.toFixed(1)}
    ${reliefContact}
    ${reliefMotion}

    // A returning grain rises over an approaching lip and falls under gravity
    // on the other side. At its destination only the actual surface supports it.
    float returnBed(vec2 p, vec2 home) {
      if (reliefPose.w <= 0.) return 0.;
      vec2 contact = reliefContact(p);
      if (contact.x < 0.) return surfaceHeight(contact);
      vec2 delta = home - p;
      float distanceLeft = length(delta);
      float reach = min(distanceLeft, 1.5 * reliefPose.w);
      if (contact.x >= reach) return 0.;
      float lip = surfaceHeight(reliefContact(p + delta * (reach / distanceLeft)));
      return lip * (1. - smoothstep(0., reach, contact.x));
    }
  #endif

  float random(vec2 st, float salt) {
    vec3 p = fract(vec3(st.xyx) * vec3(.1031, .1030, .0973) + salt);
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
  }

  vec4 dropVertically(vec4 grain, float bed) {
    float vz = grain.w - gravity * stepSeconds;
    float z = grain.z + .5 * (grain.w + vz) * stepSeconds;
    return z > bed ? vec4(grain.xy, z, vz) : vec4(grain.xy, bed, 0.);
  }

  void main() {
    // Contact and hop noise are keyed to permanent grain IDs at every population.
    vec2 uv = gl_FragCoord.xy / ${GRAIN_COLUMNS.toFixed(1)};
    vec4 particle = texelFetch(sandState, ivec2(gl_FragCoord.xy), 0);
    if (!vibrationOn && returnBlend > 0.) {
      vec2 local = texelFetch(stencilHomes, ivec2(gl_FragCoord.xy), 0).rg;
      vec2 home = clamp(homePose.xy + local * homePose.zw, vec2(-grainEdge), vec2(grainEdge));
      particle.xy = returnBlend >= 1. ? home : mix(particle.xy, home, returnBlend);
      #ifdef DUKA_RELIEF
        float bed = returnBed(particle.xy, home);
      #else
        // A grain leaving a vibration ridge no longer has that pile beneath
        // it. Keep the downward velocity of a fresh pour and settle to the plate.
        float bed = 0.;
        particle.w = min(particle.w, 0.);
      #endif
      gl_FragColor = dropVertically(particle, bed);
      return;
    }
    #ifdef DUKA_RELIEF
      if (!vibrationOn) {
        float bed = reliefPose.w > 0. ? surfaceHeight(reliefContact(particle.xy)) : 0.;
        bool resting = abs(particle.w) < .015 && particle.z <= bed + .00029;
        gl_FragColor = resting ? vec4(particle.xy, max(bed, particle.z), 0.) : dropVertically(particle, bed);
        return;
      }
    #else
      // A negative fourth component identifies grains freshly poured from a
      // stencil. Normal flat-plate hops use a nonnegative lift height.
      if (particle.w < 0.) { gl_FragColor = dropVertically(particle, 0.); return; }
      if (!vibrationOn) {
        float lift = particle.w > .000001 ? .46 * particle.w : 0.;
        gl_FragColor = vec4(particle.xy, max(0., particle.z - particle.w) + lift, lift);
        return;
      }
    #endif
    vec2 plate = particle.xy / ${SIDE} + .5;
    float gamma;
    vec2 transport = nodalDrift(particle.xy, gamma);
    vec2 resistanceUV = (plate * ${(RESISTANCE_SIZE - 1).toFixed(1)} + .5) / ${RESISTANCE_SIZE.toFixed(1)};

    // Short-range pressure gives a ridge width. A smoothed, wider pressure
    // gradient lets sand spread along a ridge after it reforms during a sweep.
    const vec2 tap = vec2(.5 / ${PACKING_SIZE.toFixed(1)}, 0.);
    mat2 packingRotation = mat2(packingAxis, vec2(-packingAxis.y, packingAxis.x));
    vec2 cell = packingRotation * particle.xy / .255 + .5 + packingOffset;
    vec2 pressure = vec2(
      textureLod(packing, cell - tap, 0.).r - textureLod(packing, cell + tap, 0.).r,
      textureLod(packing, cell - tap.yx, 0.).r - textureLod(packing, cell + tap.yx, 0.).r
    );
    vec2 spreading = vec2(
      textureLod(packing, cell - tap, 2.5).r - textureLod(packing, cell + tap, 2.5).r,
      textureLod(packing, cell - tap.yx, 2.5).r - textureLod(packing, cell + tap.yx, 2.5).r
    );
    pressure = transpose(packingRotation) * pressure;
    spreading = transpose(packingRotation) * spreading;
    spreading -= transport * dot(transport, spreading) / (dot(transport, transport) + .00000002);
    float count = textureLod(packing, cell, .5).r;
    vec2 contact = clamp(.00042 * pressure * clamp((count - 2.) / 7., 0., 2.), -.005, .005);
    vec2 pileFlow = contact + clamp(.0075 * spreading, -.005, .005);
    // Each grain has a persistent contact threshold. Vibration and pressure
    // can release it into sliding independently of the vertical hop test.
    float roundness = random(uv, .3);
    float angularity = 1. - roundness;
    // Rounded grains can reach the narrow ridges, while the angular tail
    // catches in the more weakly agitated areas around them.
    float resistance = (.035 + 1.84 * angularity * angularity) * texture2D(plateResistance, resistanceUV).r;
    float jostling = min(.55, length(pileFlow) * 75.);
    float sliding = smoothstep(resistance * .8, resistance + .35, gamma + jostling);
    vec2 drift = transport * sliding * mix(.72, 1.13, roundness);
    drift += pileFlow * smoothstep(.00005, .0007, length(pileFlow));
    #ifdef DUKA_RELIEF
      vec2 surface = reliefPose.w > 0. ? reliefContact(particle.xy) : vec2(1., 0.);
      bool supported = particle.z <= surfaceHeight(surface) + .00029 && abs(particle.w) < .015;
      float lift = 0.;
    #else
      bool supported = true;
      float lift = particle.w * .46;
    #endif
    float noise = tick * .003542;
    vec2 slip = vec2(random(uv, noise + .223), random(uv, noise + .734)) - .5;
    vec2 next = particle.xy + (supported ? drift * stepSeconds + slip * (.00016 * sliding) : vec2(0.));
    if (supported && gamma > 1. && driveHz > 0.) {
      float capped = min(gamma, 35.);
      float speed = gravity / (6.28318530718 * driveHz) * sqrt(capped * capped - 1.);
      float flight = 2. * speed / gravity;
      float rate = 1. / max(flight, 1. / driveHz);
      float activeFraction = min(1., .55 * (gamma - 1.));
      if (random(uv, noise) < 1. - exp(-.65 * rate * activeFraction * stepSeconds)) {
        float phi = 6.2831853 * random(uv, noise + .5733);
        float dist = (min(.0035, .22 * speed * flight) + .000012) * (.28 + 1.52 * random(uv, noise + .3518));
        next += dist * vec2(cos(phi), sin(phi));
        lift = min(.00065, .16 * speed * speed / (2. * gravity)) * random(uv, noise + .9091);
      }
    }
    next = sign(next) * (grainEdge - abs(grainEdge - abs(next)));
    float layer = clamp((count - 3.) * .000011, 0., .00028) * random(uv, .93);
    #ifdef DUKA_RELIEF
      gl_FragColor = moveOnRelief(particle, next, surface, layer, lift, roundness, supported);
    #else
      float floor = mix(particle.z - particle.w, layer, .18);
      gl_FragColor = vec4(next, max(0., floor) + lift, lift);
    #endif
  }
`;

const resprinkleGrains = /* glsl */ `
  uniform uint pour;
  uniform float pourHeight;
  uniform bool keepXY;
  uniform sampler2D original;
  #ifdef SVG_STENCIL
    uniform bool writeHomes;
    uniform highp usampler2D stencilTable;
    uniform int stencilCount;
    uniform uint stencilMass;
    uniform vec2 stencilPixels;
    uniform vec4 stencilPose;
    uvec2 stencilEntry(int index) {
      int width = textureSize(stencilTable, 0).x;
      return texelFetch(stencilTable, ivec2(index % width, index / width), 0).rg;
    }
  #endif

  // PCG hash of the grain ID and pour number. The upper 24 bits fit a float exactly.
  uint hash(uint inputValue) {
    uint state = inputValue * 747796405u + 2891336453u;
    uint word = ((state >> ((state >> 28u) + 4u)) ^ state) * 277803737u;
    return (word >> 22u) ^ word;
  }

  void main() {
    uvec2 cell = uvec2(gl_FragCoord.xy);
    uint id = cell.y * ${GRAIN_COLUMNS}u + cell.x;
    uint seed = id * 2u + pour * 2654435769u;
    vec2 unit = vec2(hash(seed) >> 8u, hash(seed + 1u) >> 8u) / 16777216.0;
    vec2 xy = keepXY ? texelFetch(original, ivec2(cell), 0).xy : (2.0 * unit - 1.0) * ${GRAIN_EDGE};
    float height = pourHeight;
    #ifdef SVG_STENCIL
      if (!keepXY) {
        // Invert the painted-area CDF. Open space never costs extra attempts,
        // even when the entire population is poured into a fine outline.
        float draw = float(hash(seed ^ 0xb5297a4du) >> 8u) / 16777216.;
        uint ticket = min(stencilMass - 1u, uint(draw * float(stencilMass)));
        int lo = 0, hi = stencilCount - 1;
        while (lo < hi) {
          int mid = (lo + hi) / 2;
          if (stencilEntry(mid).y <= ticket) lo = mid + 1; else hi = mid;
        }
        uint pixel = stencilEntry(lo).x, width = uint(stencilPixels.x);
        vec2 local = (vec2(pixel % width, pixel / width) + unit) / stencilPixels - .5;
        local.y = -local.y;
        if (writeHomes) { gl_FragColor = vec4(local, 0., 1.); return; }
        xy = clamp(stencilPose.xy + local * stencilPose.zw, vec2(-${GRAIN_EDGE}), vec2(${GRAIN_EDGE}));
        height = max(height, 0.);
      }
    #endif
    float z = height < 0. ? 0. : height + .002 + .008 * float(hash(seed ^ 0x8da6b343u) >> 8u) / 16777216.;
    gl_FragColor = vec4(xy, z, z > 0. ? -.02 : 0.);
  }
`;

function seededRandom() {
  let seed: number = SAND_SEED;
  return () => {
    seed ^= seed << 13;
    seed ^= seed >>> 17;
    seed ^= seed << 5;
    return (seed >>> 0) / 4294967296;
  };
}

function plateResistance() {
  const random = seededRandom();
  const samples = Uint16Array.from({ length: RESISTANCE_SIZE ** 2 }, () =>
    THREE.DataUtils.toHalfFloat(0.73 + random() * 0.56));
  const texture = new THREE.DataTexture(samples, RESISTANCE_SIZE, RESISTANCE_SIZE, THREE.RedFormat, THREE.HalfFloatType);
  texture.minFilter = texture.magFilter = THREE.LinearFilter;
  texture.needsUpdate = true;
  return texture;
}

// The ping-pong simulation follows the Three.js GPUComputationRenderer
// approach used in Alexandru Dan's Chladni example, with P1 field and packing.
export class Sand {
  readonly field = new VibrationField();
  private activeCount: number = GRAIN_COUNTS.max;
  private readonly computation: GPUComputationRenderer;
  private readonly variable: Variable;
  private readonly resprinkleMaterial: THREE.ShaderMaterial;
  private readonly wave = new THREE.DataTexture(this.field.wave, WAVE_SIZE, WAVE_SIZE, THREE.RGBAFormat, THREE.FloatType);
  private readonly resistance = plateResistance();
  private readonly packingScene = new THREE.Scene();
  private readonly packingCamera = new THREE.Camera();
  private readonly packing = new THREE.WebGLRenderTarget(PACKING_SIZE, PACKING_SIZE, {
    depthBuffer: false,
    format: THREE.RedFormat,
    type: THREE.HalfFloatType,
    minFilter: THREE.LinearMipmapLinearFilter,
    magFilter: THREE.LinearFilter,
    generateMipmaps: true,
  });
  private readonly packingGeometry = new THREE.BufferGeometry();
  private readonly packingMaterial: THREE.ShaderMaterial;
  private readonly clearColor = new THREE.Color();
  private readonly packingOffset = { value: new THREE.Vector2() };
  private readonly packingAxis = { value: new THREE.Vector2(1, 0) };
  private tick = 0;
  private reliefActive = false;
  private stencil: GrainStencil | null = null;
  private homes: THREE.WebGLRenderTarget | null = null;
  private homesDirty = true;
  private returnProgress = 0;
  private settlingSteps = 30;

  constructor(private readonly renderer: THREE.WebGLRenderer, count: number = DEFAULT_SETTINGS.grainCount,
    readonly form = new Float32Array(GRAIN_COUNTS.max * 4)) {
    if (!renderer.extensions.has('EXT_color_buffer_float')) {
      throw new Error('Floating-point WebGL2 render targets are unavailable.');
    }
    this.computation = new GPUComputationRenderer(GRAIN_COLUMNS, GRAIN_ROWS, renderer);
    const initial = this.computation.createTexture();
    const random = seededRandom();
    const texels = new Uint16Array(GRAIN_COUNTS.max * 2);
    for (let i = 0; i < GRAIN_COUNTS.max; i++) {
      texels[i * 2] = i % GRAIN_COLUMNS;
      texels[i * 2 + 1] = Math.floor(i / GRAIN_COLUMNS);
      initial.image.data[i * 4] = (2 * random() - 1) * GRAIN_EDGE;
      initial.image.data[i * 4 + 1] = (2 * random() - 1) * GRAIN_EDGE;
      // Fine sand distribution with a few larger, slightly warmer grains.
      this.form[i * 4] = 0.000161 * (0.54 + 0.92 * (random() + random()) / 2);
      this.form[i * 4 + 1] = 2 * Math.PI * random();
      this.form[i * 4 + 2] = random();
      this.form[i * 4 + 3] = random();
    }
    this.variable = this.computation.addVariable('sandState', updateGrains, initial);
    this.variable.material.uniforms.wave = { value: this.wave };
    this.variable.material.uniforms.plateResistance = { value: this.resistance };
    this.variable.material.uniforms.driveHz = { value: 0 };
    this.variable.material.uniforms.vibrationOn = { value: true };
    this.variable.material.uniforms.stencilHomes = { value: null };
    this.variable.material.uniforms.homePose = { value: new THREE.Vector4() };
    this.variable.material.uniforms.returnBlend = { value: 0 };
    this.variable.material.uniforms.packing = { value: this.packing.texture };
    this.variable.material.uniforms.packingOffset = this.packingOffset;
    this.variable.material.uniforms.packingAxis = this.packingAxis;
    this.variable.material.uniforms.tick = { value: 0 };
    this.variable.material.uniforms.reliefMap = { value: null };
    this.variable.material.uniforms.reliefPose = { value: new THREE.Vector4() };
    this.computation.setVariableDependencies(this.variable, [this.variable]);
    const failure = this.computation.init();
    if (failure) throw new Error(failure);
    this.resprinkleMaterial = this.computation.createShaderMaterial(resprinkleGrains, {
      pour: { value: 0 }, pourHeight: { value: -1 }, keepXY: { value: false }, original: { value: null },
      writeHomes: { value: false },
      stencilTable: { value: null }, stencilCount: { value: 0 }, stencilMass: { value: 0 },
      stencilPixels: { value: new THREE.Vector2() }, stencilPose: { value: new THREE.Vector4() },
    });

    // Rasterize one additive point per grain into a small world-space occupancy grid.
    this.packingGeometry.setAttribute('position', new THREE.BufferAttribute(texels, 2));
    // The attribute addresses texels. The actual grain coordinates lie on the plate.
    this.packingGeometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(), Math.SQRT2 * HALF);
    this.packingGeometry.setDrawRange(0, this.activeCount);
    this.packingMaterial = new THREE.ShaderMaterial({
      uniforms: { state: { value: this.texture }, packingOffset: this.packingOffset, packingAxis: this.packingAxis },
      depthTest: false,
      depthWrite: false,
      blending: THREE.CustomBlending,
      blendSrc: THREE.OneFactor,
      blendDst: THREE.OneFactor,
      vertexShader: `
        uniform sampler2D state;
        uniform vec2 packingOffset;
        uniform vec2 packingAxis;
        void main() {
          vec4 grain = texelFetch(state, ivec2(position.xy), 0);
          #ifdef DUKA_RELIEF
            if (abs(grain.w) >= .015) { gl_Position = vec4(2., 2., 2., 1.); return; }
          #endif
          vec2 xy = grain.xy;
          mat2 packingRotation = mat2(packingAxis, vec2(-packingAxis.y, packingAxis.x));
          gl_Position = vec4(packingRotation * xy * (2. / .255) + 2. * packingOffset, 0., 1.);
          gl_PointSize = 3.;
        }
      `,
      fragmentShader: `
        void main() {
          vec2 delta = gl_PointCoord - .5;
          float grain = .39 * exp(-4.5 * dot(delta, delta));
          gl_FragColor = vec4(grain, 0., 0., 0.);
        }
      `,
    });
    const points = new THREE.Points(this.packingGeometry, this.packingMaterial);
    points.frustumCulled = false;
    this.packingScene.add(points);
    this.setCount(count);
  }

  get count() { return this.activeCount; }
  get pourIndex(): number { return this.resprinkleMaterial.uniforms.pour.value; }

  initialize(stencilPour: boolean, pour: number) {
    this.tick = 0;
    this.returnProgress = 0;
    this.settlingSteps = 30;
    this.homesDirty = true;
    const u = this.resprinkleMaterial.uniforms;
    u.pour.value = pour;
    u.keepXY.value = !stencilPour;
    u.original.value = this.variable.initialValueTexture;
    try {
      for (const target of this.variable.renderTargets) {
        if (stencilPour || this.reliefActive) this.computation.doRenderTarget(this.resprinkleMaterial, target);
        else this.computation.renderTexture(this.variable.initialValueTexture, target);
      }
    } finally {
      u.keepXY.value = false;
      u.original.value = null;
    }
  }

  setStencil(stencil: GrainStencil | null) {
    const material = this.resprinkleMaterial;
    const homeUniforms = this.variable.material.uniforms;
    if (stencil?.table !== this.stencil?.table || stencil?.count !== this.stencil?.count) {
      this.homesDirty = true;
      this.returnProgress = 0;
    }
    if (Boolean(stencil) !== Boolean(this.stencil)) {
      if (stencil) material.defines.SVG_STENCIL = 1; else delete material.defines.SVG_STENCIL;
      material.needsUpdate = true;
    }
    this.stencil = stencil;
    const u = material.uniforms;
    u.stencilTable.value = stencil?.table ?? null;
    if (stencil) {
      u.stencilCount.value = stencil.count;
      u.stencilMass.value = stencil.mass;
      u.stencilPixels.value = stencil.pixels;
      u.stencilPose.value = stencil.pose;
      // The layer mutates its pose in place. Keep a separate copy to detect a
      // retarget even after all grains have come to rest.
      if (!homeUniforms.homePose.value.equals(stencil.pose)) {
        homeUniforms.homePose.value.copy(stencil.pose);
        this.returnProgress = 0;
      }
    } else if (this.homes) {
      this.homes.dispose();
      this.homes = null;
      homeUniforms.stencilHomes.value = null;
    }
  }

  private prepareHomes() {
    if (!this.homesDirty) return;
    // The pour shader assigns one stable local coordinate to each grain ID.
    // Cache all IDs, so a population change or a moved logo needs no new lookup.
    this.homes ??= new THREE.WebGLRenderTarget(GRAIN_COLUMNS, GRAIN_ROWS, {
      format: THREE.RGFormat, type: THREE.FloatType, depthBuffer: false,
      minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter,
    });
    const writeHomes = this.resprinkleMaterial.uniforms.writeHomes;
    writeHomes.value = true;
    try {
      this.computation.doRenderTarget(this.resprinkleMaterial, this.homes);
    } finally {
      writeHomes.value = false;
    }
    this.variable.material.uniforms.stencilHomes.value = this.homes.texture;
    this.homesDirty = false;
  }

  private advanceReturn(speed: number) {
    if (this.returnProgress >= 1) return 0;
    this.prepareHomes();
    const { progress, blend } = advanceStencilReturn(this.returnProgress, speed, STEP);
    this.returnProgress = progress;
    this.settlingSteps = 30;
    return blend;
  }

  setRelief(texture: THREE.Texture | null, pose: THREE.Vector4) {
    this.settlingSteps = 30;
    const active = texture !== null;
    const uniforms = this.resprinkleMaterial.uniforms;
    uniforms.pourHeight.value = active ? pose.w : -1;
    this.variable.material.uniforms.reliefMap.value = texture;
    this.variable.material.uniforms.reliefPose.value = pose;
    if (this.reliefActive === active) return;
    this.reliefActive = active;
    for (const material of [this.variable.material, this.packingMaterial]) {
      if (active) material.defines.DUKA_RELIEF = 1;
      else delete material.defines.DUKA_RELIEF;
      material.needsUpdate = true;
    }
    // The fourth component is hop height on the flat plate and vertical velocity
    // in relief mode. Rebase both ping-pong states together, retaining every XY.
    const current = this.computation.getCurrentRenderTarget(this.variable);
    const next = this.computation.getAlternateRenderTarget(this.variable);
    uniforms.keepXY.value = true;
    uniforms.original.value = current.texture;
    this.computation.doRenderTarget(this.resprinkleMaterial, next);
    this.computation.renderTexture(next.texture, current);
    uniforms.original.value = null;
    uniforms.keepXY.value = false;
  }

  private writeGrains(first: number, end: number, render: (target: THREE.WebGLRenderTarget) => void,
    half: 'left' | 'right' | 'both' = 'both') {
    for (const target of this.variable.renderTargets) {
      const wasScissored = target.scissorTest;
      const previous = target.scissor.clone();
      target.scissorTest = true;
      try {
        for (const [x, y, width, height] of grainRectangles(first, end)) {
          const middle = Math.floor(width / 2);
          const left = half === 'right' ? middle : 0;
          const right = half === 'left' ? middle : width;
          if (left === right) continue;
          target.scissor.set(x + left, y, right - left, height);
          render(target);
        }
      } finally {
        target.scissor.copy(previous);
        target.scissorTest = wasScissored;
      }
    }
  }

  resprinkle() {
    this.settlingSteps = 30;
    this.homesDirty = true;
    this.returnProgress = 0;
    const pour = this.resprinkleMaterial.uniforms.pour;
    pour.value = (pour.value + 1) >>> 0;
    // Split each occupied row, including the last one for small or uneven populations.
    const half = this.stencil ? 'both' : pour.value % 2 ? 'right' : 'left';
    this.writeGrains(0, this.count, target => this.computation.doRenderTarget(this.resprinkleMaterial, target), half);
  }

  setCount(requested: number) {
    const count = normalizeGrainCount(requested);
    if (count === this.activeCount) return;
    this.settlingSteps = 30;
    if (count > this.activeCount) {
      const u = this.resprinkleMaterial.uniforms;
      u.keepXY.value = this.reliefActive && !this.stencil;
      u.original.value = u.keepXY.value ? this.variable.initialValueTexture : null;
      try {
        this.writeGrains(this.activeCount, count, target => {
          if (this.stencil || this.reliefActive) this.computation.doRenderTarget(this.resprinkleMaterial, target);
          else this.computation.renderTexture(this.variable.initialValueTexture, target);
        });
      } finally {
        u.keepXY.value = false;
        u.original.value = null;
      }
    }
    for (const target of this.variable.renderTargets) {
      target.scissorTest = count < GRAIN_COUNTS.max;
      target.scissor.set(0, 0, Math.min(count, GRAIN_COLUMNS), Math.ceil(count / GRAIN_COLUMNS));
    }
    this.packingGeometry.setDrawRange(0, count);
    this.activeCount = count;
  }

  get texture() {
    return this.computation.getCurrentRenderTarget(this.variable).texture;
  }

  step(frequency: number, vibration = true, returnSpeed = 0) {
    const previousFrequency = this.field.frequency;
    this.field.update(frequency);
    if (this.field.frequency !== previousFrequency) {
      this.wave.needsUpdate = true;
      this.variable.material.uniforms.driveHz.value = frequency;
    }

    this.variable.material.uniforms.vibrationOn.value = vibration;
    if (vibration || returnSpeed <= 0 || !this.stencil) this.returnProgress = 0;
    if (!vibration) {
      this.variable.material.uniforms.returnBlend.value =
        this.stencil && returnSpeed > 0 ? this.advanceReturn(returnSpeed) : 0;
      // Half a simulated second is longer than a fall from the maximum pour
      // height, including a grain already rising when vibration is switched off.
      if (this.settlingSteps > 0) {
        this.computation.compute();
        this.settlingSteps--;
      }
      return;
    }
    this.settlingSteps = 30;
    const { renderer } = this;
    this.tick = (this.tick + 1) % 65_536;
    // Rotate and offset the density grid so its cells cannot imprint on the sand.
    const angle = (this.tick * 2.399963229728653) % (2 * Math.PI);
    this.packingAxis.value.set(Math.cos(angle), Math.sin(angle));
    this.packingOffset.value.set(
      ((this.tick * 0.6180339887) % 1 - .5) / PACKING_SIZE,
      ((this.tick * 0.4142135624) % 1 - .5) / PACKING_SIZE,
    );
    renderer.getClearColor(this.clearColor);
    const alpha = renderer.getClearAlpha();
    renderer.setClearColor(0, 0);
    this.packingMaterial.uniforms.state.value = this.texture;
    renderer.setRenderTarget(this.packing);
    renderer.render(this.packingScene, this.packingCamera);
    renderer.setRenderTarget(null);
    renderer.setClearColor(this.clearColor, alpha);
    this.variable.material.uniforms.tick.value = this.tick;
    this.computation.compute();
  }

  readPositions(maxRows = GRAIN_ROWS) {
    const count = Math.min(this.count, maxRows * GRAIN_COLUMNS);
    const pixels = new Float32Array(count * 4);
    const target = this.computation.getCurrentRenderTarget(this.variable);
    for (const [x, y, width, height] of grainRectangles(0, count)) {
      const offset = (y * GRAIN_COLUMNS + x) * 4;
      this.renderer.readRenderTargetPixels(target, x, y, width, height, pixels.subarray(offset, offset + width * height * 4));
    }
    return pixels;
  }

  dispose() {
    this.homes?.dispose();
    this.resprinkleMaterial.dispose();
    this.variable.material.dispose();
    this.computation.dispose();
    this.packingMaterial.dispose();
    this.packingGeometry.dispose();
    this.packing.dispose();
    this.wave.dispose();
    this.resistance.dispose();
  }
}
