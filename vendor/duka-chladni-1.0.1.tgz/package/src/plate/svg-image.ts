import dukaSvg from '../assets/duka-stencil.svg?raw';
import type { StencilSamples } from './svg-sampling';

export interface SvgImage {
  file: File | null;
  source: string;
  name: string;
  aspect: number;
  artwork: HTMLCanvasElement;
  samples: StencilSamples;
}

function canvas(width: number, height: number, read = false) {
  const element = document.createElement('canvas');
  element.width = width;
  element.height = height;
  const ctx = element.getContext('2d', { willReadFrequently: read });
  if (!ctx) throw new Error('The SVG image could not be rendered.');
  return ctx;
}

function fit(width: number, height: number, longest: number) {
  const scale = longest / Math.max(width, height);
  return [Math.max(1, Math.round(width * scale)), Math.max(1, Math.round(height * scale))] as const;
}

function paintedBounds(ctx: CanvasRenderingContext2D) {
  const { width, height } = ctx.canvas;
  const { data } = ctx.getImageData(0, 0, width, height);
  let left = width, top = height, right = -1, bottom = -1;
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    if (data[(y * width + x) * 4 + 3]) {
      left = Math.min(left, x); right = Math.max(right, x);
      top = Math.min(top, y); bottom = Math.max(bottom, y);
    }
  }
  if (right < left) throw new Error('The SVG has no visible artwork.');
  return { left, top, width: right - left + 1, height: bottom - top + 1 };
}

function prepareSamples(pixels: ImageData, signal: AbortSignal) {
  return new Promise<StencilSamples>((resolve, reject) => {
    signal.throwIfAborted();
    const worker = new Worker(new URL('./svg-sampling.worker.ts', import.meta.url), { type: 'module' });
    const finish = () => { worker.terminate(); signal.removeEventListener('abort', abort); };
    const abort = () => { finish(); reject(signal.reason); };
    signal.addEventListener('abort', abort, { once: true });
    worker.onerror = () => { finish(); reject(new Error('Could not prepare the SVG stencil.')); };
    worker.onmessage = ({ data }: MessageEvent<StencilSamples | { error: string }>) => {
      finish();
      if ('error' in data) reject(new Error(data.error)); else resolve(data);
    };
    worker.postMessage(pixels, [pixels.data.buffer]);
  });
}

// Decode in the browser's isolated SVG image context. Uploaded markup is never
// mounted in the page. Native SVG painting resolves transforms, fills, strokes,
// clipping, and compound paths before we inspect the painted silhouette.
export async function loadSvgImage(file: File | null, signal: AbortSignal): Promise<SvgImage> {
  const source = file ? await file.text() : dukaSvg;
  signal.throwIfAborted();
  const doc = new DOMParser().parseFromString(source, 'image/svg+xml');
  const root = doc.documentElement;
  if (!(root instanceof SVGSVGElement) || doc.getElementsByTagName('parsererror').length)
    throw new Error('Choose a valid SVG file.');
  const vb = root.viewBox.baseVal;
  const intrinsic = (length: SVGLength, fallback: number) =>
    length.unitType === SVGLength.SVG_LENGTHTYPE_PERCENTAGE ? fallback : length.value || fallback;
  const width = intrinsic(root.width.baseVal, vb.width || 300);
  const height = intrinsic(root.height.baseVal, vb.height || 150);
  if (!(width > 0 && height > 0 && Number.isFinite(width + height))) throw new Error('The SVG has an empty viewport.');
  if (!root.hasAttribute('viewBox')) root.setAttribute('viewBox', `0 0 ${width} ${height}`);
  const [pw, ph] = fit(width, height, 1536);
  root.setAttribute('width', String(pw));
  root.setAttribute('height', String(ph));
  const image = new Image();
  const url = URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(root)], { type: 'image/svg+xml' }));
  try {
    image.src = url;
    await image.decode();
    signal.throwIfAborted();
    const probe = canvas(pw, ph, true);
    probe.drawImage(image, 0, 0, pw, ph);
    const box = paintedBounds(probe);
    const [aw, ah] = fit(box.width, box.height, 2048);
    const art = canvas(aw, ah);
    art.scale(aw / box.width, ah / box.height);
    art.drawImage(image, -box.left, -box.top, pw, ph);
    const [sw, sh] = fit(box.width, box.height, 1024);
    const mask = canvas(sw, sh, true);
    mask.drawImage(art.canvas, 0, 0, sw, sh);
    const samples = await prepareSamples(mask.getImageData(0, 0, sw, sh), signal);
    return { file, source, name: file?.name ?? 'Duka logo', aspect: box.width / box.height, artwork: art.canvas, samples };
  } finally {
    URL.revokeObjectURL(url);
  }
}
