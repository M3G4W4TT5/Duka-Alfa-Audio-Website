# Chladni plate

A standalone Astro and React experiment for the S45C P1 plate. The overhead WebGL2 scene starts at the maximum of 589,824 individually simulated grains.

The title at the top left switches between **Chladni plate** and **Water Cymatics**. Switching pauses the outgoing simulation. Returning to the plate resumes the current grains, settings and camera.

```powershell
npm ci
npm run check
npm run build
npm run preview
```

Open [http://127.0.0.1:4322/](http://127.0.0.1:4322/). Cloudflare Pages can use `npm run build` and publish `dist/`. The project requires Node 22.12 or newer and a WebGL2 browser with floating-point render targets.

## Water Cymatics

Open **Water Cymatics** from the title or append `?sim=water` to the preview URL. **Tone** starts with a silent visual preview. Drag **Frequency** or type an exact value from 20 to 1,000 Hz, then choose **Listen to tone** to hear it. **Volume** controls both the shaker and the audio output.

Choose **MP3 → Choose MP3 → Play MP3** to play a file from your device. The browser plays the full track locally. An 8,192-sample spectrum analyser sends up to six peaks in the 20–1,000 Hz drive band, with their measured levels, to the water. The timeline supports seeking. Quiet passages, pauses and the end of the track let the waves decay. Switching simulators pauses playback and keeps the track position for your return.

**Controls** contains the spotlight rig, colour gradients, strobe and bloom used by both experiments. The water opens with neutral lights. A moving reflection reveals the slope of each wave on the opaque surface. **View angle** tilts the camera, scrolling zooms the dish, and **Motion speed** slows the visible wave cycles independently of audio playback.

Under **Controls → Dish → Shading**, choose **Liquid** or **Point cloud**. Both show the same moving water and spotlight reflections. Point cloud draws those reflections in fine stipple on charcoal. Switch finishes while a tone or MP3 is playing, or append `?sim=water&shading=points` to open directly in Point cloud. [Both finishes at the same instant, driven at 131 Hz](verification/water-cymatics/point-cloud-comparison.jpg)

The virtual dish is 104 mm across with 7 mm of water. Circular standing modes satisfy a reflecting wall and use the finite-depth gravity–capillary dispersion relation. The dominant response is at half the drive frequency, with a weaker harmonic response from the edge. The forcing, damping and optical finish are tuned to the supplied footage and photographs. [NASA analysis of vibrated liquid surfaces, equations 8 and 13 and figure 20](https://ntrs.nasa.gov/api/citations/20230017252/downloads/AIAA-SciTech-2024-Surface-Instability.pdf)

`npm run check:water` checks the circular modes, frequency analysis, volume response, rapid retuning and decay to rest. In Chrome, a local MP3 with a 68 Hz tone, silence and a 181 Hz tone produced two distinct patterns and settled to the still-water image during silence. Switching simulators preserved the positions of all 1,000 grains in the test plate. [Desktop view](verification/water-cymatics/desktop.jpg) · [MP3 playback](verification/water-cymatics/mp3.jpg) · [Mobile layout](verification/water-cymatics/mobile.jpg)

## Compose a website background

Open **Controls → View**. **Window** uses the browser’s available space. **Desktop** previews 1920 × 1080 CSS pixels and **Mobile** previews 402 × 874 CSS pixels in portrait. Each reference frame scales down to fit the editor. Switching views keeps the current grains, lighting and drive running.

Choose **Edit crop** to drag the scene or zoom around the pointer with the wheel. On a touchscreen, drag with one finger or pinch with two. The square overview shows sampled live sand and the active crop. Drag the rectangle to move it, drag a corner to resize it, or choose **Draw crop** and drag out a new rectangle. The X/Y centres and zoom also accept typed values. **Fit whole plate** centres the entire square with its original margin. **Fill frame** centres the largest rectangle of the view’s aspect ratio inside the square. **Interact** restores the usual drive and lighting controls.

Frame Desktop and Mobile independently and enable **Use this crop on the website** for each wanted view. **Mobile below** sets the component width where the mobile crop takes effect. The default is 768 CSS pixels. At that width and above, the component uses the desktop crop. A disabled profile falls back to Window framing. Between reference sizes, the camera keeps the saved centre and takes the largest rectangle of the container’s aspect ratio inside the saved crop.

### Save and reopen a look

Open **Controls → Configuration**, choose **Starting sand**, then **Export configuration**. **Loose sand** starts from the seeded spread. **Poured into stencil** uses the selected SVG, outline or fill, placement and pour number. **Settled pattern** runs six simulated seconds at the captured frequency before revealing the scene. All three then use the saved vibration and interaction settings. **Import configuration** reopens the file in the editor.

Each `.chladni.json` records the schema and engine version, all scene settings including inactive controls, the live drive and pointer-driven lighting state, the starting sand, both device profiles, Window framing and the last editor view. Rectangles use square-plate coordinates with the origin at the upper left and a unit plate side. Rectangles can extend past the plate. A null Window crop follows the whole plate as the host resizes. Uploaded SVG source travels inside the file. Built-in geometry, surface maps and the Duka stencil resolve by versioned identifiers in this simulator. The file recreates a starting arrangement and its motion settings. Individual live grain positions are transient.

**Controls only** is the first switch in the Chladni controls. It hides the title, simulator picker, and drive display. The canvas and controls stay in place. The preference travels with the export. Older exports open with the switch off.

## Use Chladni in a website

`@duka/chladni` ships a source package for Astro/Vite with React 19 peer dependencies. The standalone app uses the same editor entry point. To pack the current version, run `npm pack --ignore-scripts` at this workspace root. Version 1.0.0 produces `duka-chladni-1.0.0.tgz`. To pin a release, copy the tarball into the consumer and run `npm install ./vendor/duka-chladni-1.0.0.tgz` there. Keep that tarball with the consumer's lockfile. Increment this workspace's package version and update its lockfile before packing a new release.

For working-source changes, use `npm install --no-install-links "file:../Duka Motion Experiments"` in a sibling consumer, adjusting the path to this workspace as needed. Keep React and React DOM installed in the host. Add these options to the host's Vite configuration, under `vite` in Astro. For a link outside the consumer workspace, also include the simulator workspace in `server.fs.allow` when Vite restricts access.

```js
optimizeDeps: { exclude: ['@duka/chladni'] },
resolve: { dedupe: ['react', 'react-dom'] },
```

### Player

Place a saved look in the site's source tree and pass it to the player. The containing element supplies the CSS viewport. The component validates the preset before initializing WebGL and selects the enabled Desktop or Mobile crop using the container width. The Window crop is the fallback.

```astro
---
import { ChladniPlayer } from '@duka/chladni/player';
import look from '../looks/hero.chladni.json';
---
<div class="hero-background">
  <ChladniPlayer client:only="react" configuration={look} />
</div>
<style>
  .hero-background { width: 100%; height: 100svh; }
</style>
```

For menu interaction, render the player inside the host's React tree, attach a `ChladniPlayerHandle` ref and forward the host's `onPointerMove` and `onPointerLeave` to `ref.current?.movePointer(event)` and `ref.current?.leavePointer()`. Both components accept a React or native pointer event. Pointer movement over a `data-plate-controls` ancestor, touch gestures, and movement with a button held are ignored. The host owns clicks, keyboard shortcuts and scrolling.

### Editor

Import `ChladniEditor` and `ChladniEditorHandle` from `@duka/chladni/editor`. In the site's React island, give the editor a sized parent and set `layout="container"`. Optionally pass `controlsOutlet={element}` using a callback ref to a positioned overlay element over the menu in the same React tree. The outlet fills that element. Set the overlay's stacking level in the host and use `pointer-events: none` on its empty area. The controls handle their own hit testing.

Select **Desktop** or **Mobile** in **View**, then choose **Edit crop**. The canvas stays at the host container's actual size and the overview supports both panning and zooming. Enable **Use this crop on the website** to apply the saved profile in the player.

Open a saved configuration with `initialPreset` on mount, the panel's **Import configuration** button, or `await ref.current.loadPreset(preset)`. The latter accepts a parsed object, JSON text or a `File`. **Export configuration** downloads the same validated document as `ref.current.capturePreset()`. For **Lock & preview**, capture while the editor is ready, then pass that document to the player. Capture throws during loading or if a chosen SVG could not be loaded. Keep the configuration prop stable between host renders.

Both components accept `active={false}` to suspend rendering and input. An initially inactive component waits to initialize WebGL. To resume the same grains and crop, keep the component mounted and set `active` back to true. `createStarterPreset({ controlsOnly: true })` and `parseConfiguration(input)` are available from either entry point. The starter also accepts a `grainCount` option.

Existing source consumers can still import the default `src/components/Chladni` component. Passing `configuration` opens the player. Omitting it opens the standalone editor. The `?qa` diagnostics are scoped to the standalone editor.

Run `npm run check:configuration` for geometry, state restoration and file-format checks.

[Nested diamond example](verification/responsive-views/nested-diamond.chladni.json) saves the 1,535 Hz figure with two fixed lights and independent desktop and mobile crops. Import it to edit the compositions shown in the [desktop preview](verification/responsive-views/desktop.jpg) and [mobile preview](verification/responsive-views/mobile.jpg). GPU settling can move individual grains into slightly different positions within the same figure.

Move up and down to sweep frequency and left and right to sample the light gradient. The sand starts at 126 Hz, and the default sweep covers 100–182 Hz. The drive blends small pointer changes over about a tenth of a second. The readout shows tenths of a hertz. The spotlight follows the cursor’s direction and holds its last direction within 12 px of the centre. Scroll over the plate to zoom towards the mouse. **Esc** on the plate or **Reset zoom** returns to the whole plate.

Under **Controls → Drive**, choose **Vertical** to increase upwards or **Horizontal** to increase rightwards. In **Patterns**, choose **Disable** to keep the pointer on lighting and select a figure from the catalogue or with the arrow keys. Returning to **Frequency** uses the selected axis again. Drag the frequency range handles or enter the limits directly, up to 3,000 Hz. **Full range** sets the limits to 0 and 3,000 Hz. Set both limits to the same value to hold a frequency while you move the lights. The arrow keys along the drive axis tune the linear sweep in 1 Hz increments.

**Controls → Background → 3D** raises the six-part Duka logomark from the plate. It starts centred at 50% of the plate width and 1 mm high. Set the width from 15–100% and the height from 0–4 mm. X and Y measure millimetres from the plate centre, positive right and up. Their limits keep the whole mark on the plate. [Open the Duka relief](http://127.0.0.1:4322/?background=3d&mode=patterns)

In **Solid**, the logo, plate and sand receive the spotlights and strobe, and the relief casts shadows. In **Pass through**, the logo drops out of all light shadow maps and the background takes a fixed neutral fill. The same lights continue to illuminate the grains and the grains shadow each other. Switching lighting preserves the sand state. [Solid at 181 Hz](verification/duka-relief/solid.jpg) · [Pass through with the same sand](verification/duka-relief/pass-through.jpg)

**Background material** sets the base colour, finish and texture. **Logo material** has a separate link to the background for each of those three properties. Unlinking starts from the current background value. A shared texture lines up across the cap and plate. An independent logo texture follows the mark as it moves. Texture scale and rim width use physical millimetres on the plate.

Choose **Matte**, **Satin metal** or **Polished chrome**, then adjust metalness, roughness and studio reflections. Two neutral overhead softboxes provide reflections across a polished surface. A light grey base produces bright chrome. **Brushed steel** has directional scratches, **Fine grit** adds small pits, and **Corroded steel** varies roughness and metallic coverage. Its **Texture colour** slider blends in the scanned oxide colours.

**Logo effects** has its own colour. Choose **Colour overlay** for a painted outline with adjustable opacity, or **Neon** for an emitting surface. **Top edges** traces the upper perimeter of every solid part, including the inside curves. **Whole logo** covers each visible face. **Emission** sets the neon brightness before bloom. **Light spill** in Solid mode estimates local illumination of the nearby sand and plate from the rim or emitting surface. Pass through keeps the emission visible and turns off its spill. The global **Bloom** controls set the optical halo. [Open the neon outline in Chrome](http://127.0.0.1:4322/?background=3d&mode=patterns&effect=neon)

At 126 Hz, the same frozen sand and brushed satin logo show a 0.4 mm rim at 3.5× emission and a filled mark at 1.15×. [Neon edges](verification/logo-effects/neon-edges.jpg) · [Whole-logo emission](verification/logo-effects/neon-whole.jpg)

The textures are self-hosted and load on selection. The brushed and corroded finishes use CC0 scans. Fine grit is generated from a tileable seeded height field. [ambientCG Metal 012](https://ambientcg.com/view?id=Metal012) · [Poly Haven Metal Plate 02](https://polyhaven.com/a/metal_plate_02)

To regenerate the four surface assets, run `node scripts/prepare-surface-maps.mjs <source-directory>`. Supply the ambientCG 1K JPG files `Metal012_1K-JPG_NormalGL.jpg` and `Metal012_1K-JPG_Roughness.jpg`, and the Poly Haven 1K JPG normal (OpenGL), ARM and diffuse maps named `corroded-normal.jpg`, `corroded-arm.jpg` and `corroded-colour.jpg`.

Entering 3D drops the existing grains over their current positions. **Resprinkle** pours half the population from above. The GPU integrates vertical gravity and inelastic landings, tests horizontal hops against the walls and lets released grains fall from ledges. Rendering uses the supplied GLB. The contact map is baked from its upper triangles and wall contours with `node scripts/bake-duka-contact.mjs`. This experiment uses the flat plate’s vibration modes for the drive. It models how the raised surface redirects the sand and light.

**Controls → Drive → Particle count** accepts any whole number from 100 to 589,824. Drag the slider or type an exact count beside it. **Particle size**, directly below, scales the grains and their shadows from 0.25× to 10×. The default is 1×. Increasing the count sprinkles fresh sand through the active stencil or across the plate. Decreasing it removes grains immediately. Surviving grains keep their position, hop height and contact characteristics. Only the active grains contribute to packing, physics, lighting and shadows.

Turn on **Particle shape smoothing** below **Particle size** to give each grain a spherical surface and shadow. You can switch shapes while a pattern is forming. The default is faceted sand.

Sweeping the frequency can leave parts of a pattern short of sand. **Resprinkle**, beside **Particle count**, scatters half the grains across the plate at the current tuning. The other half stays in place. A second press scatters the other half, and each press generates fresh positions. At 3,000 Hz, redistributing half the sand can reveal the Window lattice’s two central arcs. [Drive controls in Chrome](verification/particle-count/resprinkle-controls.jpg) · [Before and after sprinkling](verification/particle-count/resprinkled.jpg)

At 3,000 Hz, runs with 147,456, 294,912 and 589,824 grains covered 91%, 96% and 97% of sampled vibration troughs. At 2,680 Hz the same counts covered 73%, 76% and 79%. Each Chrome run started with the same seeded distribution and advanced 360 physics steps. On a 0.5 mm sampling grid, we counted low-vibration local minima along either plate axis in the lowest quarter of the acceleration field. A sample counted as covered when at least one grain was within 0.25 mm. [Matched pattern comparison](verification/particle-count/complex-patterns.jpg)

At 1080p on the RTX 5080 Laptop GPU, 294,912 grains with two spotlights measured 7.0 ms at the 95th percentile over 180 presented frames. The maximum count with four spotlights measured 14.0 ms. Indexed shadow geometry produced identical frozen frames with two, four and five active light directions. [Chrome measurements](verification/particle-count/measurements.json)

## SVG stencils and artwork

To make a sand logo, turn off **Drive → Vibration**, enable **SVG layer** and click **Resprinkle into shape** beside **Particle count**. The entire active population falls through the stencil and settles on the plate or the Duka relief. Choose a frequency or a pattern while the grains are still. Switch **Vibration** on to release those same grains into the selected pattern. [Fill, outline and release in Chrome](verification/svg-stencil/pour-and-release.jpg)

The built-in Duka mark starts centred at 50% of the plate width. **Upload SVG** selects artwork for this tab and **Use Duka logo** restores the original. Size and X/Y position follow the painted bounds, ignoring transparent margins. **Fill** distributes grains over the painted area. **Outline** traces its outer edges and the edges of its holes. **Outline weight** sets the inward width in millimetres.

With **Use as stencil** enabled, turn on **Drive → Return to stencil** to cycle between a logo and a Chladni figure. Switching vibration off glides each grain to its own place in the current stencil. Switching vibration on releases the grains from wherever they have reached. A return takes 3 seconds at 1×. The **Return speed** slider covers 0.25× to 4× and can be adjusted during the movement. Moving or resizing the stencil while vibration is off gives the grains a new destination. With **Return to stencil** off (the default), the sand settles in place and stencil edits apply to the next pour. [Watch the 181 Hz cross return to the Duka mark](verification/svg-stencil/return-to-stencil.webp)

**Show artwork** displays the SVG in its own colours on either background. It works with or without the stencil. Set **Artwork height** to 0 mm to print it on the plate or raise it up to 8 mm. **Artwork opacity** also controls how much light passes through its painted parts when **Cast shadows** is enabled. Spots and the strobe project those shadows onto the scene. Grains pass through the artwork and land on the physical surface below.

`npm run check:stencil` checks the filled area, outline width, holes, alpha weighting, plate placement and return timing.

## Spotlights and strobe

Select a light under **Spotlights** to adjust its intensity, elevation and beam width. Its position can follow the pointer or sit at a fixed angle. Use the **Light angle** slider, type the degrees beside it, or drag a numbered handle around the plate diagram. Angles start at 0° at the top and increase clockwise. Switching **Position** to **Fixed angle** holds the rendered direction. Switching **Colour source** to **Fixed colour** captures the rendered colour for editing with the picker. [Spotlight and strobe angle controls](verification/lighting-rig/angle-and-strobe.jpg)

The horizontal gradient runs left to right and the vertical gradient runs bottom to top. Both use the same editable gradient and can share the drive axis. Click the gradient ramp or **Add stop** to add a colour stop. Adjust its **Stop position** slider or enter the percentage beside it. **One light** follows the pointer. **Two lights** places a violet key at ten o’clock and a copper fill at four o’clock at one-third intensity. Add individual lights or choose the three- or four-light preset.

The **Strobe** starts off. **Hold** and **Automatic** reveal its controls. Hold a mouse or touch on the canvas, or hold **Space** with the plate focused, to trigger Hold mode. Automatic runs while the tab is visible and the window is focused. The strobe can use a numbered light’s direction or its own **Strobe angle** slider. The rate, flash width, flashes per burst and gap are sliders. The defaults give three 70 ms flashes at 2 Hz, followed by 1,000 ms of darkness. Set the burst size to **Continuous** to hide the gap and keep pulsing. [Strobe controls in Chrome](verification/particle-count/strobe-sliders.jpg)

The standalone experiment allows 0.25–50 Hz. At up to 25 Hz, flash width leaves at least 20 ms dark between pulses within a burst. Above 25 Hz, at least half of each cycle stays dark. At 50 Hz the flash can last 1–10 ms. Showing all 50 pulses with a distinct dark frame between them requires at least 100 rendered frames per second on a display with a matching refresh rate. Shorter flashes may need still faster rendering. Up to 3 Hz, the clock limits starts to three in any rolling second, including repeated manual triggers. Higher rates can exceed the simple flash-count criterion for a fullscreen website. [W3C guidance on flash thresholds](https://www.w3.org/WAI/WCAG22/Understanding/three-flashes-or-below-threshold.html)

Run `npm run check:lighting` to verify drive-axis input, light arrangements, and strobe timing across releases, cadence edits and frame stalls. Append `?qa` to inspect the rendered lamp states, shadow count and strobe output with `window.chladni.state()`.

## Bloom

**Spread** sets the halo width in screen space. **Falloff** controls how quickly its outer glow fades. Lower falloff gives a gradual veil around a crisp centre, while higher falloff draws the halo in close to the grains. The default uses 44% spread and 35% falloff. **Threshold** selects which highlights feed the bloom, **Strength** sets how much light they add, and **Grit** textures the halo. [Matched cluster and ridge close-ups](verification/bloom/comparison.jpg)

The bloom pass extracts highlights in linear light with a soft threshold, then filters them through five normalized circular Gaussians. Each filter extends to roughly four standard deviations. Horizontal and vertical filtering each precede downsampling along that axis. The two falloff profiles have the same total weight and approximately the same half-maximum radius. Their outer tails carry different amounts of light. The approach follows the multiscale glow filter described in [GPU Gems, “Real-Time Glow”](https://developer.nvidia.com/gpugems/gpugems/part-iv-image-processing/chapter-21-real-time-glow).

In a Chrome GPU test with an isolated 7 px highlight at the default spread, changing falloff from 0% to 100% moved the 2%-of-peak radius from 47.3 to 25.1 CSS px. The half-maximum radius moved from 7.74 to 7.58 px. At the default falloff, the angular variation in radius at 5% of peak fell from 16.4% to 0.7% compared with the previous pass, measured as peak-to-peak variation divided by mean radius along 72 rays. Both bloom-off comparison frames matched their originals pixel for pixel. Run `npm run check:bloom` for the kernel, profile and display-density regression checks.

## Pattern guide

Choose **Controls → Drive → Patterns**, or [open the guide directly](http://127.0.0.1:4322/?mode=patterns). Move upwards or rightwards along the selected axis from the 107 Hz halo to the 3,000 Hz lattice. Each figure gets an equal share of travel along that axis. Hold near its position to let the sand settle. Click a thumbnail to reach its exact frequency, or focus the plate and use the arrow keys along the drive axis to visit neighbouring figures. **Frequency** returns to the linear sweep with your previous range.

The thumbnails show the density of actual grains. We surveyed the model at 1 Hz intervals through 210 Hz and 5 Hz intervals above it, then compared 98 candidate figures in Chrome. Each comparison started with the same sprinkle and ran for 360 fixed physics steps. Finer samples around the closely spaced P1 figures helped set their tuning widths. The live experiment carries its grains through the sweep, so the approach direction and settling time affect how fully each line fills. [Illustrated catalogue](verification/patterns/catalogue.jpg)

| Pattern | Hz | Pattern | Hz |
| --- | ---: | --- | ---: |
| Soft halo | 107 | Split eye | 992 |
| Double ring | 126 | Floating arcs | 1,014 |
| Tall oval | 154 | Twin figure eights | 1,093 |
| Bowed sides | 157 | Four diamonds | 1,120 |
| Parallel bands | 160 | Ring and petals | 1,287.5 |
| Open hourglass | 175 | Nested diamond | 1,535 |
| Diagonal cross | 181 | Octagonal frame | 1,800 |
| Single ring | 196 | Scalloped rings | 2,074.3 |
| Rounded diamond | 298 | Scalloped diamond | 2,315 |
| Corner arcs | 365 | Split windows | 2,450 |
| Ring and arcs | 447 | Broken spokes | 2,538 |
| Square grid | 548 | Diamond chains | 2,680 |
| Edge cups | 626 | Edge lenses | 2,852 |
| Cushion and ring | 947 | Window lattice | 3,000 |

The 548 Hz grid shares the axial divisions of Wheatstone’s figure 43, with fewer cells. The 1,535 Hz figure shows the nested outlines seen in figures 53 and 64. The 3,000 Hz lattice is the closest catalogue entry to the repeating cells in figure 47. These are visual correspondences. The frequencies above belong to this virtual steel plate. Its centred drive selects shapes with reflection symmetry about both axes. Historical figures that break those symmetries require a different excitation or plate setup. [Wheatstone’s original figures, pp. 611, 613 and 615](https://upload.wikimedia.org/wikipedia/commons/5/5b/On_the_Figures_Obtained_by_Strewing_Sand_on_Vibrating_Surfaces%2C_Commonly_Called_Acoustic_Figures_%28IA_jstor-108009%29.pdf)

Each stop has a positive local tuning slope. A quintic blend joins neighbouring slopes and preserves both first and second derivatives. For example, the guide stays within 0.09 Hz of the 181 Hz cross across the central 48% of its interval. Faster pointer moves ease through catalogue positions before the frequency curve is applied, so the narrow bands also receive time on a quick sweep. Only the resulting drive frequency goes into the existing vibration and sand simulation. `npm run check:patterns` exercises the mapping in both directions, its inverse, exact selection, and switching to and from a locked frequency.

## Model and rendering

- `npm run modes` regenerates the six mass-normalized Rayleigh–Ritz modes from the plate's bending energy. The script records the 180 × 180 × 1.15 mm dimensions, steel constants, stiffness split, pole adjustments and damping. The trial space leaves the outer edges unconstrained and retains the reflection-even modes coupled to the centre mount.
- Through 210 Hz the simulated shaker uses effective generalized loads fitted to sparse P1 photo geometry, a pole/zero fit to the Table III peaks and dips, and complex damped modal superposition. The extension outside the photographic band is approximate. At 0 Hz the driven acceleration, drift and hops are all zero. From 210 to 260 Hz a smooth blend of squared displacement envelopes joins the original fit to the centre-driven model. The legacy tail uses its one-sided slope at 210 Hz and a 5 Hz decay scale. [P1 Figure 4 and Table III](https://eu-opensci.org/index.php/ejeng/article/download/63165/13111)
- From 260 Hz the field is the predicted steady-state response of a free-edge Kirchhoff–Love plate to a sinusoidal peak force of 2.977 N on a centred 1.5 mm radius patch. The model uses a 36 g rod and 2,000 N/m spring acting on the patch average, the calculated steel-plate mass of 292.491 g, the fitted 1.5% directional stiffness split and an estimated mode damping ratio of 0.020. The uniform load footprint and the match to the legacy RMS acceleration at 198, 204 and 210 Hz are modelling choices. The same force drives the entire high band, so weakly coupled modes and quiet intervals remain visible. High-band figures are predictions for this virtual plate. [P1 experimental setup](https://doi.org/10.24018/ejeng.2024.9.3.3165) · [Tuan et al.](https://pmc.ncbi.nlm.nih.gov/articles/PMC6052176/)
- The centre drive couples only to modes even in both axes. The browser sums the signed real and imaginary responses on a 57 × 57 quadrant and uploads one float texture on frequency changes. Each grain reconstructs the wave at its own position with bicubic Catmull–Rom interpolation, then derives local acceleration and downhill drift from that same wave and its derivatives. Reflection at the centre and one-sided slopes at the free edges complete the stencil. Near a trough the downhill step is limited by the estimated distance to its minimum. At 3,000 Hz the estimated bulk wavelength is 61.0 mm, about 53 plate thicknesses. The retained poles extend to 11,696.86 Hz with a 12 kHz cutoff to capture off-resonance contributions.
- The grain model derives takeoff speed, flight time and a stochastic hop rate from local harmonic acceleration. A calibrated drift toward quieter areas speeds up settling, and a local density field approximates packing and stack height. Each grain has a persistent sliding threshold with an angularity distribution and a smooth contact variation fixed to the plate. Weak agitation leaves loose grains resting, and stronger vibration or pressure can release them. The contact threshold is independent of the vertical hop test. Sliding, slip, impact scatter and the reflecting edge are modelling choices. The display advances the same fixed 60 Hz model steps at 2.25× playback speed. The sparse-grain membrane results motivate differential mobility, and the steel-specific constants are visual calibration. [Abramian et al.](https://doi.org/10.1103/PhysRevResearch.7.L032001)
- The GPU-resident particle update reuses Three.js's `GPUComputationRenderer`, following the architecture of Alexandru Dan's Chladni demo. Schladni was a second reference for high-density ballistic grains on a free square plate. The P1 field, sand packing, and lighting shaders are local implementations. [Dan's Chladni implementation](https://github.com/danlex/particles/blob/main/chladni.html) · [Schladni](https://github.com/MaestroMed/schladni)
- The grains average 0.161 mm across, about 0.8 px on a 900 px plate. Lights aim at the physical plate centre from a radius of 148 mm. The default elevation puts the lamp 28 mm above the plate. Inverse-square falloff and depth maps projected from the active directions give directional highlights and shadows. Lights at the same position share a depth map. Direct contributions add in linear space before grain highlight compression and the shared HDR bloom. The smooth, nearly neutral stage has a faint hue bias and a separate light film grain finish.

## Wide-band mode generation

The generated asset is `src/plate/wide-modes.json`. Astro and Cloudflare Pages consume it directly. To regenerate it, use Python 3 with NumPy and Node 22.12 or newer, then run `npm run modes:wide`. The generator calibrates against the current legacy field with Node. It checks degrees 32 and 48, solves the degree-64 production basis in float64, and compares the retained response with all 1,681 modes of the degree-80 model. Each order denotes the maximum Legendre degree per axis. Runtime coefficients are stored as float32 after checking the effect of that quantization.

Use `npm run modes:wide -- --max-drive-hz 3000 --retain-hz 12000` to set the drive and retention limits explicitly. Review the wavelength-to-thickness ratio and the frequency and spatial convergence report whenever raising the limit. The 210 Hz legacy endpoint, the generated drive limit and the retained spectrum are independent.

The [solver report](verification/3000hz/solver.json) records the four distinct free-plate benchmarks, the rigid translation and tilts, eigenpair checks, mounted poles and 1 N RMS amplitudes. The specified mounted pole and RMS errors are below 0.036% and 0.154%. On the 883 Hz centre cuts the positive-axis troughs are at 22.83/61.33 mm horizontally and 21.80/63.11 mm vertically. The deeper outer troughs are within 0.20 mm of the supplied values. [Leissa, *Vibration of Plates*](https://ntrs.nasa.gov/citations/19700009156)

At 3,000 Hz the complex field with 37 retained modes differs by 0.50% in spatial L2 norm from the degree-80 reference. A 4.5 kHz cutoff gives 10.49% error. The sweep sampled every 5 Hz found a maximum combined error of 1.43% near 2,080 Hz. Reconstructing the signed wave adds about 0.004% RMS acceleration error at 3,000 Hz against direct evaluation on a 449 × 449 grid. Across the measured upper-band cuts, prominent troughs were within 0.16 mm of the higher-order fine-grid result.

## Curve continuity at 2,074.3 Hz

The matched Chrome captures start with the same 147,456 seeded grains, use the same lamp and camera, and advance exactly 240 physics steps. Along 360 directions from the centre, we measured the brightness-weighted centre of each rendered ridge against the radial vibration minimum of the virtual plate. The RMS distance fell from 0.298 to 0.075 mm for the inner ring and from 0.297 to 0.080 mm for the outer ring. [Matched detail](verification/curve-continuity/comparison.jpg) · [Full previous frame](verification/curve-continuity/before.jpg) · [Full revised frame](verification/curve-continuity/after.jpg)

`npm run check:curves` checks the runtime sampler against independently evaluated modes on cuts through both rings and across all four quadrants, then checks the two model joins and rest. In matched 10-second full-range sweeps on the RTX 5080 Laptop GPU at 1920 × 1080, DPR 1, both builds recorded a 7.0 ms p95 frame interval. The p95 CPU time for the simulation step fell from 2.1 ms to 0.5 ms.

## 3,000 Hz Chrome verification

The [legacy pattern comparison](verification/3000hz/legacy-patterns.jpg) shows the 126 Hz rings, 160 Hz bands and 181 Hz X in both builds. The [sand and acceleration comparison](verification/3000hz/sand-and-acceleration.jpg) uses the same light and zoom at rest and at 883, 1,024, 2,082 and 3,000 Hz. At 883 Hz, the sand sampled a mean of 2.95 g compared with 24.12 g across the plate. At 3,000 Hz the respective means were 0.58 g and 2.64 g. The existing contact model allows grains to stay in local valleys, so prior drive frequencies affect which parts of a trough fill. The plate field is zero at rest and the grains can retain their previous arrangement.

Chrome exercised slow passage through 210 and 260 Hz, rapid full-range reversals, the 0 and 3,000 Hz limits, numeric validation and keyboard tuning. At a locked 883.4 Hz, the same grain positions and field remained in place during a horizontal lamp move. A mouse wheel gesture reached 2.67× around the selected point and Escape returned to the full plate. The [browser measurements](verification/3000hz/browser.json) include the timings and sampled grain statistics.

The foreground production runs used 1920 × 1080 at DPR 1 with 147,456 grains, an Intel Core Ultra 9 275HX and an NVIDIA GeForce RTX 5080 Laptop GPU. The frame interval measures presentation cadence through `requestAnimationFrame`. The logged CPU simulation and rendering submission times exclude asynchronous GPU work.

| Warmed sweep | Frames | Median | p95 | Worst | Over 16.7 ms |
| --- | ---: | ---: | ---: | ---: | ---: |
| 0–3,000 Hz, 10 s | 1,012 | 7.0 ms | 27.8 ms | 111.2 ms | 115 |
| 0–3,000 Hz repeat, 10 s | 345 | 34.7 ms | 34.8 ms | 41.7 ms | 295 |
| 100–182 Hz comparison, 8 s | 499 | 7.0 ms | 34.8 ms | 736.0 ms | 120 |

Frame cadence varied between runs and exceeded the 16.7 ms budget in both bands. Across the two full sweeps, the CPU simulation step took at most 2.3 ms at p95, and render submission took at most 0.3 ms at p95.

## First-pass Chrome verification

[Figure 4 comparison](verification/p1-comparison.jpg) shows both ring radii at 126 Hz, two vertical bands 56% of the plate width apart at 160 Hz, and four diagonal arms at 181 Hz. The outer ring is narrower than the photographed halo. The bands are wider and more uniform than photographed, and the X carries more sand across the centre and toward the corners.

[Fixed-frequency light comparison](verification/lighting-160.jpg) shows the same grain positions at 160 Hz. Moving the lamp from left to right changes the lit faces and reverses the shadows. The sampled background was `#31293e` at the left and `#3a2d2a` at the right, within one 8-bit channel step of the colour targets.

Both timing runs used the production build in foreground desktop Chrome at 1920 × 1080, DPR 1, with an RTX 5080 Laptop GPU. The tests recorded the interval between animation frames for ten seconds while driving the normal pointer handler.

| Interaction | Frames | Median | 95th percentile | 99th percentile | Worst |
| --- | ---: | ---: | ---: | ---: | ---: |
| Frequency and lamp sweep | 1,441 | 6.9 ms | 7.0 ms | 7.1 ms | 7.1 ms |
| Horizontal lamp sweep at 160 Hz | 1,438 | 6.9 ms | 7.0 ms | 7.1 ms | 13.9 ms |

## Second-pass Chrome verification

[Lighting comparison](verification/round-02/lighting-before-after.jpg) repeats the frozen 126 Hz ring test at 1920 × 935 with the pointer at x = 441 px and the hue fixed within each pair. Moving from 5% to 50% of viewport height changed the brightest 1% of the square crop from 0.491 to 0.259 mean linear luminance in the first build and from 0.497 to 0.502 in the revised build. Grain positions matched within each pair. The lamp completed a full turn at constant radius and height, held its aim across the centre, and moved the lit facets and shadows in Inspect view. Repeated captures of the stationary close-up were identical after the camera settled.

[Sand comparison](verification/round-02/sand-comparison.jpg) uses the same plate scale for the P1 crop and the simulated views. The seeded sprinkle had 16,161 grains after 7 seconds and 16,229 after 34 seconds in the radial interval from 0.60 to 0.85 of the plate half-width. This interval samples between the rims for the 126 Hz figure. The 160 Hz bands and 181 Hz X formed during a continuous sweep. Returning from the X produced both rims with visible gaps in the outer rim, and the simulated bands retained wider tails than the P1 photo.

Warmed 10-second runs of the final production build at 1920 × 1080, DPR 1, on the RTX 5080 Laptop GPU measured the interval between animation frames with 147,456 grains and all effects enabled.

| Interaction | Frames | Median | 95th percentile | 99th percentile | Worst |
| --- | ---: | ---: | ---: | ---: | ---: |
| Whole plate with frequency and light sweep | 1,435 | 6.9 ms | 7.0 ms | 7.1 ms | 14.0 ms |
| Inspect grains with orbit and frequency sweep | 1,441 | 6.9 ms | 7.0 ms | 7.1 ms | 7.4 ms |

Initial runs recorded intermittent long frames, including a 570 ms maximum in Inspect view. The warmed reruns after closing the extra test tab stayed within 16.7 ms.

## Third-pass Chrome verification

[Spotlight and bloom](verification/round-03/spotlight-and-bloom.jpg) shows the brighter key and wider halo on the 126 Hz ring and in Inspect view. In a controlled 126-to-160 Hz pointer step, the lamp covered 90% of its turn in 95 ms, down from 256 ms. The time for 2.5% of grains to move beyond a radius of one plate half-width fell from 1.46 s to 0.67 s. This marks the onset of redistribution toward the ends of the bands. A separate 126 Hz hold retained 17,389 grains in the annulus after about 31 seconds of simulated time.

Warmed 10-second whole-plate and Inspect sweeps at 1920 × 1080, DPR 1, both measured 6.9 ms median and 7.0 ms p95, with no animation-frame interval beyond 16.7 ms. The first whole-plate run included intermittent long frames, with a maximum of 333 ms.
