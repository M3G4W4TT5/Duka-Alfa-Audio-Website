import modes from './modes.json' with { type: 'json' };

export const LEGACY_END_HZ = 210;

// Trial function of the free-edge Ritz calculation. Coordinates are in half-spans.
export function bend(t: number) {
  const q = t * t;
  return q * (15 + q * (-5 + q)) / 11;
}

function ring(inner: number, outer: number) {
  const a = bend(inner);
  const b = bend(outer);
  const scale = 1 / (b - a);
  return [a * b * scale, -(a + b) * scale, -(a + b) * scale, scale, 2 * scale, scale];
}

function flex(x: number, y: number) {
  return [-bend(x), 1, y, 0, 0, 0];
}

const mountSections = [
  [100, 0.22, 0.010], [105, 0.57, 0.008],
  [112, 0.20, 0.008], [116, 0.55, 0.007],
  [127, 0.25, 0.008], [144, 0.54, 0.009],
  [156, 0.20, 0.006], [160, 0.55, 0.005],
  [164, 0.32, 0.003], [169, 0.51, 0.006],
  [171, 0.20, 0.006],
];

// P1 Fig. 14. Coordinates are fractions of the plate half-span. Each arc
// crosses the midline and the free edge at the two photographed offsets.
function arcs(mid: number, edge: number, horizontal = false) {
  const c = bend(mid), curve = c - bend(edge);
  return [-c, horizontal ? curve : 1, horizontal ? 1 : curve, 0, 0, 0];
}

const loopX = .565, loopY = .555;
const loopU = bend(loopX), loopV = bend(loopY);
function fourLoops(rx: number, ry: number, tilt = 0) {
  const du = (bend(loopX + rx) - bend(loopX - rx)) / 2;
  const dv = (bend(loopY + ry) - bend(loopY - ry)) / 2;
  const xx = 1 / (du * du), xy = 2 * tilt / (du * dv), yy = 1 / (dv * dv);
  // The ellipse in (bend(x), bend(y)) repeats in the four quadrants.
  return [1 - xx * loopU ** 2 - xy * loopU * loopV - yy * loopV ** 2,
    2 * xx * loopU + xy * loopV, 2 * yy * loopV + xy * loopU, -xx, -xy, -yy];
}

type Calibration = [number, number, number[], number[]?];
function measured(hz: number, centreUm: number, shape: number[], quadrature?: number[]): Calibration {
  const centre = Math.hypot(shape[0], quadrature?.[0] ?? 0);
  return [hz, centreUm / (centre * Math.hypot(...mountResponse(hz))), shape, quadrature];
}

// Sparse geometry calibration of an even, six-term bending expansion.
// Entries are displacement coefficients in micrometres before shaker response.
const calibration: Calibration[] = [
  // Below and above the photographed anchors, use a bounded estimate.
  [0, 0, flex(0.81, 1)],
  [75, 24, flex(0.81, 1)],
  [90, 58, flex(0.81, 1)],
  [100, 95, flex(0.81, 1)],
  [107, 100, flex(0.85, 0.98)],
  [114, 100, ring(0.58, 0.97)],
  [126, 108, ring(0.535, 0.925)],
  [139, 100, ring(0.57, 0.97)],
  [149, 96, flex(0.69, 0.86)],
  [154, 97, flex(0.735, 0.68)],
  [157, 95, flex(0.66, 0.39)],
  [160, 105, flex(0.56, 0)],
  // Centre amplitudes are approximate readings of Fig. 5. A quadrature
  // component restricts the short transitional arcs to their four intersections.
  measured(161, 50, arcs(.575, .53)),
  measured(163, 54, arcs(.65, .43)),
  measured(163.32, 61, arcs(.65, .43), arcs(.59, .46, true).map(c => .48 * c)),
  measured(163.33, 61, arcs(.59, .51, true)),
  measured(163.60, 67, arcs(.62, .47, true)),
  measured(163.65, 68, arcs(.62, .47, true), arcs(.65, .43).map(c => .42 * c)),
  measured(163.66, 68, arcs(.65, .43), arcs(.62, .47, true).map(c => .8 * c)),
  measured(164, 72, fourLoops(.042, .042)),
  measured(164.5, 64, fourLoops(.056, .047, .25)),
  measured(165.3, 46, fourLoops(.073, .085, .62)),
  measured(165.5, 44, arcs(.69, .38)),
  measured(167, 42, arcs(.66, .46)),
  measured(168, 42, arcs(.57, .57)),
  [169, 95, flex(0.49, -0.23)],
  [175, 100, flex(0.32, -0.65)],
  [178, 105, flex(0.20, -0.91)],
  [181, 112, flex(0.04, -1)],
  [182, 95, flex(0.81, 1)],
  [198, 95, flex(0.81, 1)],
  [LEGACY_END_HZ, 95, flex(0.81, 1)],
];

type Complex = [number, number];
const modalDenominator = (frequency: number, pole: number, damping: number): Complex => [
  (2 * Math.PI) ** 2 * (pole * pole - frequency * frequency),
  (2 * Math.PI) ** 2 * 2 * damping * pole * frequency,
];

// Decompose each calibrated field into mass-normalized Ritz modes, then infer
// the complex generalized loads that the moving fixture must apply at that knot.
const loads = calibration.map(([hz, um, coefficients, quadrature]) => modes.map((mode, index) => {
  const project = (weights: number[]) => weights.reduce((sum, weight, j) =>
    sum + weight * mode.massProjection[j], 0) * um * 1e-6;
  const displacement = project(coefficients), outOfPhase = quadrature ? project(quadrature) : 0;
  const [real, imaginary] = modalDenominator(hz, mode.hz, mode.damping);
  // Small effective phase lag between flexural channels from fixture compliance.
  // The four closed nodes require the participating modes to cross zero together.
  const phase = index === 0 || (hz >= 164 && hz <= 165.3) ? 0 : 0.003 * (index - 1) * hz / 160;
  const r = real * Math.cos(phase) + imaginary * Math.sin(phase);
  const j = imaginary * Math.cos(phase) - real * Math.sin(phase);
  return [displacement * r - outOfPhase * j, displacement * j + outOfPhase * r];
}));

const spans = calibration.slice(1).map(([hz], i) => hz - calibration[i][0]);

// Shape-preserving cubic Hermite tangents for the calibrated complex loads.
// Use one tangent per knot so the slope stays continuous across intervals.
function loadTangents(mode: number, component: number) {
  const slopes = spans.map((span, i) => (loads[i + 1][mode][component] - loads[i][mode][component]) / span);
  return calibration.map((_, i) => {
    if (i === 0) return slopes[0];
    if (i === slopes.length) return slopes[i - 1];
    const before = slopes[i - 1];
    const after = slopes[i];
    if (before * after <= 0) return 0;
    const wBefore = 2 * spans[i] + spans[i - 1];
    const wAfter = spans[i] + 2 * spans[i - 1];
    return (wBefore + wAfter) / (wBefore / before + wAfter / after);
  });
}

const tangents = modes.map((_, i) => [loadTangents(i, 0), loadTangents(i, 1)]);

// Limited-depth, complex centre-mount response around Table III landmarks.
// The measured main bending peak is 164 Hz. The other peaks/dips are a
// reduced transfer fit; the normalization is one fixed voltage scale.
function mountResponse(frequency: number): Complex {
  let real = 1;
  let imaginary = 0;
  for (const [pole, contrast, damping] of mountSections) {
    const d = pole * pole - frequency * frequency;
    const q = 2 * damping * pole * frequency;
    const denominator = d * d + q * q;
    const x = 1 + (contrast - 1) * q * q / denominator;
    const y = (contrast - 1) * d * q / denominator;
    // A pole/zero notch or peak, using the centre-frequency gain below.
    const peak = pole === 100 || pole === 112 || pole === 127 || pole === 156 || pole === 164 || pole === 171;
    const a = peak ? 2 - x : x;
    const b = peak ? -y : y;
    [real, imaginary] = [real * a - imaginary * b, real * b + imaginary * a];
  }
  return [real, imaginary];
}

export function legacyResponseAt(frequency: number) {
  let upper = 1;
  while (upper < calibration.length - 1 && frequency > calibration[upper][0]) upper++;
  const lower = upper - 1;
  const span = spans[lower];
  const t = (frequency - calibration[lower][0]) / span;
  const remaining = 1 - t;
  const weightUpper = t * t * (3 - 2 * t);
  const weightLower = 1 - weightUpper;
  const slopeLower = span * t * remaining * remaining;
  const slopeUpper = -span * remaining * t * t;
  // Interpolate the identified fixture loads, then solve each damped oscillator.
  const [mountR, mountI] = mountResponse(frequency);
  const real = Array<number>(6).fill(0);
  const imaginary = Array<number>(6).fill(0);
  for (const [i, mode] of modes.entries()) {
    const [ar, ai] = loads[lower][i];
    const [br, bi] = loads[upper][i];
    const [realTangents, imaginaryTangents] = tangents[i];
    const forceR = ar * weightLower + br * weightUpper
      + realTangents[lower] * slopeLower + realTangents[upper] * slopeUpper;
    const forceI = ai * weightLower + bi * weightUpper
      + imaginaryTangents[lower] * slopeLower + imaginaryTangents[upper] * slopeUpper;
    const [d, q] = modalDenominator(frequency, mode.hz, mode.damping);
    const denominator = d * d + q * q;
    const r = (forceR * d + forceI * q) / denominator;
    const j = (forceI * d - forceR * q) / denominator;
    for (let k = 0; k < 6; k++) {
      real[k] += (r * mountR - j * mountI) * mode.shape[k];
      imaginary[k] += (r * mountI + j * mountR) * mode.shape[k];
    }
  }
  return { real, imaginary };
}

// Sample the legacy fit in metres on the same physical grid used by the sand.
export function sampleLegacy(axis: Float64Array, frequency: number, real: Float64Array, imaginary: Float64Array) {
  const { real: r, imaginary: j } = legacyResponseAt(frequency);
  const size = axis.length;
  // Increase the local slope around the four photographed deposits. The
  // positive envelope preserves their nodal curves and the measured centre amplitude.
  const rise = Math.max(0, Math.min(1, (frequency - 163.66) / .34));
  const fall = Math.max(0, Math.min(1, (165.5 - frequency) / .2));
  const focus = 78 * rise * rise * (3 - 2 * rise) * fall * fall * (3 - 2 * fall);
  const centreGain = 1 + focus / (1 + 750 * (loopU ** 2 + loopV ** 2));
  for (let y = 0; y < size; y++) {
    const v = axis[y];
    const rr = r[0] + r[2] * v + r[5] * v * v;
    const ri = j[0] + j[2] * v + j[5] * v * v;
    for (let x = 0; x < size; x++) {
      const u = axis[x];
      const index = y * size + x;
      real[index] = rr + u * (r[1] + r[4] * v + r[3] * u);
      imaginary[index] = ri + u * (j[1] + j[4] * v + j[3] * u);
      if (focus > 0) {
        const du = u - loopU, dv = v - loopV;
        const gain = (1 + focus / (1 + 750 * (du * du + dv * dv))) / centreGain;
        real[index] *= gain;
        imaginary[index] *= gain;
      }
    }
  }
}
