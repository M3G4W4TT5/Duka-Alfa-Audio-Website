import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { createBloom, finishFragment } from './screen-effects';
import { GRAVITY, HALF } from './field';
import { orbitPoint, type RenderedSpotlight } from './lighting';
import { GRAIN_COLUMNS, POUR_VELOCITY_TAG, RIDGE_SPAN, STEP, Sand } from './sand';
import { sphereShadowFragment, sphereShadowVertex, sphereSurfaceFragment, sphereSurfaceVertex } from './spherical-grains';
import { DukaRelief, type ReliefStatus } from './relief';
import { SvgLayer, svgTransmission } from './svg-layer';
import type { SvgImage } from './svg-image';
import reliefContact from './relief-contact.glsl?raw';
import surfaceShader from './surface.glsl?raw';
import logoLight from './logo-light.glsl?raw';
import { SurfaceMaterials } from './surface-maps';
import { DEFAULT_SETTINGS, MAX_SPOTLIGHTS, reliefBounds, type PlateSettings } from './settings';

const SHADOW_SIZE = 2048;
const LAMP_RADIUS = 0.148;
const RENDER_LIGHTS = MAX_SPOTLIGHTS + 1;
const reliefDefines = { RELIEF_SPAN: reliefBounds.span, RELIEF_PIXELS: reliefBounds.pixels.toFixed(1) };

export function lampPosition(angle: number, elevation: number) {
  const { x, y } = orbitPoint(angle);
  return { x: LAMP_RADIUS * x, y: LAMP_RADIUS * y, z: LAMP_RADIUS * Math.tan(THREE.MathUtils.degToRad(elevation)) };
}

const grainInputs = /* glsl */ `
  attribute vec4 grainForm;
  uniform sampler2D sandPositions;
  uniform sampler2D nextSandPositions;
  uniform float stepFraction;
  uniform float grainSize;
  float verticalSpeed(float w) { return w <= -${POUR_VELOCITY_TAG.toFixed(1)} ? w + ${POUR_VELOCITY_TAG.toFixed(1)} : w; }
  vec3 grainOrigin() {
    ivec2 texel = ivec2(gl_InstanceID % ${GRAIN_COLUMNS}, gl_InstanceID / ${GRAIN_COLUMNS});
    vec4 a = texelFetch(sandPositions, texel, 0);
    if (a.w == 0. || stepFraction >= 1.) return a.xyz;
    vec4 b = texelFetch(nextSandPositions, texel, 0);
    float t = stepFraction, dz = b.z - a.z;
    float vz = verticalSpeed(a.w);
    if (b.w == 0. && dz <= 0.) {
      // A small hop can take off and land within one tick. End its travel at
      // impact so the lowest height and kick settings still describe the arc.
      float time = t * ${STEP};
      float impact = (vz + sqrt(max(0., vz * vz - 2. * ${GRAVITY} * dz))) / ${GRAVITY};
      float z = max(b.z, a.z + time * (vz - .5 * ${GRAVITY} * time));
      return vec3(mix(a.xy, b.xy, min(1., time / max(impact, .000001))), z);
    }
    // Cubic Hermite interpolation is exact between two airborne states.
    float arc = mix(vz * ${STEP} - dz, dz - verticalSpeed(b.w) * ${STEP}, t);
    vec3 p = mix(a.xyz, b.xyz, t);
    p.z = max(min(a.z, b.z), p.z + t * (1. - t) * arc);
    return p;
  }
`;

const sphereInputs = /* glsl */ `
  ${grainInputs}
  vec4 grainShape() {
    float radius = .5 * grainForm.x * grainSize;
    return vec4(grainOrigin() + vec3(0., 0., radius), radius);
  }
`;

const grainFinish = /* glsl */ `
  uniform float grainPixelSize;
  uniform float highlightVariation;
  varying vec4 finish; // Tone, highlight exponent, peak strength and diameter in metres.
  vec4 sampleFinish() {
    float diameter = grainForm.x * grainSize;
    float detail = smoothstep(.8, 4., diameter / grainPixelSize);
    float polish = fract(5.17 * grainForm.z + 3.57 * grainForm.w);
    // Broaden unresolved highlights and lower their peaks to conserve lobe energy.
    float power = mix(9., mix(9., 88., polish * polish), detail);
    float energy = mix(.026, mix(.015, .037, polish), .25 + .75 * detail);
    vec2 lobe = mix(vec2(22., .64), vec2(power, energy * (power + 2.)), highlightVariation);
    return vec4(grainForm.w, lobe, diameter);
  }
`;

const grainVertex = /* glsl */ `
  ${grainInputs}
  varying vec3 worldPoint;
  varying vec3 worldNormal;

  void grain(in vec3 p, in vec3 n, out vec3 result, out vec3 normalOut) {
    float size = grainForm.x * grainSize;
    float c = cos(grainForm.y);
    float s = sin(grainForm.y);
    mat2 yaw = mat2(c, s, -s, c);
    vec3 stretch = vec3(0.76 + grainForm.z * 0.40, 1.13 - grainForm.z * 0.34, 0.71 + grainForm.w * 0.47);
    vec3 local = p * stretch;
    vec3 normal = n / stretch;
    vec2 lean = vec2(grainForm.z - .5, grainForm.w - .5) * .57;
    local.xy += lean * local.z;
    normal.z -= dot(lean, normal.xy);
    result = grainOrigin() + size * vec3(yaw * local.xy, local.z);
    normalOut = normalize(vec3(yaw * normal.xy, normal.z));
  }
`;

const shadowProjection = /* glsl */ `
  uniform vec2 atlasCentre;
  uniform vec2 atlasHalf;
  uniform float shadowCeiling;
  float depthSlope(vec3 lamp) {
    // Extend the near plane for reliefs and airborne grains at grazing elevations.
    return shadowCeiling > 0. ? clamp(1. / shadowCeiling - 1. / lamp.z, .05 / lamp.z, 125.) : 125.;
  }
  vec4 shadowClip(vec3 p, vec3 lamp) {
    float w = 1. - p.z / lamp.z;
    vec2 ground = p.xy - lamp.xy * p.z / lamp.z;
    return vec4((ground - atlasCentre * w) / atlasHalf, -depthSlope(lamp) * p.z, w);
  }
`;

const shadowSample = /* glsl */ `
  ${svgTransmission}
  uniform float emitterRadius;
  uniform float shadowPixelSize;
  const float shadowSize = ${SHADOW_SIZE.toFixed(1)};
  vec4 shadowQuad(sampler2D map, vec2 uv, out vec2 f) {
    vec2 texel = uv * shadowSize - .5;
    f = fract(texel);
    vec2 base = (floor(texel) + .5) / shadowSize;
    vec2 tap = vec2(1. / shadowSize, 0.);
    return vec4(textureLod(map, base, 0.).r, textureLod(map, base + tap, 0.).r,
                textureLod(map, base + tap.yx, 0.).r, textureLod(map, base + tap.xx, 0.).r);
  }
  float visibleQuad(vec4 depths, float receiver, vec2 f) {
    vec4 v = step(vec4(receiver), depths);
    return mix(mix(v.x, v.y, f.x), mix(v.z, v.w, f.x), f.y);
  }
  float shadowTap(sampler2D map, vec2 uv, float receiver) {
    vec2 f;
    vec4 depths = shadowQuad(map, uv, f);
    return visibleQuad(depths, receiver, f);
  }
  float nearestDepth(vec4 depths) {
    return min(min(depths.x, depths.y), min(depths.z, depths.w));
  }
  vec4 searchCross(sampler2D map, vec2 uv, vec2 a, vec2 b) {
    return vec4(textureLod(map, uv + a, 0.).r, textureLod(map, uv - a, 0.).r,
                textureLod(map, uv + b, 0.).r, textureLod(map, uv - b, 0.).r);
  }
  float depthTransmission(sampler2D shadowDepth, vec3 lamp, vec3 p, float bias) {
    vec4 clip = shadowClip(p, lamp);
    if (clip.w <= 0.) return 1.;
    float slope = depthSlope(lamp);
    bias *= slope / 125.;
    vec3 q = clip.xyz / clip.w * .5 + .5;
    if (any(lessThan(q.xy, vec2(0.))) || any(greaterThan(q.xy, vec2(1.)))) return 1.;
    vec2 f;
    vec4 depths = shadowQuad(shadowDepth, q.xy, f);
    float receiver = q.z - bias;
    float contact = visibleQuad(depths, receiver, f);
    if (emitterRadius <= 0.) return contact;

    // A horizontal disk emitter projects onto the plate by z/(lamp.z-z).
    // In this atlas that parallax is linear in stored depth. The same formula
    // works for a grain shadow landing on the logo or on another grain.
    vec2 scale = emitterRadius / (slope * lamp.z * atlasHalf);
    float clearance = max(lamp.z - p.z, .0001);
    float searchHeight = min(.004, .55 * clearance);
    vec2 search = .5 * emitterRadius / atlasHalf * (lamp.z / clearance)
                * searchHeight / (clearance - searchHeight);
    vec4 nearby = searchCross(shadowDepth, q.xy, vec2(search.x, 0.), vec2(0., search.y));
    float blocker = nearestDepth(min(depths, nearby));
    // A small airborne grain can cast a penumbra outside its central silhouette.
    // Widen the search there when the separation is resolved by the atlas.
    float searchPixels = 2. * search.x * atlasHalf.x * clip.w / shadowPixelSize;
    if (searchPixels > 1.6 && (receiver - blocker) * max(scale.x, scale.y) * shadowSize < 1.) {
      float outerHeight = min(.007, .75 * clearance);
      vec2 reach = .5 * emitterRadius / atlasHalf * (lamp.z / clearance)
                 * outerHeight / (clearance - outerHeight);
      vec4 axial = searchCross(shadowDepth, q.xy, vec2(reach.x, 0.), vec2(0., reach.y));
      vec2 diagonal = .7071 * reach;
      vec4 corners = searchCross(shadowDepth, q.xy, diagonal, vec2(diagonal.x, -diagonal.y));
      blocker = min(blocker, nearestDepth(min(axial, corners)));
    }
    vec2 radius = scale * max(0., receiver - blocker);
    float radiusTexels = max(radius.x, radius.y) * shadowSize;
    if (radiusTexels <= .35) return contact;

    // Sample a disk in a fixed spiral. Set density by its footprint on the
    // screen, so a subpixel penumbra never pays the cost of a close-up.
    float radiusPixels = 2. * radius.x * atlasHalf.x * clip.w / shadowPixelSize;
    int samples = int(clamp(ceil(3. * radiusPixels), 8., 64.));
    float inv = 1. / float(samples);
    float sum = 0.;
    // A distant blocker can overlap a crisp contact in the same atlas footprint.
    // Keep that contact in place and filter only the layer above it.
    float farDepth = receiver - .35 / (max(scale.x, scale.y) * shadowSize);
    vec4 contactDepths = mix(vec4(1.), depths, step(vec4(farDepth), depths));
    float contactLayer = visibleQuad(contactDepths, receiver, f);
    vec2 direction = vec2(1., 0.);
    const mat2 turn = mat2(-.73736888, .67549029, -.67549029, -.73736888);
    for (int i = 0; i < samples; i++) {
      vec2 offset = direction * sqrt((float(i) + .5) * inv) * radius;
      sum += shadowTap(shadowDepth, q.xy + offset, farDepth);
      direction = turn * direction;
    }
    return mix(contact, min(contactLayer, sum * inv), smoothstep(.35, 1., radiusTexels));
  }
  float transmission(sampler2D shadowDepth, vec3 lamp, vec3 p, float bias) {
    return depthTransmission(shadowDepth, lamp, p, bias) * throughSvg(lamp, p);
  }
`;

const spotlight = /* glsl */ `
  vec2 lightLobes(vec3 lamp, vec2 beam, vec3 p, vec3 n, float power) {
    vec3 ray = lamp - p;
    float squaredDistance = dot(ray, ray);
    vec3 incident = ray * inversesqrt(squaredDistance);
    float cone = smoothstep(beam.x, beam.y, dot(normalize(lamp), incident));
    vec3 halfAngle = normalize(incident + vec3(0., 0., 1.));
    float diffuse = max(0., dot(n, incident));
    float sheen = pow(max(0., dot(n, halfAngle)), power);
    return vec2(diffuse, sheen) * (cone * .325 / squaredDistance);
  }
  float illumination(vec3 lamp, vec2 beam, vec3 p, vec3 n, float specular) {
    return dot(lightLobes(lamp, beam, p, n, 22.), vec2(1., specular));
  }
`;

const lampUniforms = /* glsl */ `
  uniform int lightCount;
  uniform vec3 lightPositions[${RENDER_LIGHTS}];
  uniform vec2 lightBeams[${RENDER_LIGHTS}];
  uniform vec3 lightEnergy[${RENDER_LIGHTS}];
  uniform vec3 stageLightEnergy[${RENDER_LIGHTS}];
  uniform float stageShadowWeights[${RENDER_LIGHTS}];
  ${Array.from({ length: RENDER_LIGHTS }, (_, i) => `uniform sampler2D shadowDepth${i};`).join('\n')}
`;

// Each sampler is a static GLSL reference. The branches keep dark, unused
// slots out of the per-fragment work, including the strobe's dark phase.
function forActiveLights(body: (i: number) => string) {
  return Array.from({ length: RENDER_LIGHTS }, (_, i) => `if (lightCount > ${i}) { ${body(i)} }`).join('\n');
}

const lightingInputs = /* glsl */ `
  ${shadowProjection}
  ${shadowSample}
  ${spotlight}
  ${lampUniforms}
`;

const grainShading = /* glsl */ `
  ${lightingInputs}
  ${reliefContact}
  ${logoLight}
  uniform sampler2D grainPacking;
  uniform float ridgeShading;
  varying vec4 finish;

  float grainShelter(vec3 p) {
    if (ridgeShading == 0.) return 0.;
    float height = p.z;
    if (reliefPose.w > 0.) {
      vec2 contact = reliefContact(p.xy);
      if (contact.x < 0.) height -= contact.y;
    }
    float nearBed = 1. - smoothstep(.00012 + .3 * finish.w, .0007 + .8 * finish.w, height);
    return ridgeShading * nearBed * texture2D(grainPacking, p.xy / ${RIDGE_SPAN} + .5).r;
  }

  vec3 illuminateGrain(vec3 p, vec3 n, float shelter) {
    vec3 direct = vec3(0.);
    ${forActiveLights(i => /* glsl */ `
      vec3 lamp = lightPositions[${i}];
      float strength = dot(lightLobes(lamp, lightBeams[${i}], p, n, finish.y), vec2(1., finish.z));
      if (strength > 0.) {
        float lit = transmission(shadowDepth${i}, lamp, p + n * .000009, .00055);
        direct += lightEnergy[${i}] * (strength * mix(.11 * (1. - .82 * shelter), 1., lit));
      }
    `)}
    return direct;
  }
  vec3 grainColour(vec3 p, vec3 n) {
    float shelter = grainShelter(p);
    vec3 direct = illuminateGrain(p, n, shelter) + logoIrradiance(p, n);
    float up = max(0., n.z);
    vec3 fill = vec3(.035, .029, .037) + vec3(.083, .074, .068) * up;
    vec3 quartz = vec3(.94, .88, .81) * mix(.54, 1.0, finish.x);
    vec3 linearRgb = quartz * (fill * (1. - shelter * (.80 - .28 * up)) + direct);
    return linearRgb / (1. + linearRgb * .32);
  }
`;

const stageLights = /* glsl */ `
  ${lightingInputs}
  ${surfaceShader}
  uniform vec4 stageTint;
  uniform bool passThrough;
  vec3 illuminateStage(vec3 p, Surface s) {
    float plate = 1. - smoothstep(.019, .105, length(p.xy));
    vec3 pigment = mix(s.colour, stageTint.rgb, stageTint.a);
    vec3 base = pigment * mix(1., .62, plate);
    if (passThrough) {
      float edgeFill = dot(s.n.xy, vec2(-.52, .68));
      base *= 1. + .24 * smoothstep(0., .001, p.z) + .85 * edgeFill;
    }
    if (physicalWeight > 0.) {
      float fill = .65 + .45 * max(0., dot(s.n, normalize(vec3(-.5, .65, .7))));
      vec3 ambient = pigment * (1. - s.metal) * mix(1., .62, plate) * fill + studioReflection(s, p);
      base = mix(base, ambient, physicalWeight);
    }
    float edge = max(abs(p.x), abs(p.y));
    if (passThrough || edge >= .106) return base;
    float directWeight = .62 * physicalWeight * (1. - smoothstep(.090, .106, edge));
    vec3 direct = vec3(0.);
    float occlusion = 0.;
    float weight = 0.;
    ${forActiveLights(i => /* glsl */ `
      vec3 lamp = lightPositions[${i}];
      float lit = transmission(shadowDepth${i}, lamp, p, .00010);
      vec3 response = vec3(0.);
      if (physicalWeight < 1.) {
        response += vec3(illumination(lamp, lightBeams[${i}], p, s.n, .033) * (.0042 * plate * (1. - physicalWeight)));
      }
      if (directWeight > 0.) response += directWeight * directReflection(s, lamp, lightBeams[${i}], p);
      direct += stageLightEnergy[${i}] * response * lit;
      occlusion += stageShadowWeights[${i}] * (1. - lit);
      weight += stageShadowWeights[${i}];
    `)}
    return base * (1. - .53 * occlusion / max(1., weight)) + direct;
  }
`;

type RenderedStrobe = Omit<RenderedSpotlight, 'id' | 'hue'> & { source: number | 'fixed' };

function createShadow() {
  return new THREE.WebGLRenderTarget(SHADOW_SIZE, SHADOW_SIZE, {
    // Only depth is sampled. R8 saves 12 MiB per 2048² map over RGBA8.
    format: THREE.RedFormat,
    depthTexture: new THREE.DepthTexture(SHADOW_SIZE, SHADOW_SIZE, THREE.UnsignedIntType),
    generateMipmaps: false,
  });
}

function createLightSlot() {
  return {
    position: new THREE.Vector3(),
    beam: new THREE.Vector2(),
    energy: new THREE.Color(0, 0, 0),
    stageEnergy: new THREE.Color(0, 0, 0),
    shadowDepth: { value: null as THREE.DepthTexture | null },
  };
}

function geometryFor(sand: Sand) {
  const girdle = [[-.49, -.16, .15], [.06, -.47, .08], [.50, -.06, .18], [.30, .44, .12], [-.23, .33, .17]];
  const corners = [...girdle, [0.02, -.02, 0], [-.09, .05, .39]];
  const foot = girdle.length, crown = foot + 1;
  const upper: number[] = [], faces: number[] = [];
  for (let i = 0; i < girdle.length; i++) {
    const j = (i + 1) % girdle.length;
    upper.push(i, j, crown);
    faces.push(i, j, crown, j, i, foot);
  }
  // All five lower faces point away from the overhead camera for every grain
  // stretch and lean. Grazing lights see the full silhouette from the side.
  const surface = new THREE.InstancedBufferGeometry();
  surface.setAttribute('position', new THREE.Float32BufferAttribute(upper.flatMap(i => corners[i]), 3));
  surface.computeVertexNormals();
  const shadow = new THREE.InstancedBufferGeometry();
  shadow.setAttribute('position', new THREE.Float32BufferAttribute(corners.flat(), 3));
  shadow.setIndex(faces);
  const sphere = new THREE.InstancedBufferGeometry();
  sphere.setAttribute('position', new THREE.Float32BufferAttribute([-1, -1, 0, 1, -1, 0, 1, 1, 0, -1, 1, 0], 3));
  sphere.setIndex([0, 1, 2, 0, 2, 3]);
  const form = new THREE.InstancedBufferAttribute(sand.form, 4);
  surface.setAttribute('grainForm', form);
  shadow.setAttribute('grainForm', form);
  sphere.setAttribute('grainForm', form);
  return { surface, shadow, sphere };
}

type GrainMesh = THREE.Mesh<THREE.InstancedBufferGeometry, THREE.ShaderMaterial>;
type GrainMeshes = { surface: GrainMesh; shadow: GrainMesh };

export class PlateRenderer {
  readonly renderer: THREE.WebGLRenderer;
  sand: Sand;
  private readonly camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.01, 2);
  private readonly scene = new THREE.Scene();
  private readonly shadowScene = new THREE.Scene();
  private readonly composer: EffectComposer;
  private readonly bloom = createBloom();
  private readonly output = new ShaderPass(new THREE.ShaderMaterial({
    uniforms: { tDiffuse: { value: null } },
    depthTest: false,
    depthWrite: false,
    vertexShader: `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = vec4(position.xy, 0., 1.);
      }
    `,
    fragmentShader: finishFragment,
  }));
  private readonly shadows: THREE.WebGLRenderTarget[] = [];
  private readonly shadowLamp = { value: new THREE.Vector3() };
  private readonly shadowCeiling = { value: 0 };
  private readonly reliefMap = { value: null as THREE.Texture | null };
  private readonly reliefPose = { value: new THREE.Vector4() };
  private readonly passThrough = { value: false };
  readonly relief: DukaRelief;
  readonly svg = new SvgLayer();
  private readonly artwork: THREE.Mesh<THREE.PlaneGeometry, THREE.ShaderMaterial>;
  private readonly lightSlots = Array.from({ length: RENDER_LIGHTS }, createLightSlot);
  private readonly lightCount = { value: 0 };
  private readonly stageShadowWeights = { value: new Float32Array(RENDER_LIGHTS) };
  private readonly surfaces = new SurfaceMaterials();
  private readonly stageTint = { value: new THREE.Vector4() };
  private readonly logoEffect = { value: new THREE.Vector4() };
  private readonly effectColour = { value: new THREE.Color() };
  private readonly spillStrength = { value: 0 };
  private spillWhenSolid = 0;
  private readonly tint = new THREE.Color();
  private readonly shadowSlots: number[] = [];
  private readonly spotSlots = new Map<number, number>();
  private flashSlot = -1;
  private shadowCount = 0;
  private readonly atlasCentre = { value: new THREE.Vector2() };
  private readonly atlasHalf = { value: new THREE.Vector2() };
  private readonly cameraCentre = { value: new THREE.Vector2() };
  private readonly cameraHalf = { value: new THREE.Vector2() };
  private readonly sandPositions = { value: null as THREE.Texture | null };
  private readonly nextSandPositions = { value: null as THREE.Texture | null };
  private readonly stepFraction = { value: 1 };
  private readonly grainSize = { value: DEFAULT_SETTINGS.grainSize };
  private readonly grainPixelSize = { value: 0 };
  private readonly highlightVariation = { value: DEFAULT_SETTINGS.highlightVariation };
  private readonly ridgeShading = { value: DEFAULT_SETTINGS.ridgeShading };
  private readonly emitterRadius = { value: DEFAULT_SETTINGS.emitterRadius / 1000 };
  private readonly grainPacking = { value: null as THREE.Texture | null };
  private readonly plateGeometry = new THREE.PlaneGeometry(2, 2);
  private readonly facets: GrainMeshes;
  private readonly spheres: GrainMeshes;
  private readonly stageMaterial: THREE.ShaderMaterial;

  constructor(canvas: HTMLCanvasElement, private onReliefStatus: (status: ReliefStatus) => void) {
    this.renderer = new THREE.WebGLRenderer({ canvas, powerPreference: 'high-performance' });
    try {
      this.sand = new Sand(this.renderer);
    } catch (error) {
      this.renderer.dispose();
      throw error;
    }
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.setClearColor('#151416');
    this.camera.position.z = 1;
    this.composer = new EffectComposer(this.renderer, new THREE.WebGLRenderTarget(1, 1, {
      type: THREE.HalfFloatType, samples: 4,
    }));
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    this.composer.addPass(this.bloom);
    // The terminal pass writes to the canvas. Keep the same HDR scene target next frame.
    this.output.needsSwap = false;
    this.composer.addPass(this.output);
    const projectionUniforms = {
      atlasCentre: this.atlasCentre,
      atlasHalf: this.atlasHalf,
      shadowCeiling: this.shadowCeiling,
    };
    const lightingUniforms = {
      ...projectionUniforms,
      emitterRadius: this.emitterRadius,
      shadowPixelSize: this.grainPixelSize,
      ...this.svg.uniforms,
      lightCount: this.lightCount,
      lightPositions: { value: this.lightSlots.map(slot => slot.position) },
      lightBeams: { value: this.lightSlots.map(slot => slot.beam) },
      lightEnergy: { value: this.lightSlots.map(slot => slot.energy) },
      stageLightEnergy: { value: this.lightSlots.map(slot => slot.stageEnergy) },
      stageShadowWeights: this.stageShadowWeights,
      stageTint: this.stageTint,
      passThrough: this.passThrough,
      ...Object.fromEntries(this.lightSlots.map((slot, i) => [`shadowDepth${i}`, slot.shadowDepth])),
    };
    const reliefUniforms = {
      reliefMap: this.reliefMap, reliefPose: this.reliefPose,
      logoEffect: this.logoEffect, effectColour: this.effectColour, spillStrength: this.spillStrength,
    };
    const ink = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false,
      uniforms: { ...lightingUniforms, inkOpacity: this.svg.opacity, guide: this.svg.guide },
      vertexShader: `
        uniform vec4 svgPose;
        uniform float svgHeight;
        varying vec2 vUv;
        varying vec3 point;
        void main() {
          vUv = uv;
          point = vec3(svgPose.xy + position.xy * svgPose.zw, svgHeight);
          gl_Position = projectionMatrix * viewMatrix * vec4(point, 1.);
        }
      `,
      fragmentShader: `
        varying vec2 vUv;
        varying vec3 point;
        uniform float inkOpacity;
        uniform float guide;
        ${lightingInputs}
        float maskAt(vec2 uv) {
          if (any(lessThan(uv, vec2(0.))) || any(greaterThan(uv, vec2(1.)))) return 0.;
          return texture2D(svgMap, uv).a;
        }
        void main() {
          vec4 ink = texture2D(svgMap, vUv);
          if (guide > 0.) {
            vec2 px = 1.4 * fwidth(vUv);
            float neighbour = min(min(maskAt(vUv + vec2(px.x, 0.)), maskAt(vUv - vec2(px.x, 0.))),
                                  min(maskAt(vUv + vec2(0., px.y)), maskAt(vUv - vec2(0., px.y))));
            gl_FragColor = vec4(.60, .51, .62, .52 * guide * max(0., ink.a - neighbour));
          } else {
            if (ink.a < .001) discard;
            vec3 up = vec3(0., 0., 1.);
            vec3 light = vec3(.13);
            ${forActiveLights(i => `
              vec3 lamp = lightPositions[${i}];
              float shade = depthTransmission(shadowDepth${i}, lamp, point, .00010);
              light += .32 * shade * lightEnergy[${i}] * illumination(lamp, lightBeams[${i}], point, up, .035);
            `)}
            vec3 colour = ink.rgb * light;
            gl_FragColor = vec4(colour / (1. + .45 * colour), ink.a * inkOpacity);
          }
          #include <colorspace_fragment>
        }
      `,
    });
    this.artwork = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), ink);
    this.artwork.frustumCulled = false;
    this.artwork.visible = false;
    this.scene.add(this.artwork);
    const grainUniforms = { sandPositions: this.sandPositions, nextSandPositions: this.nextSandPositions,
      stepFraction: this.stepFraction, grainSize: this.grainSize };
    const shadowUniforms = { ...projectionUniforms, ...grainUniforms, lamp: this.shadowLamp };
    const surfaceUniforms = { ...lightingUniforms, ...reliefUniforms, ...grainUniforms,
      grainPixelSize: this.grainPixelSize, highlightVariation: this.highlightVariation,
      ridgeShading: this.ridgeShading, grainPacking: this.grainPacking };
    const shadowMaterial = new THREE.ShaderMaterial({
      colorWrite: false,
      side: THREE.DoubleSide,
      uniforms: shadowUniforms,
      vertexShader: `
        ${grainVertex}
        ${shadowProjection}
        uniform vec3 lamp;
        void main() {
          vec3 p, n;
          grain(position, normal, p, n);
          gl_Position = shadowClip(p, lamp);
        }
      `,
      fragmentShader: 'void main() { gl_FragColor = vec4(1.); }',
    });
    const grainMaterial = new THREE.ShaderMaterial({
      defines: reliefDefines,
      uniforms: surfaceUniforms,
      vertexShader: `
        ${grainVertex}
        ${grainFinish}
        void main() {
          grain(position, normal, worldPoint, worldNormal);
          finish = sampleFinish();
          gl_Position = projectionMatrix * modelViewMatrix * vec4(worldPoint, 1.);
        }
      `,
      fragmentShader: `
        varying vec3 worldPoint;
        varying vec3 worldNormal;
        ${grainShading}
        void main() {
          gl_FragColor = vec4(grainColour(worldPoint, normalize(worldNormal)), 1.);
          #include <colorspace_fragment>
        }
      `,
    });
    this.stageMaterial = new THREE.ShaderMaterial({
      depthTest: false,
      depthWrite: false,
      defines: reliefDefines,
      uniforms: {
        ...lightingUniforms,
        ...this.surfaces.background,
        cameraCentre: this.cameraCentre,
        cameraHalf: this.cameraHalf,
        ...reliefUniforms,
      },
      vertexShader: `
        varying vec2 screenPoint;
        void main() {
          screenPoint = position.xy;
          gl_Position = vec4(position.xy, .999, 1.);
        }
      `,
      fragmentShader: `
        varying vec2 screenPoint;
        uniform vec2 cameraCentre;
        uniform vec2 cameraHalf;
        ${reliefContact}
        ${logoLight}
        ${stageLights}
        void main() {
          vec2 p = cameraCentre + screenPoint * cameraHalf;
          vec3 up = vec3(0., 0., 1.);
          Surface s = readSurface(vec3(p, 0.), up, up);
          vec3 colour = illuminateStage(vec3(p, 0.), s);
          vec3 scatter = s.colour * mix(1., .06 + .32 * s.rough, s.metal);
          colour += scatter * logoIrradiance(vec3(p, 0.), s.n);
          if (passThrough && reliefPose.w > 0.) {
            float distance = max(0., reliefContact(p).x);
            colour *= mix(.65, 1., smoothstep(0., reliefPose.w * 1.6, distance));
          }
          gl_FragColor = vec4(colour, 1.);
          #include <colorspace_fragment>
        }
      `,
    });
    const geometry = geometryFor(this.sand);
    this.facets = {
      surface: new THREE.Mesh(geometry.surface, grainMaterial),
      shadow: new THREE.Mesh(geometry.shadow, shadowMaterial),
    };
    this.spheres = {
      surface: new THREE.Mesh(geometry.sphere, new THREE.ShaderMaterial({
        defines: reliefDefines,
        uniforms: surfaceUniforms,
        alphaToCoverage: true,
        vertexShader: sphereInputs + grainFinish + sphereSurfaceVertex,
        fragmentShader: grainShading + sphereSurfaceFragment,
      })),
      shadow: new THREE.Mesh(geometry.sphere, new THREE.ShaderMaterial({
        colorWrite: false, side: THREE.DoubleSide, uniforms: shadowUniforms,
        vertexShader: sphereInputs + shadowProjection + sphereShadowVertex,
        fragmentShader: shadowProjection + sphereShadowFragment,
      })),
    };
    this.spheres.surface.visible = this.spheres.shadow.visible = false;
    const floor = new THREE.Mesh(this.plateGeometry, this.stageMaterial);
    floor.frustumCulled = false;
    floor.renderOrder = -2;
    const face = new THREE.ShaderMaterial({
      uniforms: { ...lightingUniforms, ...this.surfaces.logo, ...reliefUniforms },
      defines: reliefDefines,
      vertexShader: `
        varying vec3 p, n;
        void main() {
          p = (modelMatrix * vec4(position, 1.)).xyz;
          n = normalMatrix * normal; // The overhead camera has identity rotation.
          gl_Position = projectionMatrix * viewMatrix * vec4(p, 1.);
        }
      `,
      fragmentShader: `
        varying vec3 p, n;
        uniform vec4 logoEffect;
        uniform vec3 effectColour;
        ${reliefContact}
        ${stageLights}
        void main() {
          vec3 geometryNormal = normalize(n), normal = geometryNormal;
          // A sub-millimetre edge break catches the grazing light on the square-cut cap.
          float bevel = min(.00027, reliefPose.w * .30);
          float d = reliefContact(p.xy).x;
          if (normal.z > .99 && d > -bevel && bevel > 0.) {
            normal = normalize(normal + vec3(wallNormal(p.xy), 0.) * smoothstep(-bevel, 0., d));
          }
          Surface s = readSurface(p, normal, geometryNormal);
          float mask = 1.;
          if (logoEffect.x > .5 && logoEffect.y < .5) {
            // Distance to the outline of the solid, independent of cap tessellation.
            // Integrate the inner rim over a pixel so sub-pixel widths fade continuously.
            float aa = max(max(fwidth(d), .5 * max(length(dFdx(p.xy)), length(dFdy(p.xy)))), 1.e-7);
            float solidCoverage = clamp(.5 - d / aa, 0., 1.);
            float interiorCoverage = clamp(.5 - (d + logoEffect.z) / aa, 0., 1.);
            float rim = 1. - interiorCoverage / max(solidCoverage, 1.e-5);
            float crown = smoothstep(.90, .96, p.z / max(reliefPose.w, 1.e-7)) * smoothstep(.01, .28, geometryNormal.z);
            mask = rim * crown;
          }
          if (logoEffect.x > .5 && logoEffect.x < 1.5) s.colour = mix(s.colour, effectColour, mask * logoEffect.w);
          vec3 colour = illuminateStage(p, s);
          if (logoEffect.x > 1.5) colour += effectColour * (mask * logoEffect.w);
          gl_FragColor = vec4(colour, 1.);
          #include <colorspace_fragment>
        }
      `,
    });
    const caster = new THREE.ShaderMaterial({
      colorWrite: false, side: THREE.DoubleSide,
      uniforms: { ...projectionUniforms, lamp: this.shadowLamp },
      vertexShader: `
        ${shadowProjection}
        uniform vec3 lamp;
        void main() { gl_Position = shadowClip((modelMatrix * vec4(position, 1.)).xyz, lamp); }
      `,
      fragmentShader: 'void main() { gl_FragColor = vec4(1.); }',
    });
    this.relief = new DukaRelief(face, caster, () => this.syncRelief());
    this.scene.add(floor);
    for (const pair of [this.facets, this.spheres]) {
      pair.surface.frustumCulled = pair.shadow.frustumCulled = false;
      this.scene.add(pair.surface);
      this.shadowScene.add(pair.shadow);
    }
    this.scene.add(this.relief.surface);
    this.shadowScene.add(this.relief.shadow);
  }

  resize(width: number, height: number, dpr: number) {
    this.bloom.pixelRatio = dpr;
    this.renderer.setPixelRatio(dpr);
    this.renderer.setSize(width, height, false);
    this.composer.setPixelRatio(dpr);
    this.composer.setSize(width, height);
  }

  get lightingState() {
    return { shadowCount: this.shadowCount, lightCount: this.lightCount.value,
      spotShadow: (id: number) => {
        const slot = this.spotSlots.get(id);
        return slot === undefined ? null : this.shadowSlots[slot];
      },
      strobeShadow: this.flashSlot < 0 ? null : this.shadowSlots[this.flashSlot],
    };
  }

  applySettings(settings: PlateSettings) {
    this.sand.setShakerStrength(settings.shakerStrength);
    this.sand.setStrayMotion(settings.strayJumpRate, settings.strayBounceHeight, settings.straySideKick);
    this.highlightVariation.value = settings.highlightVariation;
    this.ridgeShading.value = settings.ridgeShading;
    this.emitterRadius.value = settings.emitterRadius / 1000;
    this.grainSize.value = settings.grainSize;
    this.spheres.surface.visible = this.spheres.shadow.visible = settings.grainSmoothing;
    this.facets.surface.visible = this.facets.shadow.visible = !settings.grainSmoothing;
    this.svg.configure(settings.svg);
    this.sand.setStencil(this.svg.stencil);
    this.surfaces.configure(settings);
    const effect = settings.logoEffect;
    const effectMode = effect.kind === 'neon' ? 2 : effect.kind === 'colour' ? 1 : 0;
    this.logoEffect.value.set(effectMode, effect.coverage === 'whole' ? 1 : 0, effect.widthMm / 1000,
      effect.kind === 'neon' ? effect.emission : effect.opacity);
    this.effectColour.value.set(effect.colour);
    this.spillWhenSolid = effect.kind === 'neon' ? effect.emission * effect.spill : 0;
    this.relief.configure(settings);
    this.syncRelief();
    if (!settings.svg.enabled || !settings.svg.stencil || this.svg.stencil || settings.grainCount <= this.sand.count)
      this.sand.setCount(settings.grainCount);
    this.bloom.enabled = settings.bloomStrength > 0;
    this.bloom.strength = settings.bloomStrength;
    this.bloom.setProfile(settings.bloomRadius, settings.bloomFalloff);
    this.bloom.threshold = settings.bloomThreshold;
    this.bloom.blendMaterial.uniforms.gritStrength.value = settings.bloomGrit;
  }

  private syncRelief() {
    const { relief } = this;
    this.reliefPose.value.copy(relief.placement);
    if (!relief.active) this.reliefPose.value.w = 0;
    this.reliefMap.value = relief.texture;
    this.passThrough.value = relief.active && relief.passesLight;
    this.spillStrength.value = relief.active && !relief.passesLight ? this.spillWhenSolid : 0;
    // A pour can start 10 mm above the surface. Also leave room for the grain's cap.
    this.shadowCeiling.value = this.reliefPose.value.w + .010 + .00024 * this.grainSize.value;
    this.sand.setRelief(relief.active ? relief.texture : null, relief.placement);
    this.onReliefStatus(relief.status);
  }

  setSvgImage(image: SvgImage | null) {
    this.svg.setImage(image);
    this.sand.setStencil(this.svg.stencil);
  }

  private setLight(index: number, light: RenderedSpotlight | RenderedStrobe) {
    const slot = this.lightSlots[index];
    const { x, y, z } = lampPosition(light.angle, light.elevation);
    slot.position.set(x, y, z);
    const outerAngle = THREE.MathUtils.degToRad(light.beamWidth / 2);
    slot.beam.set(Math.cos(outerAngle), Math.cos(outerAngle * .325));
    return slot;
  }

  private drawLighting(lights: RenderedSpotlight[], strobe: RenderedStrobe) {
    let count = 0;
    let tintWeight = 0;
    this.spotSlots.clear();
    this.tint.setRGB(0, 0, 0);
    for (const light of lights) {
      if (light.intensity <= 0) continue;
      const slot = this.setLight(count, light);
      slot.energy.copy(light.color).multiplyScalar(light.intensity);
      slot.stageEnergy.copy(slot.energy);
      this.stageShadowWeights.value[count] = Math.min(1, light.intensity);
      this.tint.add(slot.energy);
      tintWeight += light.intensity;
      this.spotSlots.set(light.id, count++);
    }
    if (tintWeight > 0) this.tint.multiplyScalar(1 / tintWeight);
    const tintAmount = tintWeight > 0 && !this.passThrough.value ? .0035 : 0;
    this.stageTint.value.set(this.tint.r, this.tint.g, this.tint.b, tintAmount);

    this.flashSlot = -1;
    if (strobe.intensity > 0) {
      const linkedSlot = strobe.source === 'fixed' ? undefined : this.spotSlots.get(strobe.source);
      const flash = this.flashSlot = linkedSlot ?? count++;
      const slot = linkedSlot === undefined ? this.setLight(flash, strobe) : this.lightSlots[flash];
      if (linkedSlot === undefined) {
        slot.energy.setRGB(0, 0, 0);
        slot.stageEnergy.setRGB(0, 0, 0);
        this.stageShadowWeights.value[flash] = 0;
      }
      this.tint.copy(strobe.color).multiplyScalar(strobe.intensity);
      slot.energy.add(this.tint);
      slot.stageEnergy.add(this.tint.multiplyScalar(.14));
    }
    this.lightCount.value = count;

    this.shadowCount = 0;
    this.shadowSlots.length = count;
    for (let i = 0; i < count; i++) {
      const slot = this.lightSlots[i];
      let matching = 0;
      while (matching < i && !this.lightSlots[matching].position.equals(slot.position)) matching++;
      if (matching < i) {
        this.shadowSlots[i] = this.shadowSlots[matching];
        slot.shadowDepth.value = this.lightSlots[matching].shadowDepth.value;
        continue;
      }
      const index = this.shadowCount++;
      this.shadowSlots[i] = index;
      const shadow = this.shadows[index] ?? (this.shadows[index] = createShadow());
      slot.shadowDepth.value = shadow.depthTexture;
      this.shadowLamp.value.copy(slot.position);
      this.renderer.setRenderTarget(shadow);
      this.renderer.render(this.shadowScene, this.camera);
    }
    this.renderer.setRenderTarget(null);
  }

  draw(width: number, height: number, shortHalf: number, x: number, y: number,
    lights: RenderedSpotlight[], strobe: RenderedStrobe, stepFraction = 1) {
    const aspect = width / height;
    const halfX = shortHalf * Math.max(1, aspect);
    const halfY = shortHalf * Math.max(1, 1 / aspect);
    this.camera.left = -halfX;
    this.camera.right = halfX;
    this.camera.top = halfY;
    this.camera.bottom = -halfY;
    this.camera.position.set(x, y, 1);
    this.camera.updateProjectionMatrix();
    this.cameraCentre.value.set(x, y);
    this.cameraHalf.value.set(halfX, halfY);
    // The atlas is projected onto the plate from the actual spotlight. It uses
    // more texels per millimetre as the main camera moves in for inspection.
    this.atlasCentre.value.set(x, y);
    this.atlasHalf.value.set(Math.min(HALF + .014, halfX + .012), Math.min(HALF + .014, halfY + .012));
    this.stepFraction.value = stepFraction;
    this.sandPositions.value = stepFraction < 1 ? this.sand.previousTexture : this.sand.texture;
    this.nextSandPositions.value = this.sand.texture;
    this.artwork.visible = this.svg.visible(performance.now());
    this.artwork.material.depthTest = this.svg.guide.value === 0;
    const grains = this.spheres.surface.visible ? this.spheres : this.facets;
    grains.surface.geometry.instanceCount = grains.shadow.geometry.instanceCount = this.sand.count;
    this.grainPixelSize.value = 2 * halfY / this.renderer.domElement.height;
    this.grainPacking.value = this.ridgeShading.value > 0 ? this.sand.packingForLighting() : null;
    this.drawLighting(lights, strobe);
    this.composer.render();
  }

  dispose() {
    this.svg.dispose();
    this.artwork.geometry.dispose();
    this.artwork.material.dispose();
    this.surfaces.dispose();
    this.relief.dispose();
    this.sand.dispose();
    this.facets.surface.geometry.dispose();
    this.facets.shadow.geometry.dispose();
    this.spheres.surface.geometry.dispose();
    this.plateGeometry.dispose();
    for (const pair of [this.facets, this.spheres]) {
      pair.surface.material.dispose();
      pair.shadow.material.dispose();
    }
    this.stageMaterial.dispose();
    for (const shadow of this.shadows) shadow.dispose();
    this.composer.dispose();
    this.bloom.dispose();
    this.output.dispose();
    this.renderer.dispose();
  }
}
