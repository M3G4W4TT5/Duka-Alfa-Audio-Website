import { Color } from 'three';
import { FIELD_SIZE, HALF, START_FREQUENCY } from './field';
import { DrivePointer, PlateDrive } from './drive';
import { angleFromVector, easeAngle, updateSpotlightColour, type LiveSpotlight, type RenderedSpotlight } from './lighting';
import { patternRegion } from './patterns';
import { lampPosition, PlateRenderer } from './render';
import type { ReliefStatus } from './relief';
import type { SvgImage } from './svg-image';
import { Sand, STEP } from './sand';
import { clamp, DEFAULT_SPOTLIGHT, pointerDriveAxis, SAND_SEED, type PlateSettings } from './settings';
import { StrobeClock } from './strobe';
import { fitPlate, fillFrame, visibleCrop, websiteView, type Crop, type Preview, type ViewId } from './framing';
import type { Start, Arrangement } from './configuration';

const WIDE_HALF = HALF / 0.91;
const LAMP_RESPONSE = 24;
const CAMERA_RESPONSE = 15;
const PREPARATION_BATCH_STEPS = 6;
const WARMUP_DELAY_MS = 10;

const CENTRE_DEAD_ZONE_PX = 12;
const toLegacyAngle = (angle: number) => ((630 - angle) % 360 - 180) * Math.PI / 180;

export interface PlatePointerEvent {
  clientX: number;
  clientY: number;
  target?: EventTarget | null;
  pointerType?: string;
  buttons?: number;
  isPrimary?: boolean;
}

interface PlateMountOptions {
  stage: HTMLDivElement;
  canvas: HTMLCanvasElement;
  frequency?: HTMLOutputElement | null;
  error: HTMLParagraphElement;
  active: boolean;
  prepare?: boolean;
  onAvailabilityChange?: (available: boolean) => void;
  settings: { readonly current: PlateSettings };
  preview: { readonly current: Preview };
  onCrop?: (crop: Crop | null) => void;
  onAspect?: (aspect: number) => void;
  onPatternRegion?: (region: number) => void;
  onLightDirection?: (angle: number) => void;
  onReliefStatus?: (status: ReliefStatus) => void;
  bindGestures?: typeof import('./frame-gestures').bindFrameGestures;
}

export function mountPlate({ stage, canvas, frequency, error, settings, preview, active, prepare = false, onCrop, onAspect,
  onPatternRegion, onLightDirection, onReliefStatus, onAvailabilityChange, bindGestures }: PlateMountOptions) {
  const standalone = preview.current.layout === 'standalone';
  let view: PlateRenderer;
  try {
    view = new PlateRenderer(canvas, status => {
      onReliefStatus?.(status);
      if (preparation && prepare) scheduleFrame();
    });
  } catch {
    error.hidden = false;
    stage.dataset.state = 'unavailable';
    onAvailabilityChange?.(false);
    return;
  }
  // The renderer requires WebGL2 and floating-point render targets.
  const gl = view.renderer.getContext() as WebGL2RenderingContext;
  let sand = view.sand;

  let width = 1;
  let height = 1;
  let dpr = 1;
  let options = settings.current;
  const drive = new PlateDrive(options, START_FREQUENCY);
  const drivePointer = new DrivePointer();
  let lastRegion = -1;
  let pointerX = 0.5;
  let pointerY = 1 - drive.directHeight;
  let lampTarget = DEFAULT_SPOTLIGHT.angle;
  let followAngle = lampTarget;
  let lastPreviewAngle: number | undefined;
  const renderedLights = new Map<number, LiveSpotlight>();
  const lights: RenderedSpotlight[] = [];
  const gradientScratch = new Color();
  const strobe = new StrobeClock();
  const flash = {
    source: options.strobe.source, color: new Color(), intensity: 0, angle: options.strobe.angle,
    elevation: DEFAULT_SPOTLIGHT.elevation, beamWidth: DEFAULT_SPOTLIGHT.beamWidth,
  };
  let heldPointer: number | null = null;
  let heldSpace = false;
  let windowActive = true;
  let half = WIDE_HALF;
  let targetHalf = WIDE_HALF;
  let x = 0;
  let y = 0;
  let targetX = 0;
  let targetY = 0;
  let frame = 0;
  let warmupTimer: number | null = null;
  let warmupFence: WebGLSync | null = null;
  let contextLost = false;
  let previous = 0;
  let accumulator = 0;
  let hasMotionPair = false;
  let frozen = false;
  let fixedHue: number | null = null;
  let frames: number[][] | undefined;
  const listeners = new AbortController();
  const { signal } = listeners;
  let lastPreview: Preview | undefined;
  let profile: ViewId = 'window';
  let cancelGesture: (() => void) | undefined;
  let preparation: { start: Start; steps: number | null; done: () => void } | undefined;

  function currentCrop() { return visibleCrop(preview.current.framing, profile, width / height); }
  function syncFrame(snap = false) {
    const next = preview.current;
    const w = Math.max(1, stage.clientWidth), h = Math.max(1, stage.clientHeight);
    profile = next.layout === 'player' ? websiteView(next.framing, w) : next.view;
    const device = standalone && profile !== 'window' ? next.framing[profile] : null;
    const newWidth = device?.width ?? w, newHeight = device?.height ?? h;
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    if (newWidth !== width || newHeight !== height || dpr !== ratio || !lastPreview) {
      width = newWidth; height = newHeight; dpr = ratio;
      view.resize(width, height, dpr);
      onAspect?.(width / height);
      snap = true;
    }
    if (!lastPreview || lastPreview.view !== next.view || lastPreview.editing !== next.editing) {
      cancelGesture?.();
      releaseHold();
      if (lastPreview) drivePointer.hold();
      snap = true;
    }
    const crop = currentCrop();
    targetHalf = Math.min(crop.width, crop.height) * HALF;
    targetX = (crop.centerX - .5) * 2 * HALF;
    targetY = (.5 - crop.centerY) * 2 * HALF;
    if (snap || next.editing || !standalone) { half = targetHalf; x = targetX; y = targetY; }
    stage.dataset.profile = profile;
    stage.dataset.view = crop.centerX === .5 && crop.centerY === .5 && Math.abs(targetHalf - WIDE_HALF) < 1e-8 ? 'whole' : 'zoomed';
    lastPreview = next;
  }

  function publishFrequency() {
    const display = drive.hz.toFixed(1);
    const precise = drive.hz.toFixed(3);
    if (frequency && frequency.value !== display) frequency.value = display;
    if (stage.dataset.hz !== precise) stage.dataset.hz = precise;
    if (options.mode === 'patterns') {
      const region = patternRegion(drive.hz);
      if (region !== lastRegion) onPatternRegion?.(region);
      lastRegion = region;
    }
  }

  function applyOptions() {
    const next = settings.current;
    if (next === options) return;
    if (next.mode !== options.mode) lastRegion = -1;
    if ((pointerDriveAxis(next) !== pointerDriveAxis(options) || next.mode !== options.mode) &&
      (!standalone || !canvas.matches(':hover'))) drivePointer.hold();
    if (next.strobe.mode !== options.strobe.mode) releaseHold();
    drive.configure(next);
    options = next;
    view.applySettings(options);
  }

  function releaseHold() {
    if (heldPointer !== null && canvas.hasPointerCapture(heldPointer)) canvas.releasePointerCapture(heldPointer);
    heldPointer = null;
    heldSpace = false;
    if (options.strobe.mode === 'hold') strobe.interrupt();
  }

  function updatePointer(event: PlatePointerEvent) {
    if (!active || contextLost || preview.current.editing || preparation) return;
    const bounds = stage.getBoundingClientRect();
    const offsetX = event.clientX - bounds.left;
    const offsetY = event.clientY - bounds.top;
    if (!Number.isFinite(offsetX + offsetY) || !bounds.width || !bounds.height) return;
    if (!standalone && (event.isPrimary === false || event.pointerType === 'touch' || event.buttons ||
      (event.target instanceof Element && event.target.closest('[data-plate-controls]')) ||
      offsetX < 0 || offsetY < 0 || offsetX > bounds.width || offsetY > bounds.height)) {
      drivePointer.hold();
      return;
    }
    applyOptions();
    pointerX = clamp(offsetX / bounds.width, 0, 1);
    pointerY = clamp(offsetY / bounds.height, 0, 1);
    aimLamp();
    // Re-entering lets the pointer relight the plate without changing the
    // current tuning until it actually moves along the selected axis.
    const position = drivePointer.sample(pointerDriveAxis(options), pointerX * (width - 1), pointerY * (height - 1), width, height, event.pointerType === 'touch');
    if (position !== undefined) drive.setHeight(position);
  }

  function resetZoom() {
    onCrop?.(profile === 'window' ? null : fillFrame(width / height));
  }

  if (standalone && onCrop)
    cancelGesture = bindGestures?.(canvas, signal, () => active && !contextLost,
      () => preview.current.editing, currentCrop, onCrop,
      () => onCrop(profile === 'window' ? null : fitPlate(width / height)));

  if (standalone) {
    canvas.addEventListener('pointermove', event => {
      if (event.isPrimary) updatePointer(event);
    }, { signal });
    canvas.addEventListener('pointerleave', () => drivePointer.hold(), { signal });
    canvas.addEventListener('pointerdown', event => {
      if (!active || contextLost || !event.isPrimary || event.button !== 0 || preview.current.editing || preparation) return;
      applyOptions();
      if (event.pointerType === 'touch') updatePointer(event);
      if (options.strobe.mode === 'hold') {
        heldPointer = event.pointerId;
        if (event.isTrusted) canvas.setPointerCapture(event.pointerId);
      }
    }, { signal });
    function stopPointer(event: PointerEvent) {
      if (event.pointerId !== heldPointer) return;
      heldPointer = null;
      if (!heldSpace) strobe.interrupt();
    }
    window.addEventListener('pointerup', stopPointer, { signal, capture: true });
    window.addEventListener('pointercancel', stopPointer, { signal, capture: true });
    canvas.addEventListener('lostpointercapture', stopPointer, { signal });
    canvas.addEventListener('blur', releaseHold, { signal });
  }
  window.addEventListener('blur', () => {
    windowActive = false;
    releaseHold();
    strobe.interrupt();
  }, { signal });
  window.addEventListener('focus', () => { windowActive = true; }, { signal });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      releaseHold();
      strobe.interrupt();
    }
    scheduleFrame();
  }, { signal });
  if (standalone) {
    window.addEventListener('keyup', event => {
      if (event.code !== 'Space' || !heldSpace) return;
      heldSpace = false;
      if (heldPointer === null) strobe.interrupt();
      event.preventDefault();
    }, { signal });
    window.addEventListener('keydown', event => {
      if (!active || contextLost || preview.current.editing || preparation ||
        event.ctrlKey || event.metaKey || event.altKey || event.defaultPrevented ||
        (event.target instanceof Element && event.target.closest('[data-plate-controls]'))) return;
      applyOptions();
      if (event.code === 'Space' && event.target === canvas && options.strobe.mode === 'hold') {
        if (!event.repeat) heldSpace = true;
      } else if (event.key === 'Escape' && targetHalf !== WIDE_HALF) {
        resetZoom();
      } else if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.key)) {
        const horizontal = event.key === 'ArrowLeft' || event.key === 'ArrowRight';
        const direction = event.key === 'ArrowUp' || event.key === 'ArrowRight' ? 1 : -1;
        const tunesDrive = horizontal === (options.driveAxis === 'horizontal');
        if (tunesDrive) drive.nudge(direction);
        if (horizontal) pointerX = tunesDrive ? drive.position : clamp(pointerX + direction * .04, 0, 1);
        else pointerY = tunesDrive ? 1 - drive.position : clamp(pointerY - direction * .04, 0, 1);
        aimLamp();
      } else {
        return;
      }
      event.preventDefault();
    }, { signal });
  }
  canvas.addEventListener('webglcontextlost', event => {
    event.preventDefault();
    contextLost = true;
    cancelGesture?.();
    releaseHold();
    strobe.interrupt();
    error.textContent = 'The graphics context was interrupted. It will resume when Chrome restores it.';
    error.hidden = false;
    clearWarmupFence();
    if (preparation) preparation.steps = null;
    scheduleFrame();
    onAvailabilityChange?.(false);
  }, { signal });
  canvas.addEventListener('webglcontextrestored', () => {
    contextLost = false;
    sand.dispose();
    sand = view.sand = new Sand(view.renderer, settings.current.grainCount, sand.form);
    view.applySettings(settings.current);
    error.hidden = true;
    previous = 0;
    resized();
    onAvailabilityChange?.(true);
    scheduleFrame();
  }, { signal });

  function aimLamp() {
    const dx = (pointerX - 0.5) * width;
    const dy = (0.5 - pointerY) * height;
    // The last direction is held inside the dead zone at the viewport centre.
    if (dx * dx + dy * dy > CENTRE_DEAD_ZONE_PX ** 2) lampTarget = angleFromVector(dx, dy);
  }

  function updateSpots(ease: number) {
    followAngle = easeAngle(followAngle, lampTarget, ease);
    if (lastPreviewAngle !== followAngle) {
      onLightDirection?.(followAngle);
      lastPreviewAngle = followAngle;
    }

    lights.length = 0;
    for (const configured of options.lights) {
      const hue = fixedHue ?? (configured.colorSource === 'vertical' ? 1 - pointerY : pointerX);
      let light = renderedLights.get(configured.id);
      if (!light) {
        light = { ...configured, hue, color: new Color(), pinnedColor: new Color(), pinnedWeight: 0 };
        renderedLights.set(light.id, light);
      }
      light.angle = configured.position === 'follow' ? followAngle : configured.angle;
      light.intensity = configured.intensity;
      light.elevation = configured.elevation;
      light.beamWidth = configured.beamWidth;
      updateSpotlightColour(light, configured, options.gradient, hue, ease, gradientScratch);
      lights.push(light);
    }
    for (const id of renderedLights.keys()) {
      if (!lights.some(light => light.id === id)) renderedLights.delete(id);
    }
  }
  function updateLighting(now: number, ease: number) {
    updateSpots(ease);
    const strobeSettings = options.strobe;
    const linked = strobeSettings.source === 'fixed' ? undefined : renderedLights.get(strobeSettings.source);
    const active = windowActive && !document.hidden && strobeSettings.strength > 0 &&
      (strobeSettings.mode === 'automatic' || (strobeSettings.mode === 'hold' && (heldSpace || heldPointer !== null)));
    flash.source = linked?.id ?? 'fixed';
    flash.angle = linked?.angle ?? strobeSettings.angle;
    flash.elevation = linked?.elevation ?? DEFAULT_SPOTLIGHT.elevation;
    flash.beamWidth = linked?.beamWidth ?? DEFAULT_SPOTLIGHT.beamWidth;
    flash.color.set(strobeSettings.color);
    flash.intensity = strobe.advance(now, active, strobeSettings) ? strobeSettings.strength : 0;
  }

  function waitingForRelief() {
    return settings.current.background === '3d' && view.relief.status === 'loading';
  }

  function clearWarmupTimer() {
    if (warmupTimer === null) return;
    window.clearTimeout(warmupTimer);
    warmupTimer = null;
  }

  function clearWarmupFence() {
    if (!warmupFence) return;
    if (!gl.isContextLost()) gl.deleteSync(warmupFence);
    warmupFence = null;
  }

  function scheduleFrame() {
    const canPrepare = preparation && !contextLost && !document.hidden;
    const useWarmupTimer = canPrepare && prepare && !waitingForRelief();
    if (useWarmupTimer) {
      if (warmupTimer === null) warmupTimer = window.setTimeout(runWarmup, WARMUP_DELAY_MS);
    } else {
      clearWarmupTimer();
    }

    const useFrame = active && !contextLost && (!preparation || (canPrepare && !prepare));
    if (useFrame) {
      if (!frame) frame = requestAnimationFrame(animate);
    } else if (frame) {
      cancelAnimationFrame(frame);
      frame = 0;
    }
  }

  function drawStill() {
    hasMotionPair = false;
    applyOptions();
    syncFrame(true);
    updateSpots(0);
    flash.intensity = 0;
    view.draw(width, height, half, x, y, lights, flash);
  }

  function failWarmup() {
    contextLost = true;
    preparation = undefined;
    stage.dataset.state = 'unavailable';
    error.textContent = 'The graphics device could not finish preparing the plate.';
    error.hidden = false;
    scheduleFrame();
    onAvailabilityChange?.(false);
  }

  function prepareBatch(paced: boolean) {
    if (!preparation || waitingForRelief()) return;
    if (warmupFence) {
      const result = gl.clientWaitSync(warmupFence, 0, 0);
      if (result === gl.TIMEOUT_EXPIRED) return;
      clearWarmupFence();
      if (result === gl.WAIT_FAILED) {
        failWarmup();
        return;
      }
    }

    const { start } = preparation;
    if (preparation.steps === null) {
      sand.initialize(start.arrangement === 'stencil', start.pour);
      preparation.steps = start.arrangement === 'pattern' ? 360 : start.arrangement === 'stencil' || view.relief.active ? 30 : 0;
    }
    const batch = Math.min(preparation.steps, PREPARATION_BATCH_STEPS);
    for (let i = 0; i < batch; i++) sand.step(start.drive.hz, start.arrangement === 'pattern');
    preparation.steps -= batch;

    // Keep at most one batch in flight. Poll its fence on the next paced task
    // without waiting on the GPU or tying warmup to display frames.
    if (paced && batch) {
      warmupFence = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      if (warmupFence) gl.flush();
      else failWarmup();
      return;
    }
    if (preparation.steps === 0) {
      const done = preparation.done;
      preparation = undefined;
      drawStill();
      if (paced) {
        gl.flush();
        previous = 0;
      }
      stage.dataset.state = 'ready';
      done();
    }
  }

  function runWarmup() {
    warmupTimer = null;
    if (prepare && preparation && !contextLost && !document.hidden) {
      applyOptions();
      if (lastPreview !== preview.current) syncFrame();
      prepareBatch(true);
    }
    scheduleFrame();
  }

  function animate(now: number) {
    frame = 0;
    if (!active || contextLost) return;
    const started = frames ? performance.now() : 0;
    if (!previous || frozen) hasMotionPair = false;
    const interval = previous ? now - previous : 1000 * STEP;
    const elapsed = Math.min(0.05, interval * 0.001);
    previous = now;

    applyOptions();
    if (lastPreview !== preview.current) syncFrame();
    if (preparation) {
      if (!prepare && !document.hidden) prepareBatch(false);
      scheduleFrame();
      return;
    }
    drive.advance(elapsed);
    publishFrequency();

    if (!frozen) {
      const returning = !options.vibration && options.svg.returnToStencil && !!view.svg.stencil;
      // The return slider has its own real-time scale. Sand speed sets the
      // usual clock for vibration and unstencilled settling.
      accumulator = Math.min(accumulator + elapsed * (returning ? 1 : options.sandSpeed), STEP * 4);
      while (accumulator >= STEP) {
        sand.step(drive.hz, options.vibration, returning ? options.svg.returnSpeed : 0);
        hasMotionPair = true;
        accumulator -= STEP;
      }
    }
    const afterStep = frames ? performance.now() : 0;

    const cameraEase = 1 - Math.exp(-elapsed * CAMERA_RESPONSE);
    updateLighting(now, 1 - Math.exp(-elapsed * LAMP_RESPONSE));
    half += (targetHalf - half) * cameraEase;
    x += (targetX - x) * cameraEase;
    y += (targetY - y) * cameraEase;
    view.draw(width, height, half, x, y, lights, flash, hasMotionPair ? accumulator / STEP : 1);
    if (frames) frames.push([interval, afterStep - started, performance.now() - afterStep]);
    scheduleFrame();
  }

  const resized = () => { if (active || (prepare && preparation)) syncFrame(true); };
  const observer = new ResizeObserver(resized);
  observer.observe(stage);
  window.addEventListener('resize', resized, { signal });
  view.applySettings(options);
  resized();
  aimLamp();
  publishFrequency();
  stage.dataset.state = 'ready';
  onAvailabilityChange?.(true);
  scheduleFrame();

  // Opt-in diagnostics for matched lighting comparisons and frame timings.
  const diagnostics = standalone && new URLSearchParams(window.location.search).has('qa');
  const qa = diagnostics ? {
    freeze: (value: boolean) => { frozen = value; },
    lockHue: (value: number | null) => { fixedHue = value === null ? null : clamp(value, 0, 1); },
    startTiming: () => { frames = []; },
    stopTiming: () => { const result = frames; frames = undefined; return result; },
    state: () => {
      const { shadowCount, lightCount, spotShadow, strobeShadow } = view.lightingState;
      const spots = lights.map((light, i) => ({ ...options.lights[i], ...lampPosition(light.angle, light.elevation),
        angle: light.angle, hue: light.hue, color: '#' + light.color.getHexString(),
        linearColor: light.color.toArray(), shadowSlot: spotShadow(light.id) }));
      const first = spots[0];
      return {
      hz: drive.hz, targetHz: drive.targetHz, fieldHz: sand.field.frequency, dpr, width, height, grainCount: sand.count,
      guidePosition: drive.guidePosition, guideTarget: drive.guideTarget, driveAxis: options.driveAxis,
      settings: options, profile, crop: currentCrop(), preparing: !!preparation, camera: { x, y, half, zoom: WIDE_HALF / half },
      relief: { active: view.relief.active, status: view.relief.status, placement: view.relief.placement.toArray(),
        castsShadows: view.relief.shadow.visible, passesLight: view.relief.passesLight },
      svg: { name: view.svg.image?.name, stencil: !!view.svg.stencil, cells: view.svg.stencil?.count,
        pose: view.svg.uniforms.svgPose.value.toArray(), opacity: view.svg.opacity.value },
      lamp: first && { ...first, target: toLegacyAngle(options.lights[0].position === 'follow' ? lampTarget : first.angle),
        angle: toLegacyAngle(first.angle) },
      lights: spots, lightCount, shadowCount,
      strobe: { ...flash, ...lampPosition(flash.angle, flash.elevation), color: '#' + flash.color.getHexString(),
        on: strobe.on, flashCount: strobe.flashCount, shadowSlot: strobeShadow },
      centreMicrometres: sand.field.centreMicrometres,
      renderer: gpuName(view.renderer.getContext()),
      webgl: view.renderer.getContext().getParameter(view.renderer.getContext().VERSION),
      };
    },
    field: () => ({
      hz: sand.field.frequency, size: FIELD_SIZE, acceleration: Array.from(sand.field.acceleration),
    }),
    grainFieldStats: () => grainFieldStats(sand),
    grainPositions: () => sand.readPositions(),
    signature: () => {
      const data = new Uint32Array(sand.readPositions().buffer);
      let hash = 2166136261;
      for (let i = 0; i < data.length; i++) hash = Math.imul(hash ^ data[i], 16777619);
      return hash >>> 0;
    },
    radialCounts: () => {
      const data = sand.readPositions();
      const bins = Array<number>(29).fill(0);
      for (let i = 0; i < data.length; i += 4) {
        const radius = Math.hypot(data[i], data[i + 1]) / HALF;
        bins[Math.floor(radius / 0.05)]++;
      }
      return { binWidth: 0.05, counts: bins };
    },
  } : undefined;
  const root = window as Window & { chladni?: typeof qa };
  if (qa) root.chladni = qa;

  return {
    resetZoom,
    movePointer: updatePointer,
    leavePointer: () => drivePointer.hold(),
    setActive(next: boolean) {
      if (active === next) return;
      active = next;
      if (!active) {
        cancelGesture?.();
        releaseHold();
        strobe.interrupt();
        drivePointer.hold();
      } else if (!contextLost) {
        resized();
        previous = 0;
      }
      scheduleFrame();
    },
    setPrepare(next: boolean) {
      prepare = next;
      scheduleFrame();
    },
    present() {
      if (contextLost || preparation) return false;
      drawStill();
      return !view.renderer.getContext().isContextLost();
    },
    cancelPreparation() {
      preparation = undefined;
      stage.dataset.state = 'ready';
      scheduleFrame();
    },
    overview: () => active && !contextLost ? sand.readPositions(16) : undefined,
    snapshot(arrangement: Arrangement): Start {
      if (contextLost || preparation) throw new Error('The plate must be ready before capturing a preset.');
      applyOptions();
      updateSpots(0);
      return { arrangement, seed: SAND_SEED, pour: sand.pourIndex, drive: drive.snapshot(),
        pointer: { x: pointerX, y: pointerY }, followAngle, lampTarget,
        lights: Array.from(renderedLights.values(), (light): Start['lights'][number] => ({ id: light.id, hue: light.hue,
          color: [light.color.r, light.color.g, light.color.b],
          pinnedColor: [light.pinnedColor.r, light.pinnedColor.g, light.pinnedColor.b], pinnedWeight: light.pinnedWeight })) };
    },
    restore(start: Start, done: () => void) {
      clearWarmupTimer();
      releaseHold();
      strobe.interrupt();
      applyOptions();
      drive.restore(start.drive);
      drivePointer.hold();
      pointerX = start.pointer.x; pointerY = start.pointer.y;
      lampTarget = start.lampTarget; followAngle = start.followAngle;
      renderedLights.clear();
      for (const light of options.lights) {
        const saved = start.lights.find(item => item.id === light.id)!;
        renderedLights.set(light.id, { ...light, hue: saved.hue, color: new Color().fromArray(saved.color),
          pinnedColor: new Color().fromArray(saved.pinnedColor), pinnedWeight: saved.pinnedWeight });
      }
      accumulator = 0;
      view.svg.hideGuide();
      syncFrame(true);
      publishFrequency();
      preparation = { start, steps: null, done };
      stage.dataset.state = 'preparing';
      scheduleFrame();
    },
    setSvgImage(image: SvgImage | null) { view.setSvgImage(image); applyOptions(); },
    resprinkle() {
      applyOptions();
      if (options.svg.enabled && options.svg.stencil && !view.svg.stencil) return;
      sand.resprinkle();
    },
    selectPattern(index: number) {
      applyOptions();
      drive.selectPattern(index);
      if (!canvas.matches(':hover')) drivePointer.hold();
    },
    captureLight(id: number) {
      const light = renderedLights.get(id);
      if (!light) return undefined;
      const { r, g, b } = light.color;
      return { angle: light.angle, color: '#' + light.color.getHexString(), linearColor: [r, g, b] as [number, number, number] };
    },
    dispose() {
      listeners.abort();
      observer.disconnect();
      cancelAnimationFrame(frame);
      clearWarmupTimer();
      clearWarmupFence();
      view.dispose();
      if (qa && root.chladni === qa) delete root.chladni;
    },
  };
}

function grainFieldStats(sand: Sand) {
  const { acceleration } = sand.field;
  const median = acceleration.slice().sort()[Math.floor(acceleration.length / 2)];
  const fieldMean = acceleration.reduce((sum, value) => sum + value, 0) / acceleration.length;
  const positions = sand.readPositions();
  let sum = 0;
  let belowMedian = 0;
  for (let i = 0; i < positions.length; i += 4) {
    const gamma = sand.field.sampleAcceleration(positions[i], positions[i + 1]);
    sum += gamma;
    if (gamma < median) belowMedian++;
  }
  return { fieldMedian: median, fieldMean, grainMean: sum / sand.count, fractionBelowMedian: belowMedian / sand.count };
}

function gpuName(gl: WebGLRenderingContext | WebGL2RenderingContext) {
  const info = gl.getExtension('WEBGL_debug_renderer_info');
  return info ? gl.getParameter(info.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER);
}
