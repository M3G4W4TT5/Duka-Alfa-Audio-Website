import * as THREE from 'three';
import { GPUComputationRenderer, type Variable } from 'three/addons/misc/GPUComputationRenderer.js';
import { GRAVITY, HALF, HALF_CELLS, SIDE, VibrationField, WAVE_SIZE } from './field';
import { DEFAULT_SETTINGS, GRAIN_COUNTS, SAND_SEED, normalizeGrainCount, reliefBounds } from './settings';
import waveSampling from './wave-sampling.glsl?raw';
import reliefContact from './relief-contact.glsl?raw';
import reliefMotion from './relief-motion.glsl?raw';
import type { GrainStencil } from './svg-layer';
import { advanceStencilReturn } from './stencil-return';

export const GRAIN_COLUMNS = 384;
const GRAIN_ROWS = GRAIN_COUNTS.max / GRAIN_COLUMNS;
export const STEP = 1 / 60;
const PACKING_SIZE = 576;
const RIDGE_CELLS = 192;
export const RIDGE_SPAN = .192; // One millimetre per texel in fixed plate coordinates.
const RESISTANCE_SIZE = 18;
const GRAIN_EDGE = 0.0898;
// A pour has no lateral impulse. Its descending speed is tagged until first contact.
export const POUR_VELOCITY_TAG = 1;

// The packing pass and both its readers use the same plate-to-texture transform.
const packingGrid = /* glsl */ `
  uniform vec4 packingFrame; // Rotation axis XY and texture-space offset ZW.
  mat2 packingBasis() {
    return mat2(packingFrame.xy, vec2(-packingFrame.y, packingFrame.x));
  }
  vec2 packingUV(vec2 p) {
    return packingBasis() * p / .255 + .5 + packingFrame.zw;
  }
`;

// A consecutive range of grain IDs spans at most two partial rows and a band of full rows.
function* grainRectangles(first: number, end: number): Generator<[number, number, number, number]> {
  while (first < end) {
    const x = first % GRAIN_COLUMNS;
    const y = Math.floor(first / GRAIN_COLUMNS);
    const width = Math.min(GRAIN_COLUMNS - x, end - first);
    const height = width === GRAIN_COLUMNS ? Math.floor((end - first) / GRAIN_COLUMNS) : 1;
    yield [x, y, width, height];
    first += width * height;
  }
}

const updateGrains = /* glsl */ `
  uniform sampler2D plateResistance;
  uniform float driveHz;
  uniform bool vibrationOn;
  uniform sampler2D stencilHomes;
  uniform vec4 homePose;
  uniform float returnBlend;
  uniform sampler2D packing;
  uniform vec3 strayMotion; // Takeoff rate, calibrated apex multiplier and lateral speed.
  uniform float tick;

  ${packingGrid}
  const int halfCells = ${HALF_CELLS};
  const float cellMetres = ${HALF / HALF_CELLS};
  const float stepSeconds = ${STEP};
  const float gravity = ${GRAVITY};
  const float grainEdge = ${GRAIN_EDGE};
  const float pourTag = ${POUR_VELOCITY_TAG.toFixed(1)};
  const float maxLayer = .00028;
  ${waveSampling}
  #ifdef DUKA_RELIEF
    #define RELIEF_SPAN ${reliefBounds.span}
    #define RELIEF_PIXELS ${reliefBounds.pixels.toFixed(1)}
    ${reliefContact}
    ${reliefMotion}

    // A returning grain rises over an approaching lip and falls under gravity
    // on the other side. At its destination only the actual surface supports it.
    float returnBed(vec2 p, vec2 home) {
      if (reliefPose.w <= 0.) return 0.;
      vec2 contact = reliefContact(p);
      if (contact.x < 0.) return surfaceHeight(contact);
      vec2 delta = home - p;
      float distanceLeft = length(delta);
      float reach = min(distanceLeft, 1.5 * reliefPose.w);
      if (contact.x >= reach) return 0.;
      float lip = surfaceHeight(reliefContact(p + delta * (reach / distanceLeft)));
      return lip * (1. - smoothstep(0., reach, contact.x));
    }
  #endif

  float random(vec2 st, float salt) {
    vec3 p = fract(vec3(st.xyx) * vec3(.1031, .1030, .0973) + salt);
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
  }

  vec4 dropVertically(vec4 grain, float bed) {
    bool poured = grain.w <= -pourTag;
    float speed = poured ? grain.w + pourTag : grain.w;
    float vz = speed - gravity * stepSeconds;
    float z = grain.z + .5 * (speed + vz) * stepSeconds;
    return z > bed ? vec4(grain.xy, z, poured ? vz - pourTag : vz) : vec4(grain.xy, bed, 0.);
  }

  // Gravity reduces vz by g*dt each tick, so the estimated apex tick stays
  // constant throughout one flight. It gives each impact its own lateral
  // bearing without storing a second particle texture.
  vec2 flightTravel(vec2 id, float vz, float heightAboveBed) {
    float verticalSpeed = sqrt(max(0., vz*vz + 2.*gravity*heightAboveBed));
    float airborneTime = clamp((vz + verticalSpeed) / gravity, 0., stepSeconds);
    float apexTick = mod(tick + floor(vz / (gravity * stepSeconds) + .5), 65536.);
    float impact = apexTick * .003542;
    float bearing = 6.2831853 * random(id, .419 + impact);
    // The apex key keeps this mean-one kick constant until the next impact.
    float kick = mix(.25, 1.75, random(id.yx, .871 + impact));
    return vec2(cos(bearing), sin(bearing)) * (.16 * verticalSpeed * airborneTime * strayMotion.z * kick);
  }

  void main() {
    // Contact and hop noise are keyed to permanent grain IDs at every population.
    vec2 uv = gl_FragCoord.xy / ${GRAIN_COLUMNS.toFixed(1)};
    vec4 particle = texelFetch(sandState, ivec2(gl_FragCoord.xy), 0);
    if (!vibrationOn && returnBlend > 0.) {
      vec2 local = texelFetch(stencilHomes, ivec2(gl_FragCoord.xy), 0).rg;
      vec2 home = clamp(homePose.xy + local * homePose.zw, vec2(-grainEdge), vec2(grainEdge));
      particle.xy = returnBlend >= 1. ? home : mix(particle.xy, home, returnBlend);
      #ifdef DUKA_RELIEF
        float bed = returnBed(particle.xy, home);
      #else
        float bed = 0.;
      #endif
      gl_FragColor = dropVertically(particle, bed);
      return;
    }
    #ifdef DUKA_RELIEF
      vec2 surface = reliefPose.w > 0. ? reliefContact(particle.xy) : vec2(1., 0.);
      float ground = surfaceHeight(surface);
    #else
      float ground = 0.;
    #endif
    bool supported = particle.w == 0. && particle.z <= ground + maxLayer + .000001;
    // When the shaker is turned down, airborne grains finish their lateral
    // flight and supported grains stay at rest. Pours always fall vertically.
    if (!vibrationOn || (driveHz <= 0. && supported) || particle.w <= -pourTag) {
      gl_FragColor = supported ? vec4(particle.xy, max(ground, particle.z), 0.) : dropVertically(particle, ground);
      return;
    }
    vec2 plate = particle.xy / ${SIDE} + .5;
    float gamma;
    vec2 transport = nodalDrift(particle.xy, gamma);
    vec2 resistanceUV = (plate * ${(RESISTANCE_SIZE - 1).toFixed(1)} + .5) / ${RESISTANCE_SIZE.toFixed(1)};

    // Short-range pressure gives a ridge width. A smoothed, wider pressure
    // gradient lets sand spread along a ridge after it reforms during a sweep.
    const vec2 tap = vec2(.5 / ${PACKING_SIZE.toFixed(1)}, 0.);
    mat2 packingRotation = packingBasis();
    vec2 cell = packingUV(particle.xy);
    vec2 pressure = vec2(
      textureLod(packing, cell - tap, 0.).r - textureLod(packing, cell + tap, 0.).r,
      textureLod(packing, cell - tap.yx, 0.).r - textureLod(packing, cell + tap.yx, 0.).r
    );
    vec2 spreading = vec2(
      textureLod(packing, cell - tap, 2.5).r - textureLod(packing, cell + tap, 2.5).r,
      textureLod(packing, cell - tap.yx, 2.5).r - textureLod(packing, cell + tap.yx, 2.5).r
    );
    pressure = transpose(packingRotation) * pressure;
    spreading = transpose(packingRotation) * spreading;
    spreading -= transport * dot(transport, spreading) / (dot(transport, transport) + .00000002);
    float count = textureLod(packing, cell, .5).r;
    vec2 contact = clamp(.00042 * pressure * clamp((count - 2.) / 7., 0., 2.), -.005, .005);
    vec2 pileFlow = contact + clamp(.0075 * spreading, -.005, .005);
    // Each grain has a persistent contact threshold. Vibration and pressure
    // can release it into sliding independently of the vertical hop test.
    float roundness = random(uv, .3);
    float angularity = 1. - roundness;
    // Rounded grains can reach the narrow ridges, while the angular tail
    // catches in the more weakly agitated areas around them.
    float resistance = (.035 + 1.84 * angularity * angularity) * texture2D(plateResistance, resistanceUV).r;
    float jostling = min(.55, length(pileFlow) * 75.);
    float sliding = smoothstep(resistance * .8, resistance + .35, gamma + jostling);
    // The most angular grains can bounce without consistently travelling
    // downhill. Their weak drift leaves a sparse moving population between
    // even the four tightly focused rings, without adding or recycling grains.
    float mobility = mix(.008, 1., smoothstep(.008, .018, roundness));
    vec2 drift = transport * sliding * mix(.72, 1.13, roundness) * mobility;
    drift += pileFlow * smoothstep(.00005, .0007, length(pileFlow));
    float vz = supported ? 0. : particle.w;
    float noise = tick * .003542;
    vec2 slip = vec2(random(uv, noise + .223), random(uv, noise + .734)) - .5;
    vec2 next = particle.xy + (supported ? drift * stepSeconds + slip * (.00016 * sliding) : vec2(0.));
    if (supported && gamma > 1.) {
      float capped = min(gamma, 35.);
      float speed = gravity / (6.28318530718 * driveHz) * sqrt(capped * capped - 1.);
      float flight = 2. * speed / gravity;
      float rate = 1. / max(flight, 1. / driveHz);
      float activeFraction = min(1., .55 * (gamma - 1.));
      float hit = random(uv, noise);
      if (hit < 1. - exp(-.65 * rate * activeFraction * stepSeconds)) {
        float impulse = random(uv, noise + .9091);
        // A sparse, driven contact can receive a burst of kicks within one
        // physics step. Start its resolved flight at contact so the renderer
        // can show the climb. The height envelope is calibrated in millimetres.
        float exposed = 1. - smoothstep(.6, 3., count);
        float agitation = (gamma - 1.) / (gamma - .75);
        float burstRate = 3.2 * agitation * exposed * (.5 + roundness) * strayMotion.x;
        if (hit < burstRate * stepSeconds && strayMotion.y > 0.) {
          float calibratedApex = (.0008 + .0024 * impulse) * agitation * exposed;
          if (calibratedApex > .00012) {
            float speedUp = sqrt(2. * gravity * (calibratedApex * strayMotion.y));
            gl_FragColor = vec4(particle.xy, max(ground, particle.z), speedUp);
            return;
          }
        }
        float phi = 6.2831853 * random(uv, noise + .5733);
        float dist = (min(.0035, .22 * speed * flight) + .000012) * (.28 + 1.52 * random(uv, noise + .3518));
        next += dist * vec2(cos(phi), sin(phi));
        float lift = min(.00065, .16 * speed * speed / (2. * gravity)) * impulse;
        vz = sqrt(2. * gravity * lift);
      }
    }
    float layer = clamp((count - 3.) * .000011, 0., maxLayer) * random(uv, .93);
    if (!supported || vz > .10) {
      next += flightTravel(uv, vz, max(0., particle.z - ground - layer));
    }
    next = sign(next) * (grainEdge - abs(grainEdge - abs(next)));
    #ifdef DUKA_RELIEF
      gl_FragColor = moveOnRelief(particle, next, surface, layer, vz, roundness, supported);
    #else
      float bed = supported ? mix(particle.z, layer, .18) : layer;
      float z = particle.z + stepSeconds * (vz - .5 * gravity * stepSeconds);
      gl_FragColor = z > bed ? vec4(next, z, vz - gravity * stepSeconds) : vec4(next, bed, 0.);
    #endif
  }
`;

const resprinkleGrains = /* glsl */ `
  uniform uint pour;
  uniform float pourHeight;
  uniform bool keepXY;
  uniform sampler2D original;
  #ifdef SVG_STENCIL
    uniform bool writeHomes;
    uniform highp usampler2D stencilTable;
    uniform int stencilCount;
    uniform uint stencilMass;
    uniform vec2 stencilPixels;
    uniform vec4 stencilPose;
    uvec2 stencilEntry(int index) {
      int width = textureSize(stencilTable, 0).x;
      return texelFetch(stencilTable, ivec2(index % width, index / width), 0).rg;
    }
  #endif

  // PCG hash of the grain ID and pour number. The upper 24 bits fit a float exactly.
  uint hash(uint inputValue) {
    uint state = inputValue * 747796405u + 2891336453u;
    uint word = ((state >> ((state >> 28u) + 4u)) ^ state) * 277803737u;
    return (word >> 22u) ^ word;
  }

  void main() {
    uvec2 cell = uvec2(gl_FragCoord.xy);
    uint id = cell.y * ${GRAIN_COLUMNS}u + cell.x;
    uint seed = id * 2u + pour * 2654435769u;
    vec2 unit = vec2(hash(seed) >> 8u, hash(seed + 1u) >> 8u) / 16777216.0;
    vec2 xy = keepXY ? texelFetch(original, ivec2(cell), 0).xy : (2.0 * unit - 1.0) * ${GRAIN_EDGE};
    float height = pourHeight;
    #ifdef SVG_STENCIL
      if (!keepXY) {
        // Invert the painted-area CDF. Open space never costs extra attempts,
        // even when the entire population is poured into a fine outline.
        float draw = float(hash(seed ^ 0xb5297a4du) >> 8u) / 16777216.;
        uint ticket = min(stencilMass - 1u, uint(draw * float(stencilMass)));
        int lo = 0, hi = stencilCount - 1;
        while (lo < hi) {
          int mid = (lo + hi) / 2;
          if (stencilEntry(mid).y <= ticket) lo = mid + 1; else hi = mid;
        }
        uint pixel = stencilEntry(lo).x, width = uint(stencilPixels.x);
        vec2 local = (vec2(pixel % width, pixel / width) + unit) / stencilPixels - .5;
        local.y = -local.y;
        if (writeHomes) { gl_FragColor = vec4(local, 0., 1.); return; }
        xy = clamp(stencilPose.xy + local * stencilPose.zw, vec2(-${GRAIN_EDGE}), vec2(${GRAIN_EDGE}));
        height = max(height, 0.);
      }
    #endif
    float z = height < 0. ? 0. : height + .002 + .008 * float(hash(seed ^ 0x8da6b343u) >> 8u) / 16777216.;
    gl_FragColor = vec4(xy, z, z > 0. ? -${POUR_VELOCITY_TAG.toFixed(1)} - .02 : 0.);
  }
`;

function seededRandom() {
  let seed: number = SAND_SEED;
  return () => {
    seed ^= seed << 13;
    seed ^= seed >>> 17;
    seed ^= seed << 5;
    return (seed >>> 0) / 4294967296;
  };
}

function plateResistance() {
  const random = seededRandom();
  const samples = Uint16Array.from({ length: RESISTANCE_SIZE ** 2 }, () =>
    THREE.DataUtils.toHalfFloat(0.73 + random() * 0.56));
  const texture = new THREE.DataTexture(samples, RESISTANCE_SIZE, RESISTANCE_SIZE, THREE.RedFormat, THREE.HalfFloatType);
  texture.minFilter = texture.magFilter = THREE.LinearFilter;
  texture.needsUpdate = true;
  return texture;
}

// The ping-pong simulation follows the Three.js GPUComputationRenderer
// approach used in Alexandru Dan's Chladni example, with P1 field and packing.
export class Sand {
  readonly field = new VibrationField();
  private activeCount: number = GRAIN_COUNTS.max;
  private readonly computation: GPUComputationRenderer;
  private readonly variable: Variable;
  private readonly resprinkleMaterial: THREE.ShaderMaterial;
  private readonly wave = new THREE.DataTexture(this.field.wave, WAVE_SIZE, WAVE_SIZE, THREE.RGBAFormat, THREE.FloatType);
  private readonly resistance = plateResistance();
  private readonly packingScene = new THREE.Scene();
  private readonly packingCamera = new THREE.Camera();
  private readonly packing = new THREE.WebGLRenderTarget(PACKING_SIZE, PACKING_SIZE, {
    depthBuffer: false,
    format: THREE.RedFormat,
    type: THREE.HalfFloatType,
    minFilter: THREE.LinearMipmapLinearFilter,
    magFilter: THREE.LinearFilter,
    generateMipmaps: true,
  });
  private readonly ridgeDensity = new THREE.WebGLRenderTarget(RIDGE_CELLS, RIDGE_CELLS, {
    format: THREE.RedFormat, type: THREE.HalfFloatType, depthBuffer: false,
    minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, generateMipmaps: false,
  });
  private readonly ridgeFilter: THREE.ShaderMaterial;
  private stepsSinceFilter = Infinity;
  private readonly packingGeometry = new THREE.BufferGeometry();
  private readonly packingMaterial: THREE.ShaderMaterial;
  private readonly clearColor = new THREE.Color();
  private readonly packingFrame = new THREE.Vector4(1, 0, 0, 0);
  private packingDirty = true;
  private readonly strayMotion = new THREE.Vector3(DEFAULT_SETTINGS.strayJumpRate, 1, DEFAULT_SETTINGS.straySideKick);
  private tick = 0;
  private reliefActive = false;
  private stencil: GrainStencil | null = null;
  private homes: THREE.WebGLRenderTarget | null = null;
  private homesDirty = true;
  private returnProgress = 0;
  private settlingSteps = 30;

  constructor(private readonly renderer: THREE.WebGLRenderer, count: number = DEFAULT_SETTINGS.grainCount,
    readonly form = new Float32Array(GRAIN_COUNTS.max * 4)) {
    if (!renderer.extensions.has('EXT_color_buffer_float')) {
      throw new Error('Floating-point WebGL2 render targets are unavailable.');
    }
    this.computation = new GPUComputationRenderer(GRAIN_COLUMNS, GRAIN_ROWS, renderer);
    const initial = this.computation.createTexture();
    const random = seededRandom();
    const texels = new Uint16Array(GRAIN_COUNTS.max * 2);
    for (let i = 0; i < GRAIN_COUNTS.max; i++) {
      texels[i * 2] = i % GRAIN_COLUMNS;
      texels[i * 2 + 1] = Math.floor(i / GRAIN_COLUMNS);
      initial.image.data[i * 4] = (2 * random() - 1) * GRAIN_EDGE;
      initial.image.data[i * 4 + 1] = (2 * random() - 1) * GRAIN_EDGE;
      // Fine sand distribution with a few larger, slightly warmer grains.
      this.form[i * 4] = 0.000161 * (0.54 + 0.92 * (random() + random()) / 2);
      this.form[i * 4 + 1] = 2 * Math.PI * random();
      this.form[i * 4 + 2] = random();
      this.form[i * 4 + 3] = random();
    }
    this.variable = this.computation.addVariable('sandState', updateGrains, initial);
    this.variable.material.uniforms.wave = { value: this.wave };
    this.variable.material.uniforms.plateResistance = { value: this.resistance };
    this.variable.material.uniforms.driveHz = { value: 0 };
    this.variable.material.uniforms.vibrationOn = { value: true };
    this.variable.material.uniforms.stencilHomes = { value: null };
    this.variable.material.uniforms.homePose = { value: new THREE.Vector4() };
    this.variable.material.uniforms.returnBlend = { value: 0 };
    this.variable.material.uniforms.packing = { value: this.packing.texture };
    this.variable.material.uniforms.packingFrame = { value: this.packingFrame };
    this.variable.material.uniforms.strayMotion = { value: this.strayMotion };
    this.variable.material.uniforms.tick = { value: 0 };
    this.variable.material.uniforms.reliefMap = { value: null };
    this.variable.material.uniforms.reliefPose = { value: new THREE.Vector4() };
    this.computation.setVariableDependencies(this.variable, [this.variable]);
    const failure = this.computation.init();
    if (failure) throw new Error(failure);
    // Average density around a fixed point on the plate before sampling it
    // for lighting. This avoids making a static ridge flash as the physics grid rotates.
    this.ridgeFilter = this.computation.createShaderMaterial(`
      ${packingGrid}
      uniform sampler2D packing;
      uniform float blend;
      void main() {
        vec2 p = (gl_FragCoord.xy / ${RIDGE_CELLS.toFixed(1)} - .5) * ${RIDGE_SPAN};
        vec2 uv = packingUV(p);
        mat2 taps = packingBasis() * (.0007 / .255);
        float n = 2. * textureLod(packing, uv, 1.35).r
          + textureLod(packing, uv + taps[0], 1.35).r + textureLod(packing, uv - taps[0], 1.35).r
          + textureLod(packing, uv + taps[1], 1.35).r + textureLod(packing, uv - taps[1], 1.35).r;
        gl_FragColor = vec4(smoothstep(1.6, 9., n / 6.), 0., 0., blend);
      }`, { packing: { value: this.packing.texture }, packingFrame: { value: this.packingFrame }, blend: { value: 1 } });
    this.ridgeFilter.depthTest = this.ridgeFilter.depthWrite = false;
    this.ridgeFilter.blending = THREE.CustomBlending;
    this.ridgeFilter.blendSrc = THREE.SrcAlphaFactor;
    this.ridgeFilter.blendDst = THREE.OneMinusSrcAlphaFactor;
    this.resprinkleMaterial = this.computation.createShaderMaterial(resprinkleGrains, {
      pour: { value: 0 }, pourHeight: { value: -1 }, keepXY: { value: false }, original: { value: null },
      writeHomes: { value: false },
      stencilTable: { value: null }, stencilCount: { value: 0 }, stencilMass: { value: 0 },
      stencilPixels: { value: new THREE.Vector2() }, stencilPose: { value: new THREE.Vector4() },
    });

    // Rasterize one additive point per grain into a small world-space occupancy grid.
    this.packingGeometry.setAttribute('position', new THREE.BufferAttribute(texels, 2));
    // The attribute addresses texels. The actual grain coordinates lie on the plate.
    this.packingGeometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(), Math.SQRT2 * HALF);
    this.packingGeometry.setDrawRange(0, this.activeCount);
    this.packingMaterial = new THREE.ShaderMaterial({
      uniforms: { state: { value: this.texture }, packingFrame: { value: this.packingFrame } },
      depthTest: false,
      depthWrite: false,
      blending: THREE.CustomBlending,
      blendSrc: THREE.OneFactor,
      blendDst: THREE.OneFactor,
      vertexShader: `
        uniform sampler2D state;
        ${packingGrid}
        void main() {
          vec4 grain = texelFetch(state, ivec2(position.xy), 0);
          if (grain.w != 0.) { gl_Position = vec4(2., 2., 2., 1.); return; }
          vec2 xy = grain.xy;
          gl_Position = vec4(packingBasis() * xy * (2. / .255) + 2. * packingFrame.zw, 0., 1.);
          gl_PointSize = 3.;
        }
      `,
      fragmentShader: `
        void main() {
          vec2 delta = gl_PointCoord - .5;
          float grain = .39 * exp(-4.5 * dot(delta, delta));
          gl_FragColor = vec4(grain, 0., 0., 0.);
        }
      `,
    });
    const points = new THREE.Points(this.packingGeometry, this.packingMaterial);
    points.frustumCulled = false;
    this.packingScene.add(points);
    this.setCount(count);
  }

  get count() { return this.activeCount; }
  get pourIndex(): number { return this.resprinkleMaterial.uniforms.pour.value; }

  initialize(stencilPour: boolean, pour: number) {
    this.invalidatePacking();
    this.tick = 0;
    this.returnProgress = 0;
    this.settlingSteps = 30;
    this.homesDirty = true;
    const u = this.resprinkleMaterial.uniforms;
    u.pour.value = pour;
    u.keepXY.value = !stencilPour;
    u.original.value = this.variable.initialValueTexture;
    try {
      for (const target of this.variable.renderTargets) {
        if (stencilPour || this.reliefActive) this.computation.doRenderTarget(this.resprinkleMaterial, target);
        else this.computation.renderTexture(this.variable.initialValueTexture, target);
      }
    } finally {
      u.keepXY.value = false;
      u.original.value = null;
    }
  }

  setStrayMotion(rate: number, heightMm: number, sideways: number) {
    // The calibrated impulse spans 0.8 to 3.2 mm at full exposure.
    this.strayMotion.set(rate, heightMm / 3.2, sideways);
  }

  setShakerStrength(strength: number) {
    if (this.field.strength === strength) return;
    this.field.update(Number.isFinite(this.field.frequency) ? this.field.frequency : 0, strength);
    this.wave.needsUpdate = true;
  }

  setStencil(stencil: GrainStencil | null) {
    const material = this.resprinkleMaterial;
    const homeUniforms = this.variable.material.uniforms;
    if (stencil?.table !== this.stencil?.table || stencil?.count !== this.stencil?.count) {
      this.homesDirty = true;
      this.returnProgress = 0;
    }
    if (Boolean(stencil) !== Boolean(this.stencil)) {
      if (stencil) material.defines.SVG_STENCIL = 1; else delete material.defines.SVG_STENCIL;
      material.needsUpdate = true;
    }
    this.stencil = stencil;
    const u = material.uniforms;
    u.stencilTable.value = stencil?.table ?? null;
    if (stencil) {
      u.stencilCount.value = stencil.count;
      u.stencilMass.value = stencil.mass;
      u.stencilPixels.value = stencil.pixels;
      u.stencilPose.value = stencil.pose;
      // The layer mutates its pose in place. Keep a separate copy to detect a
      // retarget even after all grains have come to rest.
      if (!homeUniforms.homePose.value.equals(stencil.pose)) {
        homeUniforms.homePose.value.copy(stencil.pose);
        this.returnProgress = 0;
      }
    } else if (this.homes) {
      this.homes.dispose();
      this.homes = null;
      homeUniforms.stencilHomes.value = null;
    }
  }

  private prepareHomes() {
    if (!this.homesDirty) return;
    // The pour shader assigns one stable local coordinate to each grain ID.
    // Cache all IDs, so a population change or a moved logo needs no new lookup.
    this.homes ??= new THREE.WebGLRenderTarget(GRAIN_COLUMNS, GRAIN_ROWS, {
      format: THREE.RGFormat, type: THREE.FloatType, depthBuffer: false,
      minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter,
    });
    const writeHomes = this.resprinkleMaterial.uniforms.writeHomes;
    writeHomes.value = true;
    try {
      this.computation.doRenderTarget(this.resprinkleMaterial, this.homes);
    } finally {
      writeHomes.value = false;
    }
    this.variable.material.uniforms.stencilHomes.value = this.homes.texture;
    this.homesDirty = false;
  }

  private advanceReturn(speed: number) {
    if (this.returnProgress >= 1) return 0;
    this.prepareHomes();
    const { progress, blend } = advanceStencilReturn(this.returnProgress, speed, STEP);
    this.returnProgress = progress;
    this.settlingSteps = 30;
    return blend;
  }

  setRelief(texture: THREE.Texture | null, pose: THREE.Vector4) {
    const active = texture !== null;
    const uniforms = this.resprinkleMaterial.uniforms;
    uniforms.pourHeight.value = active ? pose.w : -1;
    const contact = this.variable.material.uniforms;
    if (contact.reliefMap.value !== texture || !contact.reliefPose.value.equals(pose)) this.settlingSteps = 30;
    contact.reliefMap.value = texture;
    contact.reliefPose.value.copy(pose);
    if (this.reliefActive === active) return;
    this.invalidatePacking();
    this.reliefActive = active;
    if (active) this.variable.material.defines.DUKA_RELIEF = 1;
    else delete this.variable.material.defines.DUKA_RELIEF;
    this.variable.material.needsUpdate = true;
    // Drop onto the new physical surface at the same XY in both ping-pong states.
    const current = this.computation.getCurrentRenderTarget(this.variable);
    const next = this.computation.getAlternateRenderTarget(this.variable);
    uniforms.keepXY.value = true;
    uniforms.original.value = current.texture;
    this.computation.doRenderTarget(this.resprinkleMaterial, next);
    this.computation.renderTexture(next.texture, current);
    uniforms.original.value = null;
    uniforms.keepXY.value = false;
  }

  private writeGrains(first: number, end: number, render: (target: THREE.WebGLRenderTarget) => void,
    half: 'left' | 'right' | 'both' = 'both') {
    for (const target of this.variable.renderTargets) {
      const wasScissored = target.scissorTest;
      const previous = target.scissor.clone();
      target.scissorTest = true;
      try {
        for (const [x, y, width, height] of grainRectangles(first, end)) {
          const middle = Math.floor(width / 2);
          const left = half === 'right' ? middle : 0;
          const right = half === 'left' ? middle : width;
          if (left === right) continue;
          target.scissor.set(x + left, y, right - left, height);
          render(target);
        }
      } finally {
        target.scissor.copy(previous);
        target.scissorTest = wasScissored;
      }
    }
  }

  resprinkle() {
    this.invalidatePacking();
    this.settlingSteps = 30;
    this.homesDirty = true;
    this.returnProgress = 0;
    const pour = this.resprinkleMaterial.uniforms.pour;
    pour.value = (pour.value + 1) >>> 0;
    // Split each occupied row, including the last one for small or uneven populations.
    const half = this.stencil ? 'both' : pour.value % 2 ? 'right' : 'left';
    this.writeGrains(0, this.count, target => this.computation.doRenderTarget(this.resprinkleMaterial, target), half);
  }

  setCount(requested: number) {
    const count = normalizeGrainCount(requested);
    if (count === this.activeCount) return;
    this.invalidatePacking();
    this.settlingSteps = 30;
    if (count > this.activeCount) {
      const u = this.resprinkleMaterial.uniforms;
      u.keepXY.value = this.reliefActive && !this.stencil;
      u.original.value = u.keepXY.value ? this.variable.initialValueTexture : null;
      try {
        this.writeGrains(this.activeCount, count, target => {
          if (this.stencil || this.reliefActive) this.computation.doRenderTarget(this.resprinkleMaterial, target);
          else this.computation.renderTexture(this.variable.initialValueTexture, target);
        });
      } finally {
        u.keepXY.value = false;
        u.original.value = null;
      }
    }
    for (const target of this.variable.renderTargets) {
      target.scissorTest = count < GRAIN_COUNTS.max;
      target.scissor.set(0, 0, Math.min(count, GRAIN_COLUMNS), Math.ceil(count / GRAIN_COLUMNS));
    }
    this.packingGeometry.setDrawRange(0, count);
    this.activeCount = count;
  }

  get texture() {
    return this.computation.getCurrentRenderTarget(this.variable).texture;
  }

  get previousTexture() {
    return this.computation.getAlternateRenderTarget(this.variable).texture;
  }

  private invalidatePacking() {
    this.packingDirty = true;
    this.stepsSinceFilter = Infinity;
  }

  packingForLighting() {
    if (this.packingDirty) this.drawPacking();
    if (this.stepsSinceFilter > 0) {
      // Reuse the driven step's density pass. Blend in plate coordinates over
      // 80 ms of simulated time. A pour or rearrangement starts a fresh field.
      this.ridgeFilter.uniforms.blend.value = 1 - Math.exp(-this.stepsSinceFilter * STEP / .08);
      const wasClearing = this.renderer.autoClear;
      this.renderer.autoClear = false;
      try {
        this.computation.doRenderTarget(this.ridgeFilter, this.ridgeDensity);
      } finally {
        this.renderer.autoClear = wasClearing;
      }
      this.stepsSinceFilter = 0;
    }
    return this.ridgeDensity.texture;
  }

  private drawPacking() {
    const { renderer } = this;
    renderer.getClearColor(this.clearColor);
    const alpha = renderer.getClearAlpha();
    renderer.setClearColor(0, 0);
    this.packingMaterial.uniforms.state.value = this.texture;
    renderer.setRenderTarget(this.packing);
    renderer.render(this.packingScene, this.packingCamera);
    renderer.setRenderTarget(null);
    renderer.setClearColor(this.clearColor, alpha);
    this.packingDirty = false;
    this.stepsSinceFilter++;
  }

  step(frequency: number, vibration = true, returnSpeed = 0) {
    if (this.field.update(frequency)) {
      this.wave.needsUpdate = true;
    }

    const driven = vibration && this.field.strength > 0;
    this.variable.material.uniforms.driveHz.value = driven ? frequency : 0;
    this.variable.material.uniforms.vibrationOn.value = vibration && frequency > 0;
    if (vibration) this.tick = (this.tick + 1) % 65_536;
    this.variable.material.uniforms.tick.value = this.tick;
    if (vibration || returnSpeed <= 0 || !this.stencil) this.returnProgress = 0;
    if (!driven || frequency <= 0) {
      this.variable.material.uniforms.returnBlend.value =
        !vibration && this.stencil && returnSpeed > 0 ? this.advanceReturn(returnSpeed) : 0;
      // Half a simulated second is longer than a fall from the maximum pour
      // height, including a grain already rising when vibration is switched off.
      if (this.settlingSteps > 0) {
        this.computation.compute();
        this.invalidatePacking();
        this.settlingSteps--;
      }
      return;
    }
    this.settlingSteps = 30;
    // Rotate and offset the density grid so its cells cannot imprint on the sand.
    const angle = (this.tick * 2.399963229728653) % (2 * Math.PI);
    this.packingFrame.set(Math.cos(angle), Math.sin(angle),
      ((this.tick * 0.6180339887) % 1 - .5) / PACKING_SIZE,
      ((this.tick * 0.4142135624) % 1 - .5) / PACKING_SIZE,
    );
    this.drawPacking();
    this.computation.compute();
  }

  readPositions(maxRows = GRAIN_ROWS) {
    const count = Math.min(this.count, maxRows * GRAIN_COLUMNS);
    const pixels = new Float32Array(count * 4);
    const target = this.computation.getCurrentRenderTarget(this.variable);
    for (const [x, y, width, height] of grainRectangles(0, count)) {
      const offset = (y * GRAIN_COLUMNS + x) * 4;
      this.renderer.readRenderTargetPixels(target, x, y, width, height, pixels.subarray(offset, offset + width * height * 4));
    }
    return pixels;
  }

  dispose() {
    this.homes?.dispose();
    this.ridgeFilter.dispose();
    this.ridgeDensity.dispose();
    this.resprinkleMaterial.dispose();
    this.variable.material.dispose();
    this.computation.dispose();
    this.packingMaterial.dispose();
    this.packingGeometry.dispose();
    this.packing.dispose();
    this.wave.dispose();
    this.resistance.dispose();
  }
}
