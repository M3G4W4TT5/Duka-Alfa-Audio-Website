import { Color } from 'three';
import { HALF } from './field.ts';
import type { DriveMode } from './patterns';
import reliefBounds from '../assets/duka-bounds.json' with { type: 'json' };
import { DEFAULT_LOGO_EFFECT, DEFAULT_SURFACE, type LogoEffect, type MaterialLinks, type SurfaceStyle } from './surface-settings.ts';

export type GradientStop = { id: number; position: number; color: string };
export type Axis = 'horizontal' | 'vertical';
export type LightColourSource = Axis | 'fixed';
export { reliefBounds };

export interface SpotlightSettings {
  id: number;
  position: 'follow' | 'fixed';
  angle: number; // Clockwise degrees from the top edge of the plate.
  colorSource: LightColourSource;
  color: string;
  linearColor?: [number, number, number];
  intensity: number;
  elevation: number;
  beamWidth: number;
}

export interface StrobeSettings {
  mode: 'off' | 'hold' | 'automatic';
  source: number | 'fixed';
  angle: number;
  color: string;
  strength: number;
  rate: number;
  width: number;
  flashes: number; // Zero gives a continuous train of pulses.
  gap: number;
}

export const MAX_SPOTLIGHTS = 4;
export const SAND_SEED = 0x7a372ca1;
export const GRAIN_COUNTS = { min: 100, max: 589_824, step: 1 } as const;
export const GRAIN_SIZE = { min: .25, max: 10, step: .25 } as const;
export const SHAKER_STRENGTH = { min: 0, max: 2, step: .05 } as const;
export const EMITTER_RADIUS = { min: 0, max: 1.5, step: .05 } as const; // Millimetres.
export const STRAY_JUMPS = {
  rate: { min: 0, max: 6, step: .1 },
  height: { min: 0, max: 8, step: .1 },
  kick: { min: 0, max: 4, step: .1 },
} as const;
export const DEFAULT_SPOTLIGHT: SpotlightSettings = {
  id: 1,
  position: 'follow',
  angle: 180,
  colorSource: 'horizontal',
  color: '#b86ac0',
  intensity: 1,
  elevation: 10.7,
  beamWidth: 133,
};

export const DEFAULT_STROBE: StrobeSettings = {
  mode: 'off',
  source: 1,
  angle: 315,
  color: '#f8f4ff',
  strength: 7,
  rate: 2,
  width: 70,
  flashes: 3,
  gap: 1000,
};

export interface SvgLayerSettings {
  enabled: boolean;
  stencil: boolean;
  artwork: boolean;
  shape: 'fill' | 'outline';
  weight: number; // Inward outline width in mm.
  returnToStencil: boolean;
  returnSpeed: number; // Playback multiplier for the three-second return.
  size: number; // Longest painted dimension as a percentage of plate width.
  x: number;
  y: number;
  height: number; // Millimetres above the plate, independent of the stencil.
  opacity: number;
  shadows: boolean;
}

export const DEFAULT_SVG: SvgLayerSettings = {
  enabled: false, stencil: true, artwork: false, shape: 'fill', weight: .6,
  returnToStencil: false, returnSpeed: 1,
  size: 50, x: 0, y: 0, height: 0, opacity: 1, shadows: true,
};

export function svgPlacement(size: number, aspect: number) {
  const side = HALF * 2000;
  const longest = side * size / 100;
  const width = longest * Math.min(1, aspect), height = longest / Math.max(1, aspect);
  return { width, height, travelX: Math.floor((side - width) * 5) / 10,
    travelY: Math.floor((side - height) * 5) / 10 };
}

export interface PlateSettings {
  background: 'flat' | '3d';
  svg: SvgLayerSettings;
  vibration: boolean;
  backgroundMaterial: SurfaceStyle;
  logoMaterial: SurfaceStyle;
  materialLinks: MaterialLinks;
  logoTextureAnchor: [number, number]; // Plate coordinates in mm when the texture was unlinked.
  logoEffect: LogoEffect;
  reliefLighting: 'solid' | 'pass-through';
  logoSize: number; // Percentage of plate width.
  logoHeight: number; // Millimetres above the plate.
  logoX: number; // Millimetres from centre, positive right/up.
  logoY: number;
  mode: DriveMode;
  driveAxis: Axis;
  patternPointerDisabled: boolean;
  minHz: number;
  maxHz: number;
  shakerStrength: number; // Relative drive amplitude at the selected frequency.
  sandSpeed: number;
  strayJumpRate: number; // Multiplier for loose-grain takeoffs.
  strayBounceHeight: number; // Maximum loose-grain apex above contact, in mm.
  straySideKick: number; // Multiplier for sideways travel during flight.
  grainCount: number;
  grainSize: number; // Linear scale of each grain's original dimensions.
  grainSmoothing: boolean;
  highlightVariation: number;
  ridgeShading: number;
  emitterRadius: number;
  gradient: GradientStop[];
  lights: SpotlightSettings[];
  strobe: StrobeSettings;
  bloomStrength: number;
  bloomRadius: number;
  bloomFalloff: number;
  bloomThreshold: number;
  bloomGrit: number;
}

export type BloomSettings = Pick<PlateSettings, 'bloomStrength' | 'bloomRadius' | 'bloomFalloff' | 'bloomThreshold' | 'bloomGrit'>;

export const DEFAULT_SETTINGS: PlateSettings = {
  background: 'flat',
  svg: DEFAULT_SVG,
  vibration: true,
  backgroundMaterial: DEFAULT_SURFACE,
  logoMaterial: DEFAULT_SURFACE,
  materialLinks: { colour: true, finish: true, texture: true },
  logoTextureAnchor: [0, 0],
  logoEffect: DEFAULT_LOGO_EFFECT,
  reliefLighting: 'solid',
  logoSize: 50,
  logoHeight: 1,
  logoX: 0,
  logoY: 0,
  mode: 'frequency',
  driveAxis: 'vertical',
  patternPointerDisabled: false,
  minHz: 100,
  maxHz: 182,
  shakerStrength: 1,
  sandSpeed: 2.25,
  strayJumpRate: 1,
  strayBounceHeight: 3.2,
  straySideKick: .4,
  grainCount: GRAIN_COUNTS.max,
  grainSize: 1,
  grainSmoothing: false,
  highlightVariation: .8,
  ridgeShading: .8,
  emitterRadius: .65,
  gradient: [
    { id: 0, position: 0, color: '#9b64f3' },
    { id: 1, position: 1, color: '#d16e42' },
  ],
  lights: [DEFAULT_SPOTLIGHT],
  strobe: DEFAULT_STROBE,
  bloomStrength: 0.72,
  bloomRadius: 0.44,
  bloomFalloff: 0.35,
  bloomThreshold: 0.49,
  bloomGrit: 0.41,
};

export const clamp = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));

export function logoTravel(sizePercent: number) {
  const plateHalfMm = HALF * 1000;
  const halfWidth = plateHalfMm * sizePercent / 100;
  const aspect = (reliefBounds.hi[1] - reliefBounds.lo[1]) / (reliefBounds.hi[0] - reliefBounds.lo[0]);
  const room = (half: number) => Math.max(0, Math.floor((plateHalfMm - half) * 10) / 10);
  return { x: room(halfWidth), y: room(halfWidth * aspect) };
}

export function pointerDriveAxis(settings: PlateSettings): Axis | null {
  return settings.mode === 'patterns' && settings.patternPointerDisabled ? null : settings.driveAxis;
}

export function normalizeGrainCount(value: number) {
  return Number.isFinite(value) ? clamp(Math.round(value), GRAIN_COUNTS.min, GRAIN_COUNTS.max) : DEFAULT_SETTINGS.grainCount;
}

export function sampleGradient(stops: GradientStop[], at: number, color: Color, next: Color) {
  let left = stops[0];
  for (let i = 1; i < stops.length; i++) {
    const right = stops[i];
    if (at < right.position) {
      const fraction = (at - left.position) / (right.position - left.position);
      return color.set(left.color).lerp(next.set(right.color), fraction);
    }
    left = right;
  }
  return color.set(left.color);
}
