import { z } from 'zod';
import { MAX_FREQUENCY } from './field.ts';
import { LAST_PATTERN } from './patterns.ts';
import { DEFAULT_SETTINGS, EMITTER_RADIUS, GRAIN_COUNTS, GRAIN_SIZE, MAX_SPOTLIGHTS, SAND_SEED, SHAKER_STRENGTH, STRAY_JUMPS, type PlateSettings } from './settings.ts';
import { FIT_SPAN, MAX_ZOOM, VIEW_SIZES, type Framing } from './framing.ts';
import type { PlateDrive } from './drive.ts';

const range = (min: number, max: number) => z.number().finite().min(min).max(max);
const unit = range(0, 1);
const hz = range(0, MAX_FREQUENCY);
const guide = range(0, LAST_PATTERN);
const angle = range(0, 360);
const colour = z.string().regex(/^#[0-9a-f]{6}$/i, 'Expected a six-digit hex colour');
const rgb = z.tuple([unit, unit, unit]);
const flag = z.boolean();
const lightId = range(1, MAX_SPOTLIGHTS).int();
const mm = range(-90, 90);
const surface = z.object({
  colour,
  finish: z.object({ metalness: unit, roughness: range(.035, 1), reflections: range(0, 1.5) }),
  texture: z.object({ kind: z.enum(['smooth', 'brushed', 'grit', 'corroded']), strength: unit,
    scaleMm: range(5, 180), angle: range(0, 180), colourMix: unit }),
});
const settings = z.object({
  background: z.enum(['flat', '3d']), vibration: flag,
  svg: z.object({ enabled: flag, stencil: flag, artwork: flag, shape: z.enum(['fill', 'outline']),
    weight: range(.1, 5), returnToStencil: flag, returnSpeed: range(.25, 4), size: range(5, 100),
    x: mm, y: mm, height: range(0, 8), opacity: unit, shadows: flag }),
  backgroundMaterial: surface, logoMaterial: surface, materialLinks: z.object({ colour: flag, finish: flag, texture: flag }),
  logoTextureAnchor: z.tuple([mm, mm]), reliefLighting: z.enum(['solid', 'pass-through']),
  logoEffect: z.object({ kind: z.enum(['off', 'colour', 'neon']), coverage: z.enum(['edges', 'whole']), colour,
    widthMm: range(.05, 1.5), opacity: unit, emission: range(0, 12), spill: unit }),
  logoSize: range(15, 100), logoHeight: range(0, 4), logoX: mm, logoY: mm,
  mode: z.enum(['frequency', 'patterns']), driveAxis: z.enum(['horizontal', 'vertical']), patternPointerDisabled: flag,
  minHz: hz, maxHz: hz, sandSpeed: range(.25, 4),
  shakerStrength: range(SHAKER_STRENGTH.min, SHAKER_STRENGTH.max).default(DEFAULT_SETTINGS.shakerStrength),
  strayJumpRate: range(STRAY_JUMPS.rate.min, STRAY_JUMPS.rate.max).default(DEFAULT_SETTINGS.strayJumpRate),
  strayBounceHeight: range(STRAY_JUMPS.height.min, STRAY_JUMPS.height.max).default(DEFAULT_SETTINGS.strayBounceHeight),
  straySideKick: range(STRAY_JUMPS.kick.min, STRAY_JUMPS.kick.max).default(DEFAULT_SETTINGS.straySideKick),
  grainCount: range(GRAIN_COUNTS.min, GRAIN_COUNTS.max).int(),
  grainSize: range(GRAIN_SIZE.min, GRAIN_SIZE.max).default(DEFAULT_SETTINGS.grainSize),
  grainSmoothing: flag.default(DEFAULT_SETTINGS.grainSmoothing),
  highlightVariation: unit.default(DEFAULT_SETTINGS.highlightVariation),
  ridgeShading: unit.default(DEFAULT_SETTINGS.ridgeShading),
  emitterRadius: range(EMITTER_RADIUS.min, EMITTER_RADIUS.max).default(DEFAULT_SETTINGS.emitterRadius),
  gradient: z.array(z.object({ id: z.number().int().nonnegative(), position: unit, color: colour })).min(2),
  lights: z.array(z.object({ id: lightId, position: z.enum(['follow', 'fixed']), angle,
    colorSource: z.enum(['horizontal', 'vertical', 'fixed']), color: colour, linearColor: rgb.optional(),
    intensity: range(0, 3), elevation: range(4, 60), beamWidth: range(24, 174) })).min(1).max(MAX_SPOTLIGHTS),
  strobe: z.object({ mode: z.enum(['off', 'hold', 'automatic']), source: z.union([z.literal('fixed'), lightId]),
    angle, color: colour, strength: range(0, 20), rate: range(.25, 50), width: range(1, 180), flashes: range(0, 12).int(),
    gap: range(50, 10000) }),
  bloomStrength: range(0, 2), bloomRadius: unit, bloomFalloff: unit, bloomThreshold: range(.05, 1.5), bloomGrit: range(0, .8),
}).superRefine((s, ctx) => {
  const issue = (path: string, message: string) => ctx.addIssue({ code: 'custom', path: [path], message });
  if (s.minHz > s.maxHz) issue('minHz', 'Minimum frequency exceeds maximum');
  if (new Set(s.lights.map(l => l.id)).size !== s.lights.length) issue('lights', 'Duplicate light ID');
  if (s.strobe.source !== 'fixed' && !s.lights.some(l => l.id === s.strobe.source)) issue('strobe', 'Unknown source light');
  if (s.gradient[0].id !== 0 || s.gradient.at(-1)?.id !== 1 || s.gradient[0].position !== 0 || s.gradient.at(-1)?.position !== 1 ||
    new Set(s.gradient.map(stop => stop.id)).size !== s.gradient.length ||
    s.gradient.some((stop, i, all) => i > 0 && stop.position < all[i - 1].position))
    issue('gradient', 'Expected unique stops ordered from 0 to 1');
}) satisfies z.ZodType<PlateSettings, z.ZodTypeDef, unknown>;

const crop = z.object({ centerX: unit, centerY: unit, width: z.number().finite().positive(), height: z.number().finite().positive() })
  .refine(c => Math.min(c.width, c.height) <= FIT_SPAN + 1e-8, 'Crop exceeds the plate overview');
function device(size: readonly [number, number]) {
  return z.object({ enabled: flag, width: z.literal(size[0]), height: z.literal(size[1]), crop })
    .refine(v => Math.min(v.crop.width, v.crop.height) >= FIT_SPAN / MAX_ZOOM - 1e-8, 'Crop exceeds the zoom range')
    .refine(v => Math.abs(v.crop.width / v.crop.height - v.width / v.height) < 1e-6, 'Crop aspect differs from the reference frame');
}
const framing = z.object({ breakpoint: range(240, 2560).int(), fit: z.literal('cover'), window: crop.nullable(),
  desktop: device(VIEW_SIZES.desktop), mobile: device(VIEW_SIZES.mobile) }) satisfies z.ZodType<Framing>;
const drive = z.object({ hz, targetHz: hz, filteredHz: hz, directHeight: unit, guidePosition: guide, guideTarget: guide,
  travelPosition: guide, entryOffsetHz: range(-MAX_FREQUENCY, MAX_FREQUENCY) }) satisfies z.ZodType<ReturnType<PlateDrive['snapshot']>>;
const start = z.object({
  arrangement: z.enum(['loose', 'stencil', 'pattern']), seed: z.literal(SAND_SEED), pour: range(0, 0xffffffff).int(),
  drive, pointer: z.object({ x: unit, y: unit }), followAngle: angle, lampTarget: angle,
  lights: z.array(z.object({ id: lightId, hue: unit, color: rgb, pinnedColor: rgb, pinnedWeight: unit })).max(MAX_SPOTLIGHTS),
});
export const ENGINE = 'chladni-p1/1';
export const BUILTINS = { model: 'duka-relief/v1', surfaces: 'duka-surfaces/v1' } as const;
export const DUKA_SVG = { type: 'builtin', id: 'duka-stencil/v1' } as const;
const asset = z.discriminatedUnion('type', [z.object({ type: z.literal('builtin'), id: z.literal(DUKA_SVG.id) }),
  z.object({ type: z.literal('inline'), filename: z.string().min(1), source: z.string().min(1) })]);
const configuration = z.object({
  schemaVersion: z.literal(1), engine: z.literal(ENGINE), settings, start, framing,
  editor: z.object({ view: z.enum(['window', 'desktop', 'mobile']), editCrop: flag, controlsOnly: flag.optional() }),
  assets: z.object({ model: z.literal(BUILTINS.model), surfaces: z.literal(BUILTINS.surfaces), svg: asset }),
}).superRefine((c, ctx) => {
  if (c.start.arrangement === 'stencil' && !(c.settings.svg.enabled && c.settings.svg.stencil))
    ctx.addIssue({ code: 'custom', path: ['start', 'arrangement'], message: 'Enable the SVG stencil for a stencil start' });
  const ids = new Set(c.start.lights.map(l => l.id));
  if (ids.size !== c.settings.lights.length || c.start.lights.length !== ids.size || !c.settings.lights.every(l => ids.has(l.id)))
    ctx.addIssue({ code: 'custom', path: ['start', 'lights'], message: 'Starting lights must match the configured lights' });
});
export type Configuration = z.infer<typeof configuration>;
export type Start = Configuration['start'];
export type Arrangement = Start['arrangement'];

export function parseConfiguration(input: unknown): Configuration {
  let value = input;
  if (typeof input === 'string') {
    try { value = JSON.parse(input); } catch { throw new Error('This file does not contain valid JSON.'); }
  }
  const result = configuration.safeParse(value);
  if (!result.success) {
    const issue = result.error.issues[0];
    throw new Error('Invalid configuration at ' + (issue.path.join('.') || 'root') + ' — ' + issue.message);
  }
  return result.data;
}
