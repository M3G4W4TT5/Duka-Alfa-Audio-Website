import { useEffect, useId, useRef, useState, type CSSProperties, type PointerEvent, type RefObject, type ReactNode } from 'react';
import { BloomControls, GradientEditor } from './OpticsControls';
import { MAX_FREQUENCY, MIN_FREQUENCY } from '../plate/field';
import { PATTERNS } from '../plate/patterns';
import type { ReliefStatus } from '../plate/relief';
import { clamp, DEFAULT_SETTINGS, EMITTER_RADIUS, GRAIN_COUNTS, GRAIN_SIZE, SHAKER_STRENGTH, STRAY_JUMPS, logoTravel, pointerDriveAxis, type PlateSettings, type SpotlightSettings,
  type StrobeSettings } from '../plate/settings';
import { NumericEntry, percent, SettingSlider, type SliderSpec } from './ControlFields';
import { Spotlights, StrobeControls, type LightingPreset } from './LightingControls';
import { SurfaceControls } from './SurfaceControls';
import { SvgControls, Switch, type SvgSourceControls } from './SvgControls';
import { STENCIL_RETURN_SECONDS } from '../plate/stencil-return';

interface Props {
  controlsOnly: boolean;
  onControlsOnlyChange: (value: boolean) => void;
  viewControls: ReactNode;
  configurationControls: ReactNode;
  settings: PlateSettings;
  svgSource: SvgSourceControls;
  onResetSettings: () => void;
  onChange: (patch: Partial<PlateSettings>) => void;
  onResetZoom: () => void;
  onResprinkle: () => void;
  region: number;
  reliefStatus: ReliefStatus;
  onChoosePattern: (index: number) => void;
  mapRef: RefObject<HTMLDivElement | null>;
  captureAngle: (id: number) => number | undefined;
  onLightChange: (id: number, patch: Partial<SpotlightSettings>) => void;
  onAddLight: () => number | undefined;
  onRemoveLight: (id: number) => void;
  onPreset: (preset: LightingPreset) => void;
  onStrobeChange: (patch: Partial<StrobeSettings>) => void;
}

type Bound = 'minHz' | 'maxHz';

function BackgroundControls({ settings, onChange, reliefStatus }: Pick<Props, 'settings' | 'onChange' | 'reliefStatus'>) {
  const travel = logoTravel(settings.logoSize);
  const mm = (value: number) => `${value} mm`;
  return (
    <section aria-label="Background">
      <h2>Background</h2>
      <div className="drive-modes" role="group" aria-label="Background surface">
        {(['flat', '3d'] as const).map(background => <button type="button" key={background}
          aria-pressed={settings.background === background} onClick={() => onChange({ background })}>
          {background === 'flat' ? 'Flat' : '3D'}</button>)}
      </div>
      {settings.background === '3d' && <>
        {reliefStatus === 'loading' && <p role="status" className="control-caption">Loading Duka logo…</p>}
        {reliefStatus === 'error' && <p role="status" className="control-caption">The logo could not load. Select Flat and then 3D to retry.</p>}
        <SettingSlider spec={{ label: 'Logo size', min: 15, max: 100, step: 1, format: v => `${v}%` }}
          value={settings.logoSize} onChange={logoSize => {
            const limit = logoTravel(logoSize);
            onChange({ logoSize, logoX: clamp(settings.logoX, -limit.x, limit.x), logoY: clamp(settings.logoY, -limit.y, limit.y) });
          }} />
        <SettingSlider spec={{ label: 'Logo height', min: 0, max: 4, step: .05, format: mm }}
          value={settings.logoHeight} onChange={logoHeight => onChange({ logoHeight })} />
        <SettingSlider spec={{ label: 'X position', min: -travel.x, max: travel.x, step: .1, format: mm }}
          value={settings.logoX} onChange={logoX => onChange({ logoX })} />
        <SettingSlider spec={{ label: 'Y position', min: -travel.y, max: travel.y, step: .1, format: mm }}
          value={settings.logoY} onChange={logoY => onChange({ logoY })} />
        <span id="relief-light-label" className="control-caption relief-light-label">Spotlights and strobe</span>
        <div className="drive-modes" role="group" aria-labelledby="relief-light-label">
          <button type="button" aria-pressed={settings.reliefLighting === 'solid'}
            title="Light and shadow fall on the plate, logo and sand"
            onClick={() => onChange({ reliefLighting: 'solid' })}>Solid</button>
          <button type="button" aria-pressed={settings.reliefLighting === 'pass-through'}
            title="Spotlights and strobe pass through to the grains. Surfaces use fixed studio lighting and neon spill is disabled."
            onClick={() => onChange({ reliefLighting: 'pass-through' })}>Pass through</button>
        </div>
      </>}
      <SurfaceControls settings={settings} onChange={onChange} />
    </section>
  );
}

function FrequencyRange({ settings: { minHz, maxHz }, onChange }: Pick<Props, 'settings' | 'onChange'>) {
  const active = useRef<Bound | null>(null);
  const span = MAX_FREQUENCY - MIN_FREQUENCY;
  const progress = (value: number) => 100 * (value - MIN_FREQUENCY) / span;

  function setBound(bound: Bound, input: number) {
    const rounded = Math.round(input * 10) / 10;
    const value = bound === 'minHz'
      ? clamp(rounded, MIN_FREQUENCY, maxHz)
      : clamp(rounded, minHz, MAX_FREQUENCY);
    onChange({ [bound]: value });
    return value;
  }

  function trackFrequency(event: PointerEvent<HTMLDivElement>) {
    const bounds = event.currentTarget.getBoundingClientRect();
    return MIN_FREQUENCY + span * clamp((event.clientX - bounds.left) / bounds.width, 0, 1);
  }

  return (
    <div>
      <div className="range-entries">
        <label>
          <span>Min</span>
          <NumericEntry label="Minimum frequency in hertz" value={minHz} min={MIN_FREQUENCY}
            max={maxHz} step={0.1} commit={value => setBound('minHz', value)} />
        </label>
        <label>
          <span>Max</span>
          <NumericEntry label="Maximum frequency in hertz" value={maxHz} min={minHz}
            max={MAX_FREQUENCY} step={0.1} commit={value => setBound('maxHz', value)} />
        </label>
      </div>
      <div
        className="frequency-track"
        style={{ '--range-start': `${progress(minHz)}%`, '--range-end': `${progress(maxHz)}%` } as CSSProperties}
        onPointerDown={event => {
          if (event.target !== event.currentTarget || event.button !== 0) return;
          const value = trackFrequency(event);
          const bound = value <= (minHz + maxHz) / 2 ? 'minHz' : 'maxHz';
          active.current = bound;
          event.currentTarget.setPointerCapture(event.pointerId);
          setBound(bound, value);
        }}
        onPointerMove={event => {
          if (active.current && event.currentTarget.hasPointerCapture(event.pointerId)) {
            setBound(active.current, trackFrequency(event));
          }
        }}
        onLostPointerCapture={() => { active.current = null; }}
      >
        <div className="frequency-rail" />
        {(['minHz', 'maxHz'] as const).map(bound => {
          const minimum = bound === 'minHz';
          const value = minimum ? minHz : maxHz;
          return (
            <input key={bound} className="frequency-thumb" type="range" min={MIN_FREQUENCY}
              max={MAX_FREQUENCY} step={0.1} value={value}
              aria-label={minimum ? 'Minimum frequency' : 'Maximum frequency'}
              aria-valuetext={`${value} Hz`} onChange={event => setBound(bound, event.currentTarget.valueAsNumber)} />
          );
        })}
      </div>
      <div className="panel-actions frequency-actions">
        <button type="button" disabled={minHz === MIN_FREQUENCY && maxHz === MAX_FREQUENCY}
          onClick={() => onChange({ minHz: MIN_FREQUENCY, maxHz: MAX_FREQUENCY })}>
          Full range
        </button>
      </div>
    </div>
  );
}

const sandSpeed: SliderSpec = { label: 'Sand speed', min: .25, max: 4, step: .05,
  format: value => `${value}×` };
const grainFormat = new Intl.NumberFormat('en');
const grainCountSlider: SliderSpec = { label: 'Particle count', ...GRAIN_COUNTS, format: grainFormat.format };
const grainSizeSlider: SliderSpec = { label: 'Particle size', ...GRAIN_SIZE, format: value => `${value}×` };
const multiplier = (value: number) => `${value}×`;
const lightingAmount = { min: 0, max: 1, step: .01, format: percent };
const ATLAS_COLUMNS = 7;
const ATLAS_ROWS = Math.ceil(PATTERNS.length / ATLAS_COLUMNS);
const formatHz = new Intl.NumberFormat('en', { maximumFractionDigits: 1 });

function PatternCatalogue({ region, onChoosePattern, visible }: Pick<Props, 'region' | 'onChoosePattern'> & { visible: boolean }) {
  const grid = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const list = grid.current;
    if (!visible || region % 2 || !list?.clientHeight || list.matches(':hover') || list.querySelector(':focus-visible')) return;
    const card = list.children[region / 2] as HTMLButtonElement;
    // Follow the plate while sweeping. Keep browsing and keyboard focus in
    // the gallery under the visitor's control, and never scroll the outer panel.
    const top = card.offsetTop - 3;
    const bottom = card.offsetTop + card.offsetHeight + 3;
    if (top < list.scrollTop) list.scrollTop = top;
    else if (bottom > list.scrollTop + list.clientHeight) list.scrollTop = bottom - list.clientHeight;
  }, [region, visible]);
  return (
    <details className="pattern-catalogue" open>
      <summary>Pattern catalogue <span>{PATTERNS.length} patterns</span></summary>
      <div ref={grid} className="pattern-grid" role="group" aria-label="Choose a pattern"
        style={{ '--atlas-size': `${ATLAS_COLUMNS * 100}% ${ATLAS_ROWS * 100}%` } as CSSProperties}>
        {PATTERNS.map(({ name, hz }, i) => (
          <button type="button" className="pattern-card" key={hz} aria-current={region === i * 2 || undefined}
            onClick={() => onChoosePattern(i)}>
            <span aria-hidden="true" className="pattern-portrait" style={{
              backgroundPosition: `${100 * (i % ATLAS_COLUMNS) / (ATLAS_COLUMNS - 1)}% ${100 * Math.floor(i / ATLAS_COLUMNS) / (ATLAS_ROWS - 1)}%`,
            }} />
            <span className="pattern-name">{name}</span>
            <span className="pattern-hz">{formatHz.format(hz)} Hz</span>
          </button>
        ))}
      </div>
    </details>
  );
}

export default function PlateControls({ controlsOnly, onControlsOnlyChange, viewControls, configurationControls, settings, svgSource, onResetSettings, onChange, onResetZoom, onResprinkle, region, onChoosePattern, reliefStatus,
  mapRef, captureAngle, onLightChange, onAddLight, onRemoveLight, onPreset, onStrobeChange }: Props) {
  const [open, setOpen] = useState(false);
  const panelId = useId();
  const toggle = useRef<HTMLButtonElement>(null);
  const pointerAxis = pointerDriveAxis(settings);
  const guided = settings.mode === 'patterns';
  const stencil = settings.svg.enabled && settings.svg.stencil;

  return (
    <div className="controls-shell" data-plate-controls
      onKeyDown={event => {
        if (event.key !== 'Escape' || !open) return;
        event.stopPropagation();
        setOpen(false);
        toggle.current?.focus();
      }}
    >
      <button ref={toggle} type="button" className="controls-toggle" aria-expanded={open}
        aria-controls={panelId} onClick={() => setOpen(value => !value)}>
        Controls <span aria-hidden="true" />
      </button>
      <aside id={panelId} className="controls-panel" aria-label="Plate controls" hidden={!open}>
        <section aria-label="Display">
          <Switch label="Controls only" checked={controlsOnly} change={onControlsOnlyChange} />
        </section>
        {open && viewControls}
        {configurationControls}
        <BackgroundControls settings={settings} onChange={onChange} reliefStatus={reliefStatus} />
        <SvgControls layer={settings.svg} source={svgSource} change={patch => onChange({ svg: { ...settings.svg, ...patch } })} />
        <section aria-label="Drive">
          <h2 id="drive-settings">Drive</h2>
          <div className="vibration-control"><Switch label="Vibration" checked={settings.vibration}
            change={vibration => onChange({ vibration })} /></div>
          {stencil && <div className="vibration-control">
            <Switch label="Return to stencil" checked={settings.svg.returnToStencil}
              change={returnToStencil => onChange({ svg: { ...settings.svg, returnToStencil } })} />
            {settings.svg.returnToStencil && <SettingSlider
              spec={{ label: 'Return speed', min: .25, max: 4, step: .05,
                format: value => `${Number(value.toFixed(2))}×`,
                help: `Full return in ${Number((STENCIL_RETURN_SECONDS / settings.svg.returnSpeed).toFixed(2))} s with vibration off.` }}
              value={settings.svg.returnSpeed}
              onChange={returnSpeed => onChange({ svg: { ...settings.svg, returnSpeed } })} />}
          </div>}
          <div className="drive-modes" role="group" aria-label="Drive mode">
            {(['frequency', 'patterns'] as const).map(mode => (
              <button type="button" key={mode} aria-pressed={settings.mode === mode}
                onClick={() => onChange({ mode })}>{mode === 'frequency' ? 'Frequency' : 'Patterns'}</button>
            ))}
          </div>
          <span id="drive-axis" className="control-caption">Drive axis</span>
          <div className="drive-modes" role="group" aria-labelledby="drive-axis">
            {(['vertical', 'horizontal'] as const).map(axis => (
              <button type="button" key={axis} aria-pressed={pointerAxis === axis}
                onClick={() => onChange(guided ? { driveAxis: axis, patternPointerDisabled: false } : { driveAxis: axis })}>
                {axis === 'vertical' ? 'Vertical' : 'Horizontal'}
              </button>
            ))}
            {guided && <button type="button" aria-pressed={pointerAxis === null} title="Disable pointer tuning for patterns"
              onClick={() => onChange({ patternPointerDisabled: true })}>Disable</button>}
          </div>
          {guided ?
            <PatternCatalogue region={region} onChoosePattern={onChoosePattern} visible={open} /> :
            <div><h3 className="range-heading">Frequency range <span>Hz</span></h3>
              <FrequencyRange settings={settings} onChange={onChange} />
            </div>}
          <SettingSlider spec={{ label: 'Shaker strength', ...SHAKER_STRENGTH, format: multiplier,
            help: 'Changes the plate’s vibration amplitude at the current frequency.' }}
            value={settings.shakerStrength} onChange={shakerStrength => onChange({ shakerStrength })} />
          <SettingSlider spec={sandSpeed} value={settings.sandSpeed} onChange={sandSpeed => onChange({ sandSpeed })} />
          <div className="panel-actions particle-count-control">
            <SettingSlider spec={grainCountSlider} value={settings.grainCount} onChange={grainCount => onChange({ grainCount })}
              entry={{ label: 'Exact particle count', unit: '' }} />
            <button type="button" onClick={onResprinkle} disabled={stencil && (!svgSource.ready || svgSource.busy)}
              title={stencil ? 'Pour all grains through the SVG stencil' : 'Scatter half the grains across the plate'}>
              {stencil ? 'Resprinkle into shape' : 'Resprinkle'}
            </button>
          </div>
          <SettingSlider spec={grainSizeSlider} value={settings.grainSize} onChange={grainSize => onChange({ grainSize })}
            entry={{ label: 'Particle size multiplier', unit: '×' }} />
          <Switch label="Particle shape smoothing" checked={settings.grainSmoothing}
            change={grainSmoothing => onChange({ grainSmoothing })} />
        </section>
        <section className="grain-tuning" aria-label="Stray grains">
          <h2>Stray grains</h2>
          <SettingSlider spec={{ label: 'Jump rate', ...STRAY_JUMPS.rate, format: multiplier }}
            value={settings.strayJumpRate} onChange={strayJumpRate => onChange({ strayJumpRate })} />
          <SettingSlider spec={{ label: 'Peak bounce height', ...STRAY_JUMPS.height, format: value => `${value} mm`,
            help: 'Exposed grains in stronger vibration jump highest.' }}
            value={settings.strayBounceHeight} onChange={strayBounceHeight => onChange({ strayBounceHeight })} />
          <SettingSlider spec={{ label: 'Sideways kick', ...STRAY_JUMPS.kick, format: multiplier }}
            value={settings.straySideKick} onChange={straySideKick => onChange({ straySideKick })} />
          <div className="panel-actions"><button type="button" onClick={() => onChange({
            strayJumpRate: DEFAULT_SETTINGS.strayJumpRate, strayBounceHeight: DEFAULT_SETTINGS.strayBounceHeight,
            straySideKick: DEFAULT_SETTINGS.straySideKick,
          })}>Reset jumps</button></div>
        </section>
        <section className="grain-tuning" aria-label="Grain lighting">
          <h2>Grain lighting</h2>
          <SettingSlider spec={{ label: 'Highlight variation', ...lightingAmount }}
            value={settings.highlightVariation} onChange={highlightVariation => onChange({ highlightVariation })} />
          <SettingSlider spec={{ label: 'Ridge shading', ...lightingAmount }}
            value={settings.ridgeShading} onChange={ridgeShading => onChange({ ridgeShading })} />
          <SettingSlider spec={{ label: 'Light source radius', ...EMITTER_RADIUS, format: value => `${value} mm`,
            help: 'Wider emitters soften shadows as grains rise above the surface.' }}
            value={settings.emitterRadius} onChange={emitterRadius => onChange({ emitterRadius })} />
        </section>
        <Spotlights lights={settings.lights} strobe={settings.strobe} mapRef={mapRef} captureAngle={captureAngle}
          onChange={onLightChange} onAdd={onAddLight} onRemove={onRemoveLight} onPreset={onPreset}>
          <GradientEditor gradient={settings.gradient} onChange={gradient => onChange({ gradient })} />
        </Spotlights>
        <StrobeControls settings={settings.strobe} lights={settings.lights} onChange={onStrobeChange} />
        <BloomControls settings={settings} onChange={onChange} />
        <div className="panel-actions controls-footer">
          <button type="button" onClick={onResetZoom}>Reset zoom</button>
          <button type="button" onClick={onResetSettings}>Reset settings</button>
        </div>
      </aside>
    </div>
  );
}
