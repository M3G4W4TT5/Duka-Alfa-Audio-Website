import { useEffect, useImperativeHandle, useMemo, useRef, useState, type Ref } from 'react';
import { parseConfiguration } from '../plate/configuration';
import { defaultFraming, type Preview } from '../plate/framing';
import { loadPresetSvg } from '../plate/preset-assets';
import { DEFAULT_SETTINGS } from '../plate/settings';
import { usePlate, type ChladniPointerHandle } from '../plate/use-plate';
import '../styles/stage.css';

export type ChladniPlayerHandle = ChladniPointerHandle;

export interface ChladniPlayerProps {
  configuration: unknown;
  active?: boolean;
  ref?: Ref<ChladniPlayerHandle>;
}

export function ChladniPlayer({ configuration, active = true, ref }: ChladniPlayerProps) {
  const preset = useMemo(() => {
    try {
      return { value: parseConfiguration(configuration) };
    } catch (error) {
      return { message: error instanceof Error ? error.message : 'Could not read configuration.' };
    }
  }, [configuration]);
  const settings = useRef(DEFAULT_SETTINGS);
  const preview = useRef<Preview>({ view: 'window', editing: false, layout: 'player', framing: defaultFraming() });
  const { stage, canvas, error, plate, instance } = usePlate({ active: active && !!preset.value, settings, preview });
  const [ready, setReady] = useState<typeof preset>();
  const [failure, setFailure] = useState<{ preset: typeof preset; message: string }>();

  useImperativeHandle(ref, () => ({
    movePointer: event => { if (ready === preset) instance.current?.movePointer(event); },
    leavePointer: () => instance.current?.leavePointer(),
  }), [instance, preset, ready]);

  useEffect(() => {
    if (!plate || !preset.value) return;
    const config = preset.value;
    const controller = new AbortController();
    const { signal } = controller;
    plate.cancelPreparation();
    loadPresetSvg(config, signal).then(({ image }) => {
      if (signal.aborted) return;
      settings.current = config.settings;
      preview.current = { ...preview.current, framing: config.framing };
      plate.setSvgImage(image);
      plate.restore(config.start, () => { if (!signal.aborted) setReady(preset); });
    }).catch(error => {
      if (!signal.aborted) setFailure({ preset, message: error instanceof Error ? error.message : 'Could not load configuration.' });
    });
    return () => controller.abort();
  }, [plate, preset]);

  const message = preset.message ?? (failure?.preset === preset ? failure.message : undefined);
  return <div className="chladni-player">
    <div className="plate-stage" ref={stage} style={ready === preset ? undefined : { visibility: 'hidden' }}>
      <canvas ref={canvas} aria-hidden="true" />
    </div>
    {message && <p className="plate-error" role="status">{message}</p>}
    <p className="plate-error" ref={error} role="status" hidden>The plate needs WebGL2 with floating-point render targets.</p>
  </div>;
}
