export { ChladniPlayer, type ChladniPlayerHandle, type ChladniPlayerProps } from './components/ChladniPlayer';
export { parseConfiguration, type Configuration } from './plate/configuration';
export { createStarterPreset } from './plate/starter';
export type { PlatePointerEvent as ChladniPointerEvent } from './plate/experiment';
