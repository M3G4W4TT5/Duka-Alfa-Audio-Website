import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { mountPlate, type PlatePointerEvent } from './experiment';

type MountOptions = Parameters<typeof mountPlate>[0];
type Options = Omit<MountOptions, 'stage' | 'canvas' | 'error' | 'frequency'> & {
  frequency?: { readonly current: HTMLOutputElement | null };
};
type Plate = NonNullable<ReturnType<typeof mountPlate>>;

export interface ChladniPointerHandle {
  movePointer(event: PlatePointerEvent): void;
  leavePointer(): void;
}

export function usePlate(options: Options) {
  const stage = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const error = useRef<HTMLParagraphElement>(null);
  const [started, setStarted] = useState(options.active);
  const [plate, setPlate] = useState<Plate>();
  const current = useRef(options);
  const instance = useRef<Plate>(undefined);

  useLayoutEffect(() => {
    current.current = options;
    instance.current?.setActive(options.active);
    if (options.active && !started) setStarted(true);
  });

  useEffect(() => {
    if (!started || !stage.current || !canvas.current || !error.current) return;
    const mounted = mountPlate({ ...current.current, stage: stage.current, canvas: canvas.current,
      error: error.current, frequency: current.current.frequency?.current });
    instance.current = mounted;
    setPlate(mounted);
    return () => {
      instance.current = undefined;
      mounted?.dispose();
    };
  }, [started]);

  return { stage, canvas, error, plate, instance };
}
