import { useCallback, useEffect, useId, useImperativeHandle, useLayoutEffect, useRef, useState, type CSSProperties, type ReactNode, type Ref } from 'react';
import { createPortal } from 'react-dom';
import type { ReliefStatus } from '../plate/relief';
import { START_FREQUENCY } from '../plate/field';
import { addLight, lightingPreset, mapPoint, replaceLights } from '../plate/lighting';
import { PATTERNS, patternRegion } from '../plate/patterns';
import { clamp, DEFAULT_SETTINGS, pointerDriveAxis, svgPlacement, type PlateSettings, type SpotlightSettings, type StrobeSettings } from '../plate/settings';
import { loadSvgImage, type SvgImage } from '../plate/svg-image';
import type { LightingPreset } from './LightingControls';
import PlateControls from './PlateControls';
import { cropForReference, defaultFraming, storeCrop, type Crop, type Preview } from '../plate/framing';
import { bindFrameGestures } from '../plate/frame-gestures';
import { BUILTINS, DUKA_SVG, ENGINE, parseConfiguration, type Arrangement, type Configuration } from '../plate/configuration';
import { loadPresetSvg } from '../plate/preset-assets';
import { usePlate, type ChladniPointerHandle, type ChladniPresentationStatus } from '../plate/use-plate';
import { FramingControls } from './FramingControls';
import { ConfigurationControls } from './ConfigurationControls';
import '../styles/stage.css';
import '../styles/plate.css';
import '../styles/controls.css';

export interface ChladniEditorHandle extends ChladniPointerHandle {
  capturePreset(): Configuration;
  loadPreset(input: unknown): Promise<void>;
  present(): boolean;
}

export interface ChladniEditorProps {
  initialPreset?: unknown;
  active?: boolean;
  prepare?: boolean;
  onStatusChange?: (status: ChladniPresentationStatus) => void;
  layout?: 'standalone' | 'container';
  controlsOutlet?: HTMLElement | null;
  title?: ReactNode;
  ref?: Ref<ChladniEditorHandle>;
}

export function ChladniEditor({ initialPreset, active = true, prepare = false, onStatusChange,
  layout = 'standalone', controlsOutlet, title = 'Chladni plate', ref }: ChladniEditorProps) {
  const container = layout === 'container';
  const instructionsId = useId();
  const frequencyId = useId();
  const frequency = useRef<HTMLOutputElement>(null);
  const lightMap = useRef<HTMLDivElement>(null);
  const [settings, setSettings] = useState<PlateSettings>(() => {
    if (container) return DEFAULT_SETTINGS;
    const query = new URLSearchParams(typeof window === 'undefined' ? '' : window.location.search);
    return { ...DEFAULT_SETTINGS, mode: query.get('mode') === 'patterns' ? 'patterns' : DEFAULT_SETTINGS.mode,
      background: query.get('background') === '3d' ? '3d' : 'flat',
      logoEffect: query.get('effect') === 'neon' ? { ...DEFAULT_SETTINGS.logoEffect, kind: 'neon' } : DEFAULT_SETTINGS.logoEffect };
  });
  const [region, setRegion] = useState(() => patternRegion(START_FREQUENCY));
  const [reliefStatus, setReliefStatus] = useState<ReliefStatus>('idle');
  const [svgFile, setSvgFile] = useState<File | null>(null);
  const [svgImage, setSvgImage] = useState<SvgImage | null>(null);
  const [svgError, setSvgError] = useState('');
  const [preview, setPreview] = useState<Preview>(() => ({ view: 'window', layout, editing: false, framing: defaultFraming() }));
  const livePreview = useRef(preview);
  const [controlsOnly, setControlsOnly] = useState(false);
  const [aspect, setAspect] = useState(1);
  const [arrangement, setArrangement] = useState<Arrangement | null>(null);
  const [configMessage, setConfigMessage] = useState('');
  const initial = useRef(initialPreset);
  const [loading, setLoading] = useState(initial.current !== undefined);
  const [initialising, setInitialising] = useState(initial.current !== undefined);
  const loadRequest = useRef<AbortController | null>(null);
  const svgRequest = useRef<AbortController | null>(null);
  const liveSettings = useRef(settings);
  const setView = useCallback((patch: Partial<Preview>) => {
    livePreview.current = { ...livePreview.current, ...patch };
    setPreview(livePreview.current);
  }, []);
  const setCrop = useCallback((crop: Crop | null) => {
    const { framing, view, layout } = livePreview.current;
    const device = layout === 'container' && view !== 'window' ? framing[view] : null;
    const saved = crop && device ? cropForReference(crop, device.width / device.height) : crop;
    setView({ framing: saved ? storeCrop(framing, view, saved) : { ...framing, window: null } });
  }, [setView]);
  const { stage, canvas, error, plate, surface, instance: experiment } = usePlate({ active, prepare, frequency, settings: liveSettings,
    preview: livePreview, bindGestures: container ? undefined : bindFrameGestures,
    onCrop: setCrop, onAspect: setAspect, onPatternRegion: setRegion, onReliefStatus: setReliefStatus,
    onLightDirection: angle => {
      const point = mapPoint(angle);
      lightMap.current?.style.setProperty('--follow-x', `${point.x}%`);
      lightMap.current?.style.setProperty('--follow-y', `${point.y}%`);
    },
  });
  const sample = useCallback(() => experiment.current?.overview(), [experiment]);
  const hasStencil = settings.svg.enabled && settings.svg.stencil;
  const recipe = arrangement === 'stencil' && !hasStencil ? 'loose' :
    arrangement ?? (settings.vibration ? 'pattern' : hasStencil ? 'stencil' : 'loose');
  const guided = settings.mode === 'patterns';
  const driveDirections = settings.driveAxis === 'vertical' ? 'Up / down' : 'Left / right';
  const strobeEnabled = settings.strobe.mode !== 'off' && settings.strobe.strength > 0;
  const tracksPointer = settings.lights.some(light => light.position === 'follow' &&
    (light.intensity > 0 || (strobeEnabled && settings.strobe.source === light.id)));
  const followsHorizontal = settings.lights.some(light => light.colorSource === 'horizontal' && light.intensity > 0);
  const followsVertical = settings.lights.some(light => light.colorSource === 'vertical' && light.intensity > 0);
  const lower = Math.floor(region / 2);
  const patternName = region % 2 === 0 ? PATTERNS[lower].name : `${PATTERNS[lower].name} ↔ ${PATTERNS[lower + 1].name}`;

  function updateSettings(patch: Partial<PlateSettings>) {
    const next = { ...liveSettings.current, ...patch };
    liveSettings.current = next;
    setSettings(next);
  }

  function chooseSvg(file: File | null) {
    setSvgError('');
    setSvgFile(file);
  }

  function resetSettings() {
    loadRequest.current?.abort();
    svgRequest.current?.abort();
    experiment.current?.cancelPreparation();
    initial.current = undefined;
    setLoading(false);
    setInitialising(false);
    setConfigMessage('');
    setArrangement(null);
    setView({ framing: defaultFraming(), view: 'window', editing: false });
    chooseSvg(null);
    setSvgImage(null);
    experiment.current?.setSvgImage(null);
    updateSettings(DEFAULT_SETTINGS);
  }

  useEffect(() => {
    if (!plate || initialising || (!settings.svg.enabled && !svgFile) || svgImage?.file === svgFile) return;
    const controller = new AbortController();
    svgRequest.current = controller;
    loadSvgImage(svgFile, controller.signal).then(image => {
      if (controller.signal.aborted) return;
      const svg = liveSettings.current.svg;
      const { travelX, travelY } = svgPlacement(svg.size, image.aspect);
      updateSettings({ svg: { ...svg, x: clamp(svg.x, -travelX, travelX), y: clamp(svg.y, -travelY, travelY) } });
      experiment.current?.setSvgImage(image);
      setSvgImage(image);
      setSvgError('');
    }).catch((error: unknown) => {
      if (!controller.signal.aborted) setSvgError(error instanceof Error ? error.message : 'Could not read this SVG.');
    });
    return () => controller.abort();
  }, [plate, initialising, svgFile, svgImage, settings.svg.enabled]);

  const svgPending = (settings.svg.enabled || !!svgFile) && svgImage?.file !== svgFile;
  function capturePreset() {
    const mounted = experiment.current;
    if (!mounted || initial.current !== undefined || loadRequest.current)
      throw new Error('The plate must be ready before capturing a preset.');
    if (svgPending) throw new Error(svgError || 'Wait for the SVG to finish loading.');
    const { framing, view, editing } = livePreview.current;
    const svg = svgFile && svgImage?.file === svgFile
      ? { type: 'inline', filename: svgImage.name, source: svgImage.source } : DUKA_SVG;
    return parseConfiguration({ schemaVersion: 1, engine: ENGINE, settings: liveSettings.current, start: mounted.snapshot(recipe),
      framing, editor: { view, editCrop: editing, controlsOnly }, assets: { ...BUILTINS, svg } });
  }

  function saveConfiguration() {
    try {
      const doc = capturePreset();
      const blob = new Blob([JSON.stringify(doc, null, 2) + '\n'], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'plate-' + doc.start.drive.hz.toFixed(1) + 'hz.chladni.json';
      link.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      setConfigMessage('Exported ' + link.download);
    } catch (e) { setConfigMessage(e instanceof Error ? e.message : 'Could not export configuration.'); }
  }

  const loadConfiguration = useCallback(async (input: unknown) => {
    const mounted = experiment.current;
    if (!mounted) throw new Error('The plate must be ready before loading a preset.');
    if (loadRequest.current) {
      loadRequest.current.abort();
      mounted.cancelPreparation();
    }
    const controller = new AbortController();
    const { signal } = controller;
    loadRequest.current = controller;
    setLoading(true);
    setConfigMessage('Reading configuration…');
    try {
      const config = parseConfiguration(input instanceof File ? await input.text() : input);
      signal.throwIfAborted();
      const { file, image } = await loadPresetSvg(config, signal);
      svgRequest.current?.abort();
      liveSettings.current = config.settings;
      setSettings(config.settings);
      setSvgFile(file); setSvgImage(image); setSvgError('');
      setView({ framing: config.framing, view: config.editor.view, editing: config.editor.editCrop });
      setControlsOnly(config.editor.controlsOnly ?? false);
      setArrangement(config.start.arrangement);
      mounted.setSvgImage(image);
      setConfigMessage('Preparing starting sand…');
      await new Promise<void>((resolve, reject) => {
        const abort = () => reject(signal.reason);
        signal.addEventListener('abort', abort, { once: true });
        mounted.restore(config.start, () => {
          signal.removeEventListener('abort', abort);
          resolve();
        });
      });
      signal.throwIfAborted();
      setConfigMessage('Configuration loaded.');
    } catch (e) {
      if (!signal.aborted) setConfigMessage(e instanceof Error ? e.message : 'Could not load configuration.');
      throw e;
    } finally {
      if (loadRequest.current === controller) {
        loadRequest.current = null;
        if (!signal.aborted) {
          initial.current = undefined;
          setLoading(false);
          setInitialising(false);
        }
      }
    }
  }, [experiment, setView]);

  useImperativeHandle(ref, () => ({
    capturePreset,
    loadPreset: loadConfiguration,
    movePointer: event => experiment.current?.movePointer(event),
    leavePointer: () => experiment.current?.leavePointer(),
    present: () => status === 'ready' && !!experiment.current?.present(),
  }));

  const status = surface?.available === false ? 'unavailable' : plate && !loading && !initialising ? 'ready' : 'preparing';
  useLayoutEffect(() => onStatusChange?.(status), [onStatusChange, status]);

  function updateLight(id: number, patch: Partial<SpotlightSettings>) {
    const lights = liveSettings.current.lights.map(light => {
      if (light.id !== id) return light;
      const next = { ...light, ...patch };
      const snapshot = experiment.current?.captureLight(id);
      if (snapshot && patch.position === 'fixed' && light.position === 'follow' && patch.angle === undefined) {
        next.angle = snapshot.angle;
      }
      if (snapshot && patch.colorSource === 'fixed' && light.colorSource !== 'fixed') {
        next.color = snapshot.color;
        next.linearColor = snapshot.linearColor;
      }
      return next;
    });
    updateSettings({ lights });
  }

  function updateLights(lights: SpotlightSettings[]) {
    const current = liveSettings.current;
    const detachedAngle = current.strobe.source === 'fixed' ? undefined : experiment.current?.captureLight(current.strobe.source)?.angle;
    updateSettings(replaceLights(current, lights, detachedAngle));
  }

  function updateStrobe(patch: Partial<StrobeSettings>) {
    const current = liveSettings.current.strobe;
    const strobe = { ...current, ...patch };
    if (patch.source === 'fixed' && current.source !== 'fixed') {
      strobe.angle = experiment.current?.captureLight(current.source)?.angle ?? strobe.angle;
    }
    updateSettings({ strobe });
  }

  useEffect(() => {
    if (plate && initial.current !== undefined) void loadConfiguration(initial.current).catch(() => {});
    return () => loadRequest.current?.abort();
  }, [plate, loadConfiguration]);

  const device = !container && preview.view !== 'window' ? preview.framing[preview.view] : null;
  const controls = <PlateControls settings={settings} onChange={updateSettings} region={region} reliefStatus={reliefStatus}
        controlsOnly={controlsOnly} onControlsOnlyChange={setControlsOnly}
        viewControls={<FramingControls preview={preview} update={setView} aspect={aspect} setCrop={setCrop} sample={sample} />}
        configurationControls={<ConfigurationControls arrangement={recipe} change={setArrangement} hasStencil={hasStencil}
          busy={!plate || loading || (svgPending && !svgError)} message={configMessage}
          save={saveConfiguration} load={file => void loadConfiguration(file).catch(() => {})} />}
        svgSource={{ name: svgImage?.name ?? 'Duka logo', aspect: svgImage?.aspect ?? 1, ready: !!svgImage,
          busy: settings.svg.enabled && svgImage?.file !== svgFile && !svgError, custom: svgFile !== null,
          error: svgError, choose: chooseSvg }} onResetSettings={resetSettings}
        onChoosePattern={index => experiment.current?.selectPattern(index)}
        onResprinkle={() => experiment.current?.resprinkle()}
        onResetZoom={() => experiment.current?.resetZoom()} mapRef={lightMap}
        captureAngle={id => experiment.current?.captureLight(id)?.angle} onLightChange={updateLight}
        onAddLight={() => {
          const previous = liveSettings.current.lights;
          const lights = addLight(previous);
          if (lights === previous) return undefined;
          updateLights(lights);
          return lights.at(-1)?.id;
        }}
        onRemoveLight={id => {
          const lights = liveSettings.current.lights;
          if (lights.length > 1) updateLights(lights.filter(light => light.id !== id));
        }}
        onPreset={(preset: LightingPreset) => updateLights(lightingPreset(preset))} onStrobeChange={updateStrobe} />;
  const hostedControls = <div className="chladni-controls-outlet" hidden={!active || initialising}>{controls}</div>;

  return (
    <div className={`experiment plate-editor${container ? ' chladni-container' : ''}`} data-device={device ? preview.view : undefined}
      data-editing={preview.editing || undefined} style={device ? { '--view-aspect': device.width / device.height,
        '--reference-width': device.width + 'px' } as CSSProperties : undefined}>
      <div className="preview-space"><div className="plate-stage" ref={stage} style={initialising ? { visibility: 'hidden' } : undefined}>
        <canvas ref={canvas} tabIndex={container ? undefined : 0} aria-describedby={controlsOnly ? undefined : instructionsId}
          aria-label="Overhead simulation of sand on a vibrating square plate" />
      </div></div>
      {!controlsOnly && (!container || !initialising) && <header className="plate-title">
        <h1>{title}</h1>
        <p>{device ? (preview.view === 'desktop' ? 'Desktop' : 'Mobile') + ' · ' + device.width + ' × ' + device.height : 'P1 / S45C steel'}</p>
      </header>}
      <div className="drive" hidden={controlsOnly || (container && initialising)}>
        <label htmlFor={frequencyId}>{guided ? patternName : 'Drive frequency'}</label>
        <div className="readout">
          <output id={frequencyId} ref={frequency} aria-live="off">126.0</output>
          <span>Hz</span>
        </div>
        {!settings.vibration && <span className="vibration-status">Vibration off</span>}
        <p className="instructions" id={instructionsId}>
          {preview.editing ? <span>{container ? 'Pan and zoom with the plate overview in Controls' : 'Drag to pan · Scroll or pinch to zoom'}</span> : <>
          <span>{pointerDriveAxis(settings) === null ? 'Choose a pattern in Controls' :
            `${driveDirections}${guided ? ' through patterns' : ' for frequency'}`}</span>
          {(followsHorizontal || followsVertical) && <span>{followsHorizontal && followsVertical ? 'Both axes' :
            followsHorizontal ? 'Left / right' : 'Up / down'} for light colour</span>}
          {tracksPointer && <span>Lights follow pointer direction</span>}
          {!container && <span>Scroll to zoom</span>}
          {!container && strobeEnabled && settings.strobe.mode === 'hold' && <span>Hold on the plate or hold Space for strobe</span>}
          {strobeEnabled && settings.strobe.mode === 'automatic' && <span>Automatic strobe on</span>}
          </>}
        </p>
      </div>
      {container ? (controlsOutlet ? createPortal(hostedControls, controlsOutlet) : hostedControls) : controls}
      <p className="plate-error" ref={error} role="status" hidden>The plate needs WebGL2 with floating-point render targets.</p>
    </div>
  );
}
